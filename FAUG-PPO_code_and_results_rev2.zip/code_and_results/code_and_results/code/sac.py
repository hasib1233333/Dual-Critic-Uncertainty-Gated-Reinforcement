"""Soft actor-critic (Haarnoja et al., 2018) with a tanh-squashed Gaussian policy,
twin Q-critics, target networks, and automatic entropy tuning. Same act() API as TD3Agent."""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as Fn


def mlp(sizes, act=nn.ReLU):
    L = []
    for i in range(len(sizes) - 1):
        L += [nn.Linear(sizes[i], sizes[i + 1])] + ([act()] if i < len(sizes) - 2 else [])
    return nn.Sequential(*L)


class SACActor(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden=64):
        super().__init__()
        self.net = mlp([obs_dim, hidden, hidden, 2 * act_dim])
        self.act_dim = act_dim

    def forward(self, obs, deterministic=False):
        mu, log_std = self.net(obs).chunk(2, -1)
        log_std = log_std.clamp(-5, 2); std = log_std.exp()
        u = mu if deterministic else mu + std * torch.randn_like(mu)
        a = torch.tanh(u)
        logp = (-0.5 * ((u - mu) / std) ** 2 - log_std - 0.5 * np.log(2 * np.pi)).sum(-1)
        logp = logp - (2 * (np.log(2) - u - Fn.softplus(-2 * u))).sum(-1)   # tanh change of variables
        return a, logp


class TwinQ(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden=64):
        super().__init__()
        self.q1 = mlp([obs_dim + act_dim, hidden, hidden, 1]); self.q2 = mlp([obs_dim + act_dim, hidden, hidden, 1])

    def forward(self, o, a):
        x = torch.cat([o, a], -1)
        return self.q1(x).squeeze(-1), self.q2(x).squeeze(-1)


class SACAgent:
    dual = False

    def __init__(self, obs_dim, act_dim, hidden=64, gamma=0.98, tau=0.005, lr=3e-4):
        self.actor = SACActor(obs_dim, act_dim, hidden)
        self.critic = TwinQ(obs_dim, act_dim, hidden); self.critic_target = TwinQ(obs_dim, act_dim, hidden)
        self.critic_target.load_state_dict(self.critic.state_dict())
        self.log_alpha = torch.zeros(1, requires_grad=True); self.target_ent = -float(act_dim)
        self.actor_opt = torch.optim.Adam(self.actor.parameters(), lr=lr)
        self.critic_opt = torch.optim.Adam(self.critic.parameters(), lr=lr)
        self.alpha_opt = torch.optim.Adam([self.log_alpha], lr=lr)
        self.gamma, self.tau, self.act_dim = gamma, tau, act_dim
        self.update_count = 0

    def act(self, obs_np, a_safe_np=None, sample=True, explore_noise=None):
        with torch.no_grad():
            a, _ = self.actor(torch.as_tensor(obs_np, dtype=torch.float32).unsqueeze(0), deterministic=not sample)
        return a.squeeze(0).numpy(), 0.0, 0.0, 0.0, 1.0

    def update(self, buf, batch_size=256):
        if buf.size < batch_size:
            return
        o, a, r, no, d = buf.sample(batch_size)
        alpha = self.log_alpha.exp().detach()
        with torch.no_grad():
            na, nlogp = self.actor(no)
            q1t, q2t = self.critic_target(no, na)
            y = r + self.gamma * (1 - d) * (torch.min(q1t, q2t) - alpha * nlogp)
        q1, q2 = self.critic(o, a)
        lc = ((q1 - y) ** 2).mean() + ((q2 - y) ** 2).mean()
        self.critic_opt.zero_grad(); lc.backward(); self.critic_opt.step()
        pa, logp = self.actor(o)
        la = (alpha * logp - torch.min(*self.critic(o, pa))).mean()
        self.actor_opt.zero_grad(); la.backward(); self.actor_opt.step()
        lal = -(self.log_alpha * (logp.detach() + self.target_ent)).mean()
        self.alpha_opt.zero_grad(); lal.backward(); self.alpha_opt.step()
        with torch.no_grad():
            for p, pt in zip(self.critic.parameters(), self.critic_target.parameters()):
                pt.data.mul_(1 - self.tau).add_(self.tau * p.data)
        self.update_count += 1
