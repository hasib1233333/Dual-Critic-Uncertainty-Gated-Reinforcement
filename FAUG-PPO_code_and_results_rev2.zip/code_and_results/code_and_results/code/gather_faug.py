"""
Secondary analyses for FAUG-PPO (proposed), mirroring the gather_extra.py /
gather_extra2.py protocols. DCUG-PPO (dcug_full seed 1, now an ablation) and
single-critic PPO (seed 2) are re-run alongside wherever the original
protocol interleaved controllers on one environment stream, so every number
within a figure comes from the same run. Output: results/extra_faug.json
"""
import os, json, time
import numpy as np

from env import IBVSDropoutEnv
from train import make_env
from controllers import run_classical_ekf_fallback, fallback_action, classical_ibvs_action
from run_experiments import load_agent
from eval_faug import load_faug, RESULTS

OUT = {}
faug = load_faug(1)
dcug = load_agent('dcug_full', 1, dual=True)
sc = load_agent('single_critic', 2, dual=False)


def record_classical(env, mode, reset_kw=None):
    obs, _ = env.reset(**(reset_kw or {}))
    done, traj, last = False, [], np.zeros(4)
    while not done:
        if mode == 'no_fallback':
            if env.channel.visible:
                last = classical_ibvs_action(env.pose, env.s_star)
            action = last
        else:
            action = classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred)
        obs, rew, done, info = env.step(action)
        traj.append(dict(rmse=info['rmse_true'], visible=info['visible'], pose=info['pose'].tolist(),
                         action=np.asarray(action).tolist(), success=info['success']))
    return traj


def record_agent(env, agent, reset_kw=None):
    obs, _ = env.reset(**(reset_kw or {}))
    done, traj = False, []
    while not done:
        a_safe = fallback_action(env) if agent.dual else np.zeros(4, dtype=np.float32)
        act, logp, vopt, vpess, alpha = agent.act(obs, a_safe_np=a_safe, sample=False)
        obs, rew, done, info = env.step(act)
        traj.append(dict(rmse=info['rmse_true'], visible=info['visible'], pose=info['pose'].tolist(),
                         action=act.tolist(), alpha=float(alpha), success=info['success']))
    return traj


def conv_effort_jerk(traj):
    conv, hold = None, 0
    for i, s in enumerate(traj):
        hold = hold + 1 if s['rmse'] < 5.5 else 0
        if hold >= 8:
            conv = i - 7
            break
    A = np.array([s['action'] for s in traj])
    effort = float(np.mean(np.sum(A ** 2, axis=1)))
    jerk = float(np.mean(np.sum(np.diff(A, axis=0) ** 2, axis=1))) if len(A) > 1 else 0.0
    return conv, effort, jerk


t0 = time.time()
# 1) matched severe-dropout qualitative episode (same seed as the paper)
OUT['qualitative_faug'] = record_agent(make_env(seed=42, difficulty='severe'), faug)
print('qualitative done', flush=True)

# 2) control effort / jerk / convergence time: five controllers interleaved, 120 episodes
names = ['no_fallback', 'ekf_fallback', 'single_critic', 'dcug_full', 'faug']
conv = {k: [] for k in names}; eff = {k: [] for k in names}; jerk = {k: [] for k in names}
env = make_env(seed=77, difficulty='moderate')
for k in range(120):
    trs = [record_classical(env, 'no_fallback'), record_classical(env, 'ekf_fallback'),
           record_agent(env, sc), record_agent(env, dcug), record_agent(env, faug)]
    for n, tr in zip(names, trs):
        c, e, j = conv_effort_jerk(tr)
        if c is not None:
            conv[n].append(c)
        eff[n].append(e); jerk[n].append(j)
OUT['convergence'] = conv; OUT['effort'] = eff; OUT['jerk'] = jerk
print('effort block done', {k: round(float(np.mean(v)), 4) for k, v in jerk.items()}, flush=True)

# 3) multi-seed effort/jerk for FAUG-PPO (removes the single-seed caveat for the proposed method)
ms = []
for sd in range(1, 11):
    ag = load_faug(sd)
    env = make_env(seed=77, difficulty='moderate')
    es, js = [], []
    for k in range(120):
        _, e, j = conv_effort_jerk(record_agent(env, ag))
        es.append(e); js.append(j)
    ms.append(dict(seed=sd, effort=float(np.mean(es)), jerk=float(np.mean(js))))
OUT['faug_multiseed_effort_jerk'] = ms
print('multiseed effort done', flush=True)

# 4) dropout-parameter heatmap (FAUG vs alpha-beta fallback, alternating as in the original)
pl_grid = [0.03, 0.06, 0.09, 0.12, 0.16, 0.20]
pr_grid = [0.35, 0.25, 0.18, 0.12, 0.08]
hf = np.zeros((5, 6)); he = np.zeros((5, 6))
for i, pr in enumerate(pr_grid):
    for j, pl in enumerate(pl_grid):
        env = IBVSDropoutEnv(p_lose=pl, p_recover=pr, seed=123)
        sf = se = 0
        for k in range(60):
            obs, _ = env.reset(); done = False
            while not done:
                act, *_ = faug.act(obs, a_safe_np=fallback_action(env), sample=False)
                obs, rew, done, info = env.step(act)
            sf += info['success']
            se += run_classical_ekf_fallback(env, dict())[-1]['success']
        hf[i, j] = sf / 60; he[i, j] = se / 60
OUT['heatmap'] = dict(p_lose_grid=pl_grid, p_recover_grid=pr_grid, faug=hf.tolist(), ekf=he.tolist())
print('heatmap done', flush=True)

# 5) initial-pose displacement (same env stream order as the original: nf, ekf, sc, then proposed)
dist = {}
for name, scale in [('near', 0.5), ('medium', 1.0), ('far', 1.6)]:
    env = make_env(seed=55, difficulty='moderate'); res = {}
    for cname, mode in [('no_fallback', 'no_fallback'), ('ekf_fallback', 'ekf')]:
        res[cname] = float(np.mean([record_classical(env, mode, dict(difficulty=scale))[-1]['success'] for _ in range(80)]))
    for cname, ag in [('single_critic', sc), ('faug', faug)]:
        res[cname] = float(np.mean([record_agent(env, ag, dict(difficulty=scale))[-1]['success'] for _ in range(80)]))
    dist[name] = res
OUT['distance_sensitivity'] = dist
print('distance done', dist, flush=True)

# 6) pixel-noise sweep (FAUG, DCUG, single-critic, alpha-beta fallback interleaved)
noise_levels = [0.0, 0.5, 1.0, 2.0, 3.0, 4.0]
nz = {k: [] for k in ['faug', 'dcug_full', 'single_critic', 'ekf_fallback']}
for sigma in noise_levels:
    env = IBVSDropoutEnv(p_lose=0.08, p_recover=0.18, seed=321, pixel_noise_std=sigma)
    cnt = {k: 0 for k in nz}
    for k in range(100):
        cnt['faug'] += record_agent(env, faug)[-1]['success']
        cnt['dcug_full'] += record_agent(env, dcug)[-1]['success']
        cnt['single_critic'] += record_agent(env, sc)[-1]['success']
        cnt['ekf_fallback'] += run_classical_ekf_fallback(env, dict())[-1]['success']
    for kk in nz:
        nz[kk].append(cnt[kk] / 100)
OUT['noise_robustness'] = dict(noise_levels=noise_levels, **nz)
print('noise done', flush=True)


# 7) disturbance rejection (same protocol and seed as the paper)
def run_with_disturbance(agent, mode, seed=17, jump=(0.05, -0.04), jump_step=40, horizon=90):
    env = make_env(seed=seed, difficulty='moderate'); obs, _ = env.reset(); traj = []
    for t in range(horizon):
        if t == jump_step:
            env.target_xy = env.target_xy + np.array(jump)
        if mode == 'ekf':
            action = classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred)
        else:
            a_safe = fallback_action(env) if agent.dual else np.zeros(4, dtype=np.float32)
            action, *_ = agent.act(obs, a_safe_np=a_safe, sample=False)
        obs, rew, done, info = env.step(action)
        traj.append(dict(rmse=info['rmse_true']))
        env._success_streak = 0
    return traj


OUT['disturbance'] = dict(ekf_fallback=run_with_disturbance(None, 'ekf'),
                          single_critic=run_with_disturbance(sc, 'rl'),
                          faug=run_with_disturbance(faug, 'rl'), jump_step=40)

# 8) inference timing (ms per control step, single CPU core context as in the paper)
env = make_env(seed=99, difficulty='moderate'); obs, _ = env.reset()
def timeit(fn, n=500):
    t = time.time()
    for _ in range(n):
        fn()
    return (time.time() - t) / n * 1000
OUT['timing_ms'] = dict(
    classical=timeit(lambda: classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred)),
    single_critic=timeit(lambda: sc.act(obs, a_safe_np=np.zeros(4, dtype=np.float32), sample=False)),
    dcug_full=timeit(lambda: dcug.act(obs, a_safe_np=fallback_action(env), sample=False)),
    faug=timeit(lambda: faug.act(obs, a_safe_np=fallback_action(env), sample=False)))
print('timing', OUT['timing_ms'], flush=True)

json.dump(OUT, open(f'{RESULTS}/extra_faug.json', 'w'))
print(f'SAVED extra_faug.json in {time.time()-t0:.0f}s', flush=True)
