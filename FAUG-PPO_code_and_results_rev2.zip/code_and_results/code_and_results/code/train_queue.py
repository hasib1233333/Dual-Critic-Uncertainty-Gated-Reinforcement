"""Training queue for the C&EE revision (all PPO variants at an identical 3000-episode budget).
Usage: python train_queue.py WORKER_ID N_WORKERS   (jobs already finished are skipped)."""
import os, sys, json, time
import numpy as np, torch
torch.set_num_threads(1)
from train import make_env, collect_and_train
from ppo import Agent
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, '..', 'results'); MOD = os.path.join(HERE, '..', 'models_v2'); os.makedirs(MOD, exist_ok=True)
CFG = {  # name: (agent kwargs, env kwargs)
    'faug_sc':  (dict(gate_single=True), {}),                       # proposed: single critic, learned gate
    'sc_3k':    (dict(), {}),                                       # single-critic PPO, no fallback
    'dcug_3k':  (dict(dual=True), {}),                              # dual-critic + Delta-V gate
    'resid':    (dict(residual=True), {}),                          # residual RL (unit weight)
    'faug_kf':  (dict(gate_single=True), dict(estimator='kf')),     # proposed gate + calibrated KF
}
CFG.update({  # factorial ablation (C&EE revision 2)
    'kf_fixed': (dict(gate_single=True, fixed_alpha=0.5), dict(estimator='kf')),          # KF predictor, fixed blend
    'kf_age':   (dict(gate_single=True), dict(estimator='kf', obs_mask=('zeta',))),       # KF, gate sees age only
    'kf_cov':   (dict(gate_single=True), dict(estimator='kf', obs_mask=('tau',))),        # KF, gate sees covariance only
    'kf_none':  (dict(gate_single=True), dict(estimator='kf', obs_mask=('tau', 'zeta'))), # KF, no uncertainty input
    'kf_proxy': (dict(gate_single=True), dict(estimator='kf', unc='proxy')),              # KF predictor, heuristic proxy
    'ab_kfcov': (dict(gate_single=True), dict(unc='kfcov')),                               # ab predictor, KF covariance
    'faug_kf_log': (dict(gate_single=True), dict(estimator='kf')),                       # = faug_kf, re-run with per-entry interaction logging (and a determinism check)
    'faug_kf_rm': (dict(gate_single=True), dict(estimator='kf', mix=True)),               # real-data-driven training (mire-2 + randomization)
    'kf_fixed_rm': (dict(gate_single=True, fixed_alpha=0.5), dict(estimator='kf', mix=True)),
})
ORDER = ['faug_sc', 'sc_3k', 'dcug_3k', 'resid', 'faug_kf'] + (sys.argv[3].split(',') if len(sys.argv) > 3 else [])
NSEED = {}
for i, n in enumerate(ORDER):                          # 'name:K' trains seeds 1..K only
    if ':' in n: ORDER[i], NSEED[n.split(':')[0]] = n.split(':')[0], int(n.split(':')[1])
jobs = [(n, s) for n in ORDER for s in range(1, NSEED.get(n, 10) + 1)]
wid, nw = int(sys.argv[1]), int(sys.argv[2])
for i, (name, sd) in enumerate(jobs):
    if i % nw != wid:
        continue
    ck = f'{MOD}/{name}_seed{sd}.pt'
    if os.path.exists(ck):
        continue
    akw, ekw = CFG[name]
    np.random.seed(sd); torch.manual_seed(sd)
    env = make_env(seed=sd, difficulty='moderate', **dict(ekw))
    ag = Agent(env.obs_dim, env.act_dim, **akw)
    cnt = {'env': 0, 'grad': 0}
    _st, _os = env.step, ag.opt.step
    def step_c(a, _st=_st): cnt['env'] += 1; return _st(a)
    def opt_c(*x, _os=_os, **k): cnt['grad'] += 1; return _os(*x, **k)
    env.step, ag.opt.step = step_c, opt_c
    t0 = time.time()
    hist, _ = collect_and_train(ag, env, total_episodes=3000, episodes_per_update=16, log_every=200, verbose=False)
    dt = time.time() - t0
    torch.save({'actor': ag.actor.state_dict(), 'v_opt': ag.v_opt.state_dict(),
                'v_pess': ag.v_pess.state_dict() if ag.v_pess is not None else None, 'cfg': [akw, ekw]}, ck + '.tmp')
    os.replace(ck + '.tmp', ck)
    hf = f'{RES}/train_v2_{name}_seed{sd}.json'
    json.dump(dict(name=name, seed=sd, history=hist, elapsed=dt, env_steps=cnt['env'], grad_updates=cnt['grad']), open(hf, 'w'))
    print(f'{name} seed {sd} done {dt:.0f}s final windowed success {hist[-1]["success_rate"]:.2f}', flush=True)
print('WORKER DONE', wid, flush=True)
