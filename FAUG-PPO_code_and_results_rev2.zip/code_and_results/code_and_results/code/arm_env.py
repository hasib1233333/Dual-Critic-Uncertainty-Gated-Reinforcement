"""Articulated digital twin: eye-in-hand 6R manipulator in MuJoCo.

Differences from the kinematic tier (all policies are transferred zero-shot):
  * 6R arm (UR5-like link lengths) on a 0.4 m pedestal, gravity on, link masses and inertias,
    joint damping, Coulomb friction (frictionloss), rotor armature;
  * model-based gravity compensation (MuJoCo gravcomp), as in industrial arm controllers;
  * torque-limited joint velocity servos (150 N m shoulder/elbow, 28 N m wrist) and joint position limits;
  * the 4-DOF camera command (vx, vy, vz, wz) is mapped to joint velocities by damped-least-squares
    resolved-rate control (100 Hz) with an attitude-keeping term (optical axis vertical), joint speeds clipped
    to 1.5 rad/s;
  * features are projected from the camera's FULL 6-DOF pose, so tilt errors from dynamics, limits and
    saturation enter the image; the controllers still receive (px, py, pz, yaw) from forward kinematics;
  * optional command latency of `latency` control steps (0.1 s each).
Task, dropout channel, estimators, target drift, reward-free success/loss criteria are as in env.py."""
import numpy as np
import mujoco
from env import TARGET_PTS, Z_DESIRED, F, IMG_HALF, SUCCESS_TOL, SUCCESS_HOLD, DropoutChannel, DT, project

T0 = np.array([0.5, 0.0, 0.0])           # target-frame origin on the table (world)
XML = """
<mujoco model="eye_in_hand_6r">
  <compiler angle="radian"/>
  <option timestep="0.002" gravity="0 0 -9.81" integrator="implicitfast"/>
  <default>
    <joint damping="1.0" frictionloss="0.4" armature="0.1" limited="true"/>
    <geom type="capsule" size="0.04" rgba="0.6 0.6 0.65 1" contype="0" conaffinity="0"/>
  </default>
  <worldbody>
    <geom type="plane" size="1 1 0.01" rgba="0.9 0.9 0.9 1"/>
    <geom type="cylinder" fromto="0 0 0 0 0 0.4" size="0.07"/>
    <body name="link1" gravcomp="1" pos="0 0 0.4">
      <joint name="j1" axis="0 0 1" range="-3.1 3.1"/>
      <inertial pos="0 0 0.04" mass="3.7" diaginertia="0.010 0.010 0.007"/>
      <geom fromto="0 0 0 0 0 0.089"/>
      <body name="link2" gravcomp="1" pos="0 0 0.089">
        <joint name="j2" axis="0 1 0" range="-3.1 0.5"/>
        <inertial pos="0.21 0 0" mass="8.4" diaginertia="0.015 0.13 0.13"/>
        <geom fromto="0 0 0 0.425 0 0"/>
        <body name="link3" gravcomp="1" pos="0.425 0 0">
          <joint name="j3" axis="0 1 0" range="-2.9 2.9"/>
          <inertial pos="0.2 0 0" mass="2.3" diaginertia="0.004 0.03 0.03"/>
          <geom fromto="0 0 0 0.392 0 0" size="0.035"/>
          <body name="link4" gravcomp="1" pos="0.392 0 0">
            <joint name="j4" axis="0 1 0" range="-3.1 3.1" damping="0.3"/>
            <inertial pos="0 0 0" mass="1.2" diaginertia="0.002 0.002 0.002"/>
            <geom fromto="0 0 0 0 0 -0.095" size="0.03"/>
            <body name="link5" gravcomp="1" pos="0 0 -0.095">
              <joint name="j5" axis="1 0 0" range="-3.1 3.1" damping="0.3"/>
              <inertial pos="0 0 0" mass="1.2" diaginertia="0.002 0.002 0.002"/>
              <geom fromto="0 0 0 0 0 -0.082" size="0.03"/>
              <body name="link6" gravcomp="1" pos="0 0 -0.082">
                <joint name="j6" axis="0 0 1" range="-3.1 3.1" damping="0.3"/>
                <inertial pos="0 0 -0.02" mass="0.45" diaginertia="0.0005 0.0005 0.0005"/>
                <geom type="box" size="0.03 0.025 0.02" pos="0 0 -0.02"/>
                <site name="cam" pos="0 0 -0.05" quat="1 0 0 0"/>
              </body>
            </body>
          </body>
        </body>
      </body>
    </body>
  </worldbody>
  <actuator>
    <velocity joint="j1" kv="400" forcerange="-150 150" forcelimited="true"/>
    <velocity joint="j2" kv="400" forcerange="-150 150" forcelimited="true"/>
    <velocity joint="j3" kv="300" forcerange="-150 150" forcelimited="true"/>
    <velocity joint="j4" kv="40" forcerange="-28 28" forcelimited="true"/>
    <velocity joint="j5" kv="40" forcerange="-28 28" forcelimited="true"/>
    <velocity joint="j6" kv="40" forcerange="-28 28" forcelimited="true"/>
  </actuator>
</mujoco>
"""
SUB = int(round(DT / 0.002))
QD_MAX = 1.5


def project_full(p, R, target_xy):
    """Pinhole projection from a full camera pose. R columns: camera x, camera y, (up) z axes in world;
    optical axis = -z. Coincides with env.project for a camera pointing straight down."""
    pts = TARGET_PTS + np.array([target_xy[0], target_xy[1], 0.0])
    d = pts - p
    xc, yc, zc = d @ R[:, 0], d @ R[:, 1], d @ (-R[:, 2])
    zc = np.maximum(zc, 1e-3)
    return np.stack([F * xc / zc, F * yc / zc], 1).reshape(-1), zc


class ArmIBVSEnv:
    V_LIM = np.array([0.25, 0.25, 0.20, 0.8])

    def __init__(self, p_lose=0.08, p_recover=0.18, seed=0, pixel_noise_std=0.5, target_drift_std=0.006,
                 pose_range=None, estimator='ab', kf_q=72.0, latency=0):
        self.estimator, self.kf_q, self.latency = estimator, kf_q, int(latency)
        self.model = mujoco.MjModel.from_xml_string(XML); self.data = mujoco.MjData(self.model)
        self.sid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_SITE, 'cam')
        self.rng = np.random.default_rng(seed); self.channel = DropoutChannel(p_lose, p_recover, self.rng)
        self.pixel_noise_std, self.target_drift_std = pixel_noise_std, target_drift_std
        self.pose_range = pose_range or dict(xy=0.15, z=(0.45, 0.85), th=0.5)
        self.s_star, _, _, _ = project((0.0, 0.0, Z_DESIRED, 0.0))
        self.obs_dim, self.act_dim = 22, 4
        self.Jp = np.zeros((3, self.model.nv)); self.Jr = np.zeros((3, self.model.nv))

    # ---------------------------------------------------------------- kinematics helpers
    def _cam(self):
        p = self.data.site_xpos[self.sid].copy(); R = self.data.site_xmat[self.sid].reshape(3, 3).copy()
        return p, R

    def _pose4(self):
        p, R = self._cam()
        return np.array([p[0] - T0[0], p[1] - T0[1], p[2] - T0[2], np.arctan2(R[1, 0], R[0, 0])])

    def _ik(self, pose):
        x, y, z, th = pose
        p_des = T0 + np.array([x, y, z]); c, s = np.cos(th), np.sin(th)
        R_des = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1.0]])
        q = np.array([0.0, -1.2, 1.6, -0.4, 0.0, 0.0])
        for _ in range(400):
            self.data.qpos[:] = q; mujoco.mj_kinematics(self.model, self.data); mujoco.mj_comPos(self.model, self.data)
            p, R = self._cam()
            ep = p_des - p; er = 0.5 * (np.cross(R[:, 0], R_des[:, 0]) + np.cross(R[:, 1], R_des[:, 1]) + np.cross(R[:, 2], R_des[:, 2]))
            if np.linalg.norm(ep) < 1e-5 and np.linalg.norm(er) < 1e-5: break
            mujoco.mj_jacSite(self.model, self.data, self.Jp, self.Jr, self.sid)
            Jf = np.vstack([self.Jp, self.Jr]); e = np.concatenate([ep, er])
            q = q + Jf.T @ np.linalg.solve(Jf @ Jf.T + 1e-4 * np.eye(6), e)
            lo, hi = self.model.jnt_range[:, 0], self.model.jnt_range[:, 1]; q = np.clip(q, lo, hi)
        return q

    def _rr(self, v4):
        """Resolved-rate: camera command (world vx, vy, vz, yaw rate) -> joint velocities."""
        p, R = self._cam()
        w_keep = 2.0 * np.cross(R[:, 2], np.array([0, 0, 1.0]))      # keep optical axis vertical
        tw = np.array([v4[0], v4[1], v4[2], w_keep[0], w_keep[1], v4[3]])
        mujoco.mj_jacSite(self.model, self.data, self.Jp, self.Jr, self.sid)
        Jf = np.vstack([self.Jp, self.Jr])
        qd = Jf.T @ np.linalg.solve(Jf @ Jf.T + 0.02 ** 2 * np.eye(6), tw)
        return np.clip(qd, -QD_MAX, QD_MAX)

    # ---------------------------------------------------------------- gym-like API
    def reset(self, difficulty=None):
        r = self.pose_range
        x0, y0 = self.rng.uniform(-r['xy'], r['xy']), self.rng.uniform(-r['xy'], r['xy'])
        z0, th0 = self.rng.uniform(*r['z']), self.rng.uniform(-r['th'], r['th'])
        if difficulty is not None: x0, y0, th0 = x0 * difficulty, y0 * difficulty, th0 * difficulty
        mujoco.mj_resetData(self.model, self.data)
        self.data.qpos[:] = self._ik((x0, y0, z0, th0)); self.data.qvel[:] = 0.0
        mujoco.mj_forward(self.model, self.data)
        self.target_xy = np.zeros(2); self.target_vel = self.rng.normal(0, self.target_drift_std, size=2)
        self.channel.reset(); self.t = 0; self.prev_action = np.zeros(4)
        self.queue = [np.zeros(4)] * self.latency
        self.pose = self._pose4()
        p, R = self._cam(); self.true_s, self.zc = project_full(p - T0, R, self.target_xy)
        self.s_pred = self.true_s.copy(); self.s_vel = np.zeros(8); self.cov_trace = 0.0
        from kf_util import kf_init
        kf_init(self, self.pixel_noise_std)
        if self.estimator == 'kf': self.cov_trace = 8 * self.P[0, 0]
        self._success_streak = 0; self.tilt = 0.0; self.sat = 0
        return self._obs(), {}

    def _obs(self):
        err = (self.s_pred - self.s_star) / IMG_HALF; vel = self.s_vel / IMG_HALF
        t_since = np.array([min(self.channel.steps_since_valid, 20) / 20.0]); cov = np.array([min(self.cov_trace, 400.0) / 400.0])
        return np.concatenate([err, vel, t_since, cov, self.prev_action]).astype(np.float32)

    def step(self, action):
        action = np.clip(action, -1, 1)
        self.queue.append(action.copy()); a_exec = self.queue.pop(0)
        v_cmd = a_exec * self.V_LIM
        for k in range(SUB):
            if k % 5 == 0:                                   # resolved-rate loop at 100 Hz, physics at 500 Hz
                self.data.ctrl[:] = self._rr(v_cmd)
            mujoco.mj_step(self.model, self.data)
        self.sat += int(np.any(np.abs(self.data.actuator_force) >= np.abs(self.model.actuator_forcerange[:, 1]) - 1e-6))
        self.pose = self._pose4()
        p, R = self._cam(); self.tilt = max(self.tilt, float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1)))))
        self.target_vel = np.clip(self.target_vel + self.rng.normal(0, self.target_drift_std * 0.3, size=2), -0.05, 0.05)
        self.target_xy = self.target_xy + self.target_vel * DT
        self.true_s, self.zc = project_full(p - T0, R, self.target_xy)
        visible = self.channel.step()
        if self.estimator == 'kf':
            from kf_util import kf_step
            z = self.true_s + self.rng.normal(0, self.pixel_noise_std, size=8) if visible else None
            kf_step(self, visible, z, DT, self.kf_q, self.pixel_noise_std)
        elif visible:
            noisy = self.true_s + self.rng.normal(0, self.pixel_noise_std, size=8)
            self.s_vel = 0.7 * self.s_vel + 0.3 * ((noisy - self.s_pred) / DT); self.s_pred = noisy; self.cov_trace = 5.0
        else:
            self.s_pred = self.s_pred + self.s_vel * DT
            self.cov_trace = self.cov_trace + 8.0 * (1 + 0.15 * self.channel.steps_since_valid)
        rmse = float(np.sqrt(np.mean((self.true_s - self.s_star) ** 2)))
        lost = bool(np.any(np.abs(self.true_s) > IMG_HALF * 1.6) or self.pose[2] <= 0.21 or self.pose[2] >= 1.19)
        self._success_streak = self._success_streak + 1 if rmse < SUCCESS_TOL else 0
        success = self._success_streak >= SUCCESS_HOLD
        self.prev_action = action.copy(); self.t += 1
        done = lost or success or self.t >= 100
        return self._obs(), 0.0, done, dict(rmse_true=rmse, visible=visible, lost=lost, success=success, pose=self.pose.copy())
