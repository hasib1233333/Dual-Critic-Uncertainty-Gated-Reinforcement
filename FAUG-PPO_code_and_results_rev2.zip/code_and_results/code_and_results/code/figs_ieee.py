"""
IEEE-style figures for the FAUG-PPO manuscript.
Grayscale + hatching, one muted accent (blue) reserved for the proposed method.
Single-column width 3.5 in, double-column width 7.16 in, 8-pt type.
Every number plotted is read from the JSON files in results/; nothing is typed in.
"""
import os, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, '..', 'results')
OUT = os.environ.get('FIGOUT', os.path.join(HERE, '..', '..', '..', 'paper_ieee'))
os.makedirs(OUT, exist_ok=True)
J = lambda f: json.load(open(os.path.join(RES, f)))

plt.rcParams.update({
    'font.family': 'serif', 'font.serif': ['Liberation Serif', 'Times New Roman', 'DejaVu Serif'],
    'mathtext.fontset': 'stix', 'font.size': 8, 'axes.labelsize': 8, 'axes.titlesize': 8,
    'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5, 'legend.fontsize': 7,
    'axes.linewidth': 0.6, 'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
    'lines.linewidth': 1.2, 'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': True, 'grid.color': '#D0D0D0', 'grid.linewidth': 0.4, 'grid.linestyle': ':',
    'legend.frameon': False, 'savefig.bbox': 'tight', 'savefig.pad_inches': 0.02,
    'hatch.linewidth': 0.5, 'figure.dpi': 200,
})
W1, W2 = 3.5, 7.16
BLUE = '#2B5C8A'

# style per controller: face, hatch, line style, label
S = {
    'no_fallback':  dict(fc='white',   h='....', ls=(0, (1, 1.5)), c='#9A9A9A', lab='IBVS, no fallback'),
    'ekf_fallback': dict(fc='#CFCFCF', h='',     ls=(0, (4, 1.5)), c='#8C8C8C', lab=r'IBVS + $\alpha\beta$ fallback'),
    'single_critic': dict(fc='#8F8F8F', h='////', ls=(0, (3, 1.5)), c='#5E5E5E', lab='Single-critic PPO'),
    'td3':          dict(fc='#3F3F3F', h='',     ls=(0, (5, 1.5, 1, 1.5)), c='#2E2E2E', lab='TD3'),
    'fixed':        dict(fc='#EDEDED', h='xxxx', ls=(0, (2, 2)), c='#7A7A7A', lab=r'Fixed $\alpha{=}0.5$'),
    'dcug':         dict(fc='white',   h='\\\\\\\\', ls=(0, (1, 1)), c='black', lab=r'DCUG-PPO ($\Delta V$ gate)'),
    'faug':         dict(fc=BLUE,      h='',     ls='-', c=BLUE, lab='FAUG-PPO (proposed)'),
}

ev = J('eval_results.json'); td3 = J('eval_td3.json'); fk = J('faug_eval_kinematic.json')
abl = J('ablation_expanded_n10.json'); xf = J('extra_faug.json'); xo = J('extra_data.json')
mjo = J('mujoco_transfer.json'); mjf = J('faug_eval_mujoco.json'); tde = J('td3_effort_timing.json')
DIFFS = ['mild', 'moderate', 'severe']


def seeds(name, d, key='success_rate'):
    if name == 'faug':
        return [x[key] for x in fk[d]]
    if name == 'td3':
        return [x[key] for x in td3[d][:3]]
    if name == 'dcug':
        return [x[key] for x in ev[d]['dcug_full']]
    if name == 'single_critic':
        return [x[key] for x in ev[d]['single_critic']]
    return [ev[d]['classical_' + ('no_fallback' if name == 'no_fallback' else 'ekf_fallback')][key]]


def bar(ax, x, h, name, w, err=None):
    st = S[name]
    if err is not None:  # asymmetric: never draw a whisker below zero
        hh, ee = np.atleast_1d(h).astype(float), np.atleast_1d(err).astype(float)
        err = np.vstack([np.minimum(ee, hh), ee])
    ax.bar(x, h, w, color=st['fc'], hatch=st['h'], edgecolor='black', linewidth=0.5,
           yerr=err, error_kw=dict(elinewidth=0.6, capsize=1.6, capthick=0.6), zorder=3)


def save(fig, name):
    fig.savefig(os.path.join(OUT, name))
    plt.close(fig)


# ------------------------------------------------------------------ main comparison
def fig_main():
    names = ['no_fallback', 'ekf_fallback', 'single_critic', 'td3', 'dcug', 'faug']
    fig, axes = plt.subplots(1, 2, figsize=(W2, 2.15))
    w = 0.13; xs = np.arange(3)
    for k, (ax, key, yl) in enumerate([(axes[0], 'success_rate', 'Success rate'),
                                       (axes[1], 'lost_rate', 'Target-loss rate')]):
        for i, n in enumerate(names):
            vals = [seeds(n, d, key) for d in DIFFS]
            m = [np.mean(v) for v in vals]
            e = [np.std(v, ddof=1) if len(v) > 1 else 0 for v in vals]
            bar(ax, xs + (i - 2.5) * w, m, n, w, err=e)
        ax.set_xticks(xs); ax.set_xticklabels(['Mild', 'Moderate', 'Severe'])
        ax.set_ylabel(yl); ax.set_title(f'({"ab"[k]}) {yl.lower()} vs. dropout severity')
        ax.set_axisbelow(True)
    axes[0].set_ylim(0, 1.08)
    h = [Patch(facecolor=S[n]['fc'], hatch=S[n]['h'], edgecolor='black', linewidth=0.5, label=S[n]['lab']) for n in names]
    fig.legend(handles=h, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.06), handlelength=1.6, columnspacing=1.1)
    fig.subplots_adjust(bottom=0.24, wspace=0.25)
    save(fig, 'ieee_main.pdf')


# ------------------------------------------------------------------ per-seed reliability
def fig_seeds():
    names = ['single_critic', 'dcug', 'td3', 'faug']
    fig, ax = plt.subplots(figsize=(W1, 2.1))
    rng = np.random.default_rng(0); w = 0.2; xs = np.arange(3)
    mk = {'single_critic': 's', 'dcug': 'D', 'td3': '^', 'faug': 'o'}
    for i, n in enumerate(names):
        for j, d in enumerate(DIFFS):
            v = np.array(seeds(n, d)); x0 = xs[j] + (i - 1.5) * w
            ax.plot([x0 - 0.08, x0 + 0.08], [v.mean()] * 2, color='black', lw=0.9, zorder=4)
            ax.scatter(x0 + rng.uniform(-0.05, 0.05, len(v)), v, s=9, marker=mk[n],
                       facecolor=S[n]['fc'] if n != 'dcug' else 'white', edgecolor='black', linewidth=0.45, zorder=5)
    ax.set_xticks(xs); ax.set_xticklabels(['Mild', 'Moderate', 'Severe'])
    ax.set_ylabel('Per-seed success rate'); ax.set_ylim(-0.04, 1.04)
    h = [Line2D([], [], ls='', marker=mk[n], mfc=(S[n]['fc'] if n != 'dcug' else 'white'), mec='black', mew=0.45,
                ms=4, label=S[n]['lab'] + (' (3 seeds)' if n == 'td3' else ' (10)')) for n in names]
    ax.legend(handles=h, loc='upper center', ncol=2, fontsize=6.3, bbox_to_anchor=(0.5, -0.13), handletextpad=0.2, columnspacing=0.8)
    ax.annotate('collapsed seed (all severities)', xy=(1 - 1.5 * w + 0.03, 0.0), xytext=(0.95, 0.28), fontsize=6.3,
                arrowprops=dict(arrowstyle='->', lw=0.5))
    save(fig, 'ieee_seeds.pdf')


# ------------------------------------------------------------------ training dynamics
def curve(runs, key, maxep):
    H = [np.array([[h['episode'], h[key]] for h in r['history'] if h['episode'] <= maxep]) for r in runs]
    n = min(len(h) for h in H); H = np.stack([h[:n] for h in H])
    return H[0, :, 0], H[:, :, 1].mean(0), H[:, :, 1].std(0, ddof=1)


def fig_training():
    runs = {'faug': J('train_abl_no_vdiff_n10.json'), 'dcug': J('train_dcug_full.json'),
            'fixed': J('train_abl_fixed_alpha_n10.json'), 'single_critic': J('train_single_critic.json'),
            'td3': [J(f'train_td3_seed{s}.json') for s in (1, 2, 3)]}
    fig, axes = plt.subplots(1, 2, figsize=(W2, 2.1))
    for k, (key, yl) in enumerate([('mean_return', 'Episodic return'), ('success_rate', 'Stochastic-rollout success')]):
        ax = axes[k]
        for n in ['single_critic', 'fixed', 'dcug', 'td3', 'faug']:
            ep, m, s = curve(runs[n], key, 2400)
            ax.plot(ep, m, color=S[n]['c'], ls=S[n]['ls'], lw=1.5 if n == 'faug' else 1.1,
                    label=S[n]['lab'] + (' (3)' if n == 'td3' else ' (10)'), zorder=4 if n == 'faug' else 3)
            ax.fill_between(ep, m - s, m + s, color=S[n]['c'], alpha=0.15 if n == 'faug' else 0.07, lw=0)
        ax.set_xlabel('Training episode'); ax.set_ylabel(yl + (' (200-ep window)' if k else ''))
        ax.set_title(f'({"ab"[k]}) {yl.lower()}'); ax.set_xlim(0, 2400)
    axes[1].set_ylim(0, 1.0)
    hh, ll = axes[1].get_legend_handles_labels()
    fig.legend(hh, ll, loc='lower center', ncol=5, bbox_to_anchor=(0.5, -0.07), handlelength=2.6, columnspacing=1.2)
    fig.subplots_adjust(wspace=0.27, bottom=0.25)
    save(fig, 'ieee_training.pdf')


# ------------------------------------------------------------------ component (ablation) study
def fig_ablation():
    tr = {'fixed': J('train_abl_fixed_alpha_n10.json'), 'faug': J('train_abl_no_vdiff_n10.json'),
          'dcug': J('train_dcug_full.json')}
    det = {'fixed': [e['success_rate'] for e in abl['abl_fixed_alpha_n10']],
           'faug': [e['success_rate'] for e in abl['abl_no_vdiff_n10']],
           'dcug': [e['success_rate'] for e in ev['moderate']['dcug_full']],
           'single_critic': [e['success_rate'] for e in ev['moderate']['single_critic']]}
    aucf = lambda runs: [np.mean([h['success_rate'] for h in r['history'] if h['episode'] <= 2400]) for r in runs]
    auc = {k: aucf(v) for k, v in tr.items()}
    auc['single_critic'] = aucf(J('train_single_critic.json'))
    order = ['single_critic', 'fixed', 'dcug', 'faug']
    labs = ['No fallback\n(single-critic)', r'Fallback,' '\n' r'fixed $\alpha$', r'Learned gate' '\n' r'$+\Delta V$ (DCUG)', 'Learned gate\n(FAUG)']
    fig, axes = plt.subplots(1, 2, figsize=(W2, 2.0))
    rng = np.random.default_rng(1)
    for k, (data, yl) in enumerate([(det, 'Deterministic success (moderate)'), (auc, 'Mean training success (AUC)')]):
        ax = axes[k]
        for i, n in enumerate(order):
            v = np.array(data[n])
            bar(ax, i, v.mean(), n, 0.6, err=v.std(ddof=1))
            ax.scatter(i + rng.uniform(-0.17, 0.17, len(v)), v, s=5, color='black', zorder=5, linewidth=0)
        ax.set_xticks(range(4)); ax.set_xticklabels(labs, fontsize=6.8)
        ax.set_ylabel(yl); ax.set_title(f'({"ab"[k]}) {"final deterministic policy" if k == 0 else "learning speed, episodes 0--2400"}')
        ax.set_ylim(0, 1.05 if k == 0 else 0.75); ax.set_axisbelow(True)
    fig.subplots_adjust(wspace=0.28)
    save(fig, 'ieee_ablation.pdf')


# ------------------------------------------------------------------ qualitative episode
def fig_qualitative():
    q = xo['qualitative']; qf = xf['qualitative_faug']
    fig, axes = plt.subplots(2, 1, figsize=(W1, 2.9), sharex=True, gridspec_kw=dict(height_ratios=[1.6, 1]))
    dt = 0.1
    vis = [s['visible'] for s in max([q['no_fallback'], q['ekf_fallback'], qf], key=len)]
    for ax in axes:
        t = 0
        for i, v in enumerate(vis):
            if not v:
                ax.axvspan(i * dt, (i + 1) * dt, color='#E6E6E6', lw=0, zorder=0)
    for n, tr in [('no_fallback', q['no_fallback']), ('ekf_fallback', q['ekf_fallback']),
                  ('single_critic', q['single_critic']), ('dcug', q['dcug_full']), ('faug', qf)]:
        r = [s['rmse'] for s in tr]
        axes[0].plot(np.arange(len(r)) * dt, r, color=S[n]['c'], ls=S[n]['ls'], lw=1.5 if n == 'faug' else 1.0, label=S[n]['lab'])
    axes[0].axhline(5.5, color='black', lw=0.6, ls='--'); axes[0].text(0.05, 6.2, 'success threshold', fontsize=6.3)
    axes[0].set_yscale('log'); axes[0].set_ylabel('Feature RMSE (px)')
    hh, ll = axes[0].get_legend_handles_labels()
    axes[0].set_title('(a) matched severe-dropout episode (shading: camera dropout)')
    a = [s['alpha'] for s in qf]
    axes[1].plot(np.arange(len(a)) * dt, a, color=BLUE, lw=1.4)
    axes[1].set_ylim(0, 1); axes[1].set_ylabel(r'Gate $\alpha_t$'); axes[1].set_xlabel('Time (s)')
    axes[1].set_title(r'(b) FAUG-PPO gate ($1$: policy, $0$: fallback)')
    fig.legend(hh, ll, loc='upper center', ncol=2, bbox_to_anchor=(0.53, -0.045), fontsize=6.3, handlelength=2.4, columnspacing=1.0)
    fig.subplots_adjust(hspace=0.38)
    save(fig, 'ieee_qualitative.pdf')


# ------------------------------------------------------------------ heatmap
def fig_heatmap():
    h = xf['heatmap']; F = np.array(h['faug']); E = np.array(h['ekf']); D = F - E
    pl, pr = h['p_lose_grid'], h['p_recover_grid']
    fig, axes = plt.subplots(1, 3, figsize=(W2, 2.05), gridspec_kw=dict(wspace=0.32))
    for ax, M, title, cm, vmin, vmax in [(axes[0], E, r'(a) IBVS + $\alpha\beta$ fallback', 'Greys', 0, 1),
                                         (axes[1], F, '(b) FAUG-PPO', 'Greys', 0, 1),
                                         (axes[2], D, '(c) difference (b) $-$ (a)', 'Greys', 0, 0.6)]:
        im = ax.imshow(M, cmap=cm, vmin=vmin, vmax=vmax, aspect='auto')
        for i in range(M.shape[0]):
            for j in range(M.shape[1]):
                val = M[i, j]; thr = 0.55 * (vmax - vmin) + vmin
                ax.text(j, i, f'{val:.2f}', ha='center', va='center', fontsize=6,
                        color='white' if val > thr else 'black')
        ax.set_xticks(range(len(pl))); ax.set_xticklabels([f'{v:.2f}' for v in pl], fontsize=6.5)
        ax.set_yticks(range(len(pr))); ax.set_yticklabels([f'{v:.2f}' for v in pr], fontsize=6.5)
        ax.set_xlabel(r'$p_{\mathrm{lose}}$'); ax.set_title(title); ax.grid(False)
        cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03); cb.ax.tick_params(labelsize=6)
    axes[0].set_ylabel(r'$p_{\mathrm{recover}}$')
    save(fig, 'ieee_heatmap.pdf')


# ------------------------------------------------------------------ effort / jerk
def fig_effort():
    names = ['no_fallback', 'ekf_fallback', 'single_critic', 'dcug', 'faug', 'td3']
    key = {'dcug': 'dcug_full'}
    ms = xf['faug_multiseed_effort_jerk']
    fig, axes = plt.subplots(1, 2, figsize=(W2, 1.95))
    for k, (m, yl) in enumerate([('effort', r'Effort $\langle\Vert\mathbf{a}_t\Vert^2\rangle$'),
                                 ('jerk', r'Jerk $\langle\Vert\mathbf{a}_t-\mathbf{a}_{t-1}\Vert^2\rangle$')]):
        ax = axes[k]
        for i, n in enumerate(names):
            if n == 'td3':
                v, e = tde[m], tde[m + '_std'] / np.sqrt(120)
            else:
                arr = np.array(xf[m][key.get(n, n)]); v, e = arr.mean(), arr.std(ddof=1) / np.sqrt(len(arr))
            bar(ax, i, v, n, 0.62, err=e)
        fv = [s[m] for s in ms]
        ax.errorbar(names.index('faug') + 0.43, np.mean(fv), yerr=np.std(fv, ddof=1), fmt='o', ms=2.6,
                    color=BLUE, mec='black', mew=0.4, elinewidth=0.7, capsize=1.6, zorder=6)
        ax.set_yscale('log'); ax.set_ylabel(yl)
        ax.set_xticks(range(len(names))); ax.set_xticklabels(['No fb.', r'$\alpha\beta$ fb.', 'SC-PPO', 'DCUG', 'FAUG', 'TD3'])
        ax.set_title(f'({"ab"[k]}) {m} (moderate, 120 episodes; error: s.e.m.)'); ax.set_axisbelow(True)
    fig.subplots_adjust(wspace=0.3)
    save(fig, 'ieee_effort.pdf')


# ------------------------------------------------------------------ cross-simulator transfer
def fig_transfer():
    names = ['ekf_fallback', 'single_critic', 'dcug', 'faug']
    fig, axes = plt.subplots(1, 2, figsize=(W2, 2.05), gridspec_kw=dict(width_ratios=[1.35, 1]))
    ax = axes[0]; w = 0.19; xs = np.arange(3)
    for i, n in enumerate(names):
        if n == 'ekf_fallback':
            m = [mjo[d]['classical_ekf_fallback'] for d in DIFFS]; e = None
        else:
            src = mjf if n == 'faug' else mjo; kk = 'dcug_full' if n == 'dcug' else n
            vals = [[x['success_rate'] for x in (src[d] if n == 'faug' else src[d][kk])] for d in DIFFS]
            m = [np.mean(v) for v in vals]; e = [np.std(v, ddof=1) for v in vals]
        bar(ax, xs + (i - 1.5) * w, m, n, w, err=e)
    ax.set_xticks(xs); ax.set_xticklabels(['Mild', 'Moderate', 'Severe']); ax.set_ylim(0, 1.08)
    ax.set_ylabel('Success rate'); ax.set_title('(a) zero-shot MuJoCo rigid-body dynamics (10 seeds)'); ax.set_axisbelow(True)
    h = [Patch(facecolor=S[n]['fc'], hatch=S[n]['h'], edgecolor='black', linewidth=0.5, label=S[n]['lab']) for n in names]
    fig.legend(handles=h, loc='lower center', ncol=4, bbox_to_anchor=(0.5, -0.06), handlelength=1.6)
    # (b) fidelity tiers at the moderate preset
    ax = axes[1]
    tiers = ['Kinematic', 'MuJoCo', 'Rendered\n(OpenCV)']
    rif = os.path.join(RES, 'faug_eval_realimage.json')
    ri_ok = os.path.exists(rif) and abs(J('faug_eval_realimage.json')['reproduction_check']['classical_ab_fallback_strict'] - 0.6333) < 0.01
    rio = J('realimage_transfer.json')
    data = {
        'ekf_fallback': [ev['moderate']['classical_ekf_fallback']['success_rate'], mjo['moderate']['classical_ekf_fallback'],
                         rio['classical_ekf_fallback']['success_rate']],
        'dcug': [np.mean(seeds('dcug', 'moderate')), np.mean([x['success_rate'] for x in mjo['moderate']['dcug_full']]),
                 np.mean([x['success_rate'] for x in rio['dcug_full']])],
        'faug': [np.mean(seeds('faug', 'moderate')), np.mean([x['success_rate'] for x in mjf['moderate']]),
                 np.mean([x['success_rate'] for x in J('faug_eval_realimage.json')['strict']]) if ri_ok else np.nan],
    }
    w = 0.25
    for i, n in enumerate(['ekf_fallback', 'dcug', 'faug']):
        bar(ax, np.arange(3) + (i - 1) * w, data[n], n, w)
    if not ri_ok:
        ax.text(2 + w, 0.05, 'n/a', ha='center', fontsize=6.5, rotation=90)
    ax.set_xticks(range(3)); ax.set_xticklabels(tiers); ax.set_ylim(0, 1.08)
    ax.set_title('(b) moderate preset across fidelity tiers'); ax.set_axisbelow(True)
    fig.subplots_adjust(wspace=0.22, bottom=0.2)
    save(fig, 'ieee_transfer.pdf')


# ------------------------------------------------------------------ robustness (single seed)
def fig_robust():
    nz = xf['noise_robustness']; ds = xf['distance_sensitivity']; dist = xf['disturbance']
    fig, axes = plt.subplots(1, 3, figsize=(W2, 1.95), gridspec_kw=dict(wspace=0.33))
    ax = axes[0]
    for n, k in [('ekf_fallback', 'ekf_fallback'), ('single_critic', 'single_critic'), ('dcug', 'dcug_full'), ('faug', 'faug')]:
        ax.plot(nz['noise_levels'], nz[k], color=S[n]['c'], ls=S[n]['ls'], marker='o', ms=2.4, lw=1.4 if n == 'faug' else 1.0, label=S[n]['lab'])
    ax.axvline(0.5, color='black', lw=0.5, ls=':'); ax.text(0.58, 0.615, 'training $\\sigma$', fontsize=6)
    ax.set_xlabel(r'Pixel noise $\sigma$ (px)'); ax.set_ylabel('Success rate'); ax.set_ylim(0.6, 1.02)
    ax.set_title('(a) measurement noise')
    ax = axes[1]; w = 0.2
    for i, n in enumerate(['no_fallback', 'ekf_fallback', 'single_critic', 'faug']):
        bar(ax, np.arange(3) + (i - 1.5) * w, [ds[s][n] for s in ['near', 'medium', 'far']], n, w)
    ax.set_xticks(range(3)); ax.set_xticklabels(['Near', 'Medium', 'Far']); ax.set_ylim(0, 1.05)
    ax.set_title('(b) initial-pose displacement'); ax.set_axisbelow(True)
    ax = axes[2]; dt = 0.1
    for n, k in [('ekf_fallback', 'ekf_fallback'), ('single_critic', 'single_critic'), ('faug', 'faug')]:
        r = [s['rmse'] for s in dist[k]]
        ax.plot(np.arange(len(r)) * dt, r, color=S[n]['c'], ls=S[n]['ls'], lw=1.4 if n == 'faug' else 1.0, label=S[n]['lab'])
    ax.axvline(dist['jump_step'] * dt, color='black', lw=0.6, ls='--')
    ax.text(dist['jump_step'] * dt + 0.15, 40, 'target step', fontsize=6)
    ax.axhline(5.5, color='black', lw=0.5, ls=':')
    ax.set_xlabel('Time (s)'); ax.set_ylabel('Feature RMSE (px)'); ax.set_title('(c) target-step disturbance')
    from matplotlib.legend_handler import HandlerTuple
    hs, ls_ = [], []
    for n in ['no_fallback', 'ekf_fallback', 'single_critic', 'dcug', 'faug']:
        hs.append((Patch(facecolor=S[n]['fc'], hatch=S[n]['h'], edgecolor='black', linewidth=0.5),
                   Line2D([], [], color=S[n]['c'], ls=S[n]['ls'], lw=1.3 if n == 'faug' else 1.0)))
        ls_.append(S[n]['lab'])
    fig.legend(hs, ls_, handler_map={tuple: HandlerTuple(ndivide=None, pad=0.4)}, loc='lower center', ncol=5,
               bbox_to_anchor=(0.5, -0.08), handlelength=3.2, columnspacing=1.2)
    fig.subplots_adjust(bottom=0.24)
    save(fig, 'ieee_robust.pdf')


# ------------------------------------------------------------------ gate response (all 10 seeds)
def fig_gate():
    g = J('faug_gate_analysis.json')
    bins = g['alpha_by_tau_bin']
    labs = ['0\n(visible)', '1', '2-3', '4-6', '7-10', '11-20']
    fig, axes = plt.subplots(1, 2, figsize=(W2, 1.95), gridspec_kw=dict(width_ratios=[1.3, 1], wspace=0.3))
    ax = axes[0]
    m = [b['mean'] for b in bins]; sd = [b['sd'] for b in bins]; x = np.arange(len(bins))
    ax.fill_between(x, np.array(m) - np.array(sd), np.array(m) + np.array(sd), color=BLUE, alpha=0.15, lw=0)
    ax.plot(x, m, color=BLUE, marker='o', ms=3, lw=1.4)
    for i, b in enumerate(bins):
        ax.text(i, m[i] + sd[i] + 0.012, f"n={b['n']}", ha='center', fontsize=5.6, color='#555555')
    ax.set_xticks(x); ax.set_xticklabels(labs); ax.set_xlabel(r'Dropout age $\tau_t$ (control steps since last valid frame)')
    ax.set_ylabel(r'Gate $\alpha_t$ (mean $\pm$ s.d.)'); ax.set_ylim(0.05, 0.48); ax.set_xlim(-0.45, 5.35)
    ax.set_title('(a) gate vs. dropout age, 10 seeds pooled')
    ax = axes[1]
    ps = g['per_seed']
    ax.scatter([p['spearman_alpha_tau'] for p in ps], [p['spearman_alpha_zeta'] for p in ps], s=14, color=BLUE,
               edgecolor='black', linewidth=0.4, zorder=5)
    for p in ps:
        ax.annotate(str(p['seed']), (p['spearman_alpha_tau'], p['spearman_alpha_zeta']), xytext=(2.5, 1.5),
                    textcoords='offset points', fontsize=5.6)
    ax.plot([-0.6, 0.0], [-0.6, 0.0], color='#AAAAAA', lw=0.5, ls=':')
    ax.axvline(0, color='black', lw=0.5); ax.axhline(0, color='black', lw=0.5)
    ax.set_xlim(-0.6, 0.05); ax.set_ylim(-0.6, 0.05)
    ax.set_xlabel(r'Spearman $\rho(\alpha_t,\tau_t)$'); ax.set_ylabel(r'Spearman $\rho(\alpha_t,\zeta_t)$')
    ax.set_title('(b) per-seed rank correlation')
    save(fig, 'ieee_gate.pdf')


if __name__ == '__main__':
    for f in [fig_main, fig_seeds, fig_training, fig_ablation, fig_qualitative, fig_heatmap, fig_effort, fig_transfer, fig_robust, fig_gate]:
        f(); print('ok', f.__name__)
