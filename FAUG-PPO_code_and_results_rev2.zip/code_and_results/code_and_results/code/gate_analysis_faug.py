"""Gate-response analysis for FAUG-PPO across all 10 seeds (moderate preset).
Records alpha_t against dropout age tau (steps since last valid frame) and the
filter-uncertainty proxy zeta; also the pre-clip bound-exceedance rate of
sampled (stochastic) actions. Output: results/faug_gate_analysis.json"""
import json, numpy as np
from scipy import stats
from train import make_env
from controllers import fallback_action
from eval_faug import load_faug, RESULTS

out = {'per_seed': []}
bins = [0, 1, 2, 4, 7, 11, 21]          # tau bins (steps): 0 = visible
pooled = {b: [] for b in range(len(bins) - 1)}
for sd in range(1, 11):
    ag = load_faug(sd); env = make_env(seed=2024, difficulty='moderate')
    A, T, Z = [], [], []
    for _ in range(60):
        obs, _ = env.reset(); done = False
        while not done:
            act, *_, alpha = ag.act(obs, a_safe_np=fallback_action(env), sample=False)
            A.append(alpha); T.append(env.channel.steps_since_valid); Z.append(env.cov_trace)
            obs, r, done, info = env.step(act)
    A, T, Z = map(np.array, (A, T, Z))
    rho_t = stats.spearmanr(A, T).correlation; rho_z = stats.spearmanr(A, Z).correlation
    vis = A[T == 0].mean(); drp = A[T > 0].mean()
    for b in range(len(bins) - 1):
        m = (T >= bins[b]) & (T < bins[b + 1]); pooled[b] += list(A[m])
    # stochastic actions: pre-clip exceedance
    env = make_env(seed=7, difficulty='moderate'); n = exc = 0; mx = 0.0
    for _ in range(10):
        obs, _ = env.reset(); done = False
        while not done:
            a, *_ = ag.act(obs, a_safe_np=fallback_action(env), sample=True)
            n += 1; e = np.max(np.abs(a)) - 1.0
            if e > 0: exc += 1; mx = max(mx, e)
            obs, r, done, info = env.step(a)
    out['per_seed'].append(dict(seed=sd, n_steps=int(len(A)), alpha_visible=float(vis), alpha_dropout=float(drp),
                                spearman_alpha_tau=float(rho_t), spearman_alpha_zeta=float(rho_z),
                                preclip_exceed_frac=exc / n, preclip_max_excess=float(mx), preclip_steps=n))
    print(out['per_seed'][-1], flush=True)
out['alpha_by_tau_bin'] = [dict(tau_lo=bins[b], tau_hi=bins[b + 1] - 1, n=len(v), mean=float(np.mean(v)) if v else None,
                                 sd=float(np.std(v)) if v else None) for b, v in pooled.items()]
json.dump(out, open(f'{RESULTS}/faug_gate_analysis.json', 'w'), indent=1)
print(out['alpha_by_tau_bin'])
