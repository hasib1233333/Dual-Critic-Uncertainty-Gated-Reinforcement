"""Generate LaTeX table rows for revision 2 directly from the result JSON files (no hand-typed numbers).
Usage: python make_tables_v3.py [arm|stress|tiers|effort|real|factorial|budget ...]  -> prints rows; also writes paper_cee/tab_*.tex"""
import json, os, sys, glob, numpy as np
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results')
OUT = '/home/claude/project/paper_cee'
J = lambda f: json.load(open(os.path.join(R, f))) if os.path.exists(os.path.join(R, f)) else {}
LAB = {'classical_ab': r'IBVS + $\alpha\beta$', 'classical_kf': 'IBVS + Kalman', 'sc_3k': 'PPO', 'resid': 'Residual PPO',
       'fixed': r'Fixed $\alpha=0.5$', 'dcug_3k': 'DCUG-PPO', 'faug_sc': r'FAUG-PPO ($\alpha\beta$)', 'sac': 'SAC', 'td3': 'TD3',
       'td3_smooth': 'TD3-smooth', 'faug_kf': 'FAUG-PPO (KF), no cap', 'faug_kf_rm': 'FAUG-PPO (KF, real-data), no cap',
       'faug_kf_rm@cov3a03': 'FAUG-PPO (KF, real-data) + cap', 'faug_kf@cov3a03': r'\textbf{FAUG-PPO (KF) + cap}',
       'kf_fixed': r'KF + fixed $\alpha=0.5$', 'kf_fixed@cov3a03': r'KF + fixed $\alpha=0.5$ + cap',
       'kf_age': 'KF + gate (age only)', 'kf_cov': 'KF + gate (covariance only)', 'kf_none': 'KF + gate (no uncertainty input)',
       'kf_proxy': 'KF + gate (heuristic proxy)', 'ab_kfcov': r'$\alpha\beta$ + gate (KF covariance)'}
ORDER = ['classical_ab', 'classical_kf', 'sc_3k', 'resid', 'fixed', 'dcug_3k', 'faug_sc', 'sac', 'td3', 'td3_smooth',
         'faug_kf', 'faug_kf_rm', 'faug_kf_rm@cov3a03', 'faug_kf@cov3a03']


def cell(runs, key='success_rate', sd=True, scale=100, fmt='%.1f'):
    v = np.array([r[key] for r in runs]) * scale
    if len(v) > 1 and sd: return f'${fmt % v.mean()}\\pm{fmt % v.std(ddof=1)}$'
    return fmt % v.mean()


def rows(d, conds, extra_loss=None, names=None):
    out = []
    for n in (names or ORDER):
        if n not in d: continue
        c = [cell(d[n][k]) for k in conds]
        if extra_loss: c.append(cell(d[n][extra_loss], 'lost_rate', sd=False))
        seeds = len(d[n][conds[0]])
        out.append(f"{LAB.get(n, n)} & {'--' if n.startswith('classical') else seeds} & " + ' & '.join(c) + r' \\')
    return out


def t_arm():
    d = J('v3_arm.json'); r = rows(d, ['moderate', 'severe', 'severe_lat200'], extra_loss='severe')
    return r


def t_stress():
    d = J('v3_stress.json')
    return rows(d, ['lat200', 'lat300', 'motion_dropout', 'long_burst', 'actuator50', 'noise2px'])


def t_tiers():
    d = J('v3_tiers.json')
    return rows(d, ['kin|mild', 'kin|moderate', 'kin|severe', 'replay|1|severe', 'replay|3|severe']) + ['% mujoco'] + \
        rows(d, ['mujoco|mild', 'mujoco|moderate', 'mujoco|severe']) if any('mujoco|severe' in v for v in d.values()) else \
        rows(d, ['kin|mild', 'kin|moderate', 'kin|severe', 'replay|1|severe', 'replay|3|severe'])


def t_effort():
    d = J('v3_effort.json'); out = []
    for n in ORDER:
        if n not in d: continue
        rs = d[n]['moderate']
        e = np.array([r['effort'] for r in rs]); a = np.array([r['action_rate'] for r in rs]); j = np.array([r['jerk_rms'] for r in rs])
        cl = [r['stoch_clip_frac'] for r in rs if r['stoch_clip_frac'] is not None]
        f = lambda x: '$%.2f\\times10^{%d}$' % (x / 10 ** np.floor(np.log10(x)), np.floor(np.log10(x)))
        out.append(f"{LAB.get(n, n)} & {f(e.mean())} & {f(a.mean())} & {j.mean():.2f} & " + (('%.2f\\%%' % (100 * np.mean(cl))) if cl else '--') + r' \\')
    return out


def t_real():
    d = J('v3_real.json'); return rows(d, ['strict', 'lenient'])


def t_factorial():
    k = J('v3_tiers.json'); h = J('v3_heldout.json'); out = []
    for n in ['faug_sc', 'ab_kfcov', 'kf_proxy', 'kf_none', 'kf_age', 'kf_cov', 'faug_kf', 'kf_fixed', 'kf_fixed@cov3a03', 'faug_kf@cov3a03']:
        if n not in k: continue
        hs = [x for x in h.get(n, {}) if x.endswith('severe')]
        hv = (np.mean([[r['success_rate'] for r in h[n][x]] for x in hs], 0) * 100) if hs else None
        out.append(f"{LAB.get(n, n)} & {len(k[n]['kin|severe'])} & {cell(k[n]['kin|moderate'])} & {cell(k[n]['kin|severe'])} & "
                   f"{cell(k[n]['replay|1|severe'])} & " + (f'${hv.mean():.1f}\\pm{hv.std(ddof=1):.1f}$' if hv is not None else '--') + r' \\')
    return out


def _kin(n):
    """kinematic-tier runs per preset: capped controllers from v3_tiers, all others from v2_kin (same CRN episodes)."""
    if '@' in n: return {p: J('v3_tiers.json')[n][f'kin|{p}'] for p in ['mild', 'moderate', 'severe']}
    K = J('v2_kin.json')
    if n.startswith('classical'): e = n.split('_')[1]; return {p: [K['classical'][e][p]] for p in ['mild', 'moderate', 'severe']}
    return K[n]


MAIN = ['classical_ab', 'classical_kf', 'sc_3k', 'resid', 'fixed', 'dcug_3k', 'sac', 'td3', 'td3_smooth', 'faug_sc', 'faug_kf', 'faug_kf@cov3a03']
MLAB = dict(LAB, faug_kf='FAUG-PPO (KF), no cap', classical_ab=r'IBVS + $\alpha\beta$ predictor', classical_kf='IBVS + Kalman predictor',
            dcug_3k='DCUG-PPO (earlier design)', **{'faug_kf@cov3a03': r'\textbf{FAUG-PPO (KF) + cap (proposed)}'})


def t_main():
    out = []
    for n in MAIN:
        d = _kin(n); c = []
        for p in ['mild', 'moderate', 'severe']:
            c += [cell(d[p]), cell(d[p], 'lost_rate', sd=False)]
        out.append(f"{MLAB.get(n, n)} & {'--' if n.startswith('classical') else len(d['mild'])} & " + ' & '.join(c) + r' \\')
    return out


def t_heldout():
    H = J('v3_heldout.json'); out = []
    conds = [('mbt-cube', 1), ('mbt-cube', 3), ('cube', 1), ('cube', 3), ('ellipse-1', 1), ('ellipse-1', 3)]
    for n in ['classical_ab', 'classical_kf', 'sc_3k', 'resid', 'fixed', 'dcug_3k', 'faug_sc', 'sac', 'td3', 'td3_smooth', 'faug_kf', 'faug_kf_rm', 'faug_kf_rm@cov3a03', 'faug_kf@cov3a03']:
        if n not in H: continue
        per = ['%.0f' % (100 * np.mean([r['success_rate'] for r in H[n][f'{s}|{k}|severe']])) for s, k in conds]
        sev = [k for k in H[n] if k.endswith('severe')]; mod = [k for k in H[n] if k.endswith('moderate')]
        v = np.mean([[r['success_rate'] for r in H[n][k]] for k in sev], 0) * 100
        L = np.mean([[r['lost_rate'] for r in H[n][k]] for k in sev]) * 100
        m = np.mean([[r['success_rate'] for r in H[n][k]] for k in mod]) * 100
        sv = f'${v.mean():.1f}\\pm{v.std(ddof=1):.1f}$' if len(v) > 1 else f'{v.mean():.1f}'
        lab = LAB.get(n, n) + (f' ({len(v)} seeds)' if n == 'td3' else '')
        out.append(f"{lab} & " + ' & '.join(per) + f" & {sv} & {L:.1f} & {m:.1f} \\\\")
    return out


def t_transfer():
    M = J('v2_mujoco.json'); T = J('v3_tiers.json'); RR = J('v2_real.json'); R3 = J('v3_real.json'); out = []
    for n in ['classical_ab', 'classical_kf', 'sc_3k', 'resid', 'dcug_3k', 'faug_sc', 'faug_kf', 'faug_kf@cov3a03', 'sac', 'td3', 'td3_smooth']:
        if n.startswith('classical'):
            e = n.split('_')[1]; mj = ['%.1f' % (100 * M['classical'][e][p]['success_rate']) for p in ['mild', 'moderate', 'severe']]
            k = '' if e == 'ab' else '_kf'; rd = ['%.1f' % (100 * RR['classical'][m + k]['success_rate']) for m in ['strict', 'lenient']]
        else:
            src = (lambda p: T[n][f'mujoco|{p}']) if '@' in n else (lambda p: M[n][p])
            mj = [cell(src(p)) for p in ['mild', 'moderate', 'severe']]
            if n in R3: rd = [cell(R3[n][m]) for m in ['strict', 'lenient']]
            elif n in RR: rd = [cell(RR[n][m]) for m in ['strict', 'lenient']]
            else: rd = ['--', '--']
        lab = LAB.get(n, n) + (f' ({len(M[n]["mild"])} seeds)' if n in ('sac', 'td3', 'td3_smooth') else '')
        out.append(f"{lab} & " + ' & '.join(mj + rd) + r' \\')
    return out


def t_replay():
    P = J('v2_replay.json'); T = J('v3_tiers.json'); out = []
    for n in ['classical_ab', 'classical_kf', 'sc_3k', 'resid', 'fixed', 'dcug_3k', 'sac', 'td3', 'td3_smooth', 'faug_sc', 'faug_kf', 'faug_kf@cov3a03']:
        c = []
        for sp, k in [('real', 1), ('stress', 3)]:
            for pre in ['moderate', 'severe']:
                if n.startswith('classical'):
                    r = P['classical'][f'{sp}_{pre}'][n.split('_')[1]]; v = '%.0f' % (100 * r['success_rate'])
                    if pre == 'severe': v += ' (%.0f)' % (100 * r['lost_rate'])
                else:
                    runs = T[n][f'replay|{k}|{pre}'] if '@' in n else P[n][f'{sp}_{pre}']
                    v = cell(runs) + ((' (%.1f)' % (100 * np.mean([r['lost_rate'] for r in runs]))) if pre == 'severe' else '')
                c.append(v)
        lab = LAB.get(n, n) + (r'$^\dagger$' if '@' in n else '')
        out.append(f"{lab} & " + ' & '.join(c) + r' \\')
    return out


def t_budget():
    out = []
    spec = [('sc_3k', 'PPO'), ('resid', 'Residual PPO'), ('dcug_3k', 'DCUG-PPO'), ('faug_sc', r'FAUG-PPO ($\alpha\beta$)'),
            ('faug_kf', 'FAUG-PPO (KF)'), ('faug_kf_rm', 'FAUG-PPO (KF, real-data)'), ('kf_fixed', r'KF + fixed $\alpha=0.5$'),
            ('kf_fixed_rm', r'KF + fixed $\alpha=0.5$ (real-data)'), ('kf_age', 'KF + gate variants (4 types)'),
            ('ab_kfcov', r'$\alpha\beta$ + gate (KF covariance)'), ('sac', 'SAC'), ('td3', 'TD3'), ('td3_smooth', 'TD3-smooth')]
    for name, lab in spec:
        names = ['kf_age', 'kf_cov', 'kf_none', 'kf_proxy'] if name == 'kf_age' else [name]
        R_ = [json.load(open(f)) for n in names for f in glob.glob(f'{R}/train_v2_{n}_seed*.json')]
        if not R_: continue
        ep = '1200' if name in ('sac', 'td3', 'td3_smooth') else '3000'
        sd = f'{len(R_) // len(names)}' + (r'$\times$4' if len(names) > 1 else '')
        f = lambda x: f'{x:,.0f}'.replace(',', '{,}')
        out.append(f"{lab} & {sd} & {ep} & {f(np.mean([r['env_steps'] for r in R_]))} & {f(np.mean([r['grad_updates'] for r in R_]))} \\\\")
    return out


if __name__ == '__main__':
    for t in (sys.argv[1:] or ['arm', 'stress', 'tiers', 'effort', 'real', 'factorial']):
        r = globals()['t_' + t]()
        print(f'--- {t}'); print('\n'.join(r))
        open(os.path.join(OUT, f'tab_{t}.tex'), 'w').write('\n'.join(r) + '\n')
