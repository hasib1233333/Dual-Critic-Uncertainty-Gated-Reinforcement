"""
Budget-matched, properly-powered ablation re-run.

The original ablation (abl_fixed_alpha, abl_no_vdiff) used only 2 seeds at
2500 episodes, versus 10 seeds at 3000 episodes for dcug_full/single_critic.
This script retrains BOTH ablation variants for all 10 seeds at 3000
episodes (matching the main comparison's budget exactly), evaluates each at
the moderate preset with the same 300-episode protocol used for Table 4,
and writes results to new files (originals are left untouched for audit).
"""
import json
import time
import numpy as np
import torch

from train import make_env, collect_and_train
from ppo import Agent
from controllers import fallback_action

RESULTS = '/home/claude/project/code_and_results/code_and_results/results'
MODELS = '/home/claude/project/code_and_results/code_and_results/models_expanded'

import os
os.makedirs(MODELS, exist_ok=True)

SEEDS = list(range(1, 11))
TRAIN_EPISODES = 3000  # budget-matched to dcug_full / single_critic
TRAIN_DIFFICULTY = 'moderate'
EVAL_EPISODES = 300
EVAL_SEED = 999

VARIANTS = {
    'abl_fixed_alpha_n10': dict(dual=True, kwargs=dict(fixed_alpha=0.5)),
    'abl_no_vdiff_n10':    dict(dual=True, kwargs=dict(use_vdiff=False)),
}


def set_seed(s):
    np.random.seed(s)
    torch.manual_seed(s)


def train_one(name, dual, seed, episodes, **agent_kwargs):
    set_seed(seed)
    env = make_env(seed=seed, difficulty=TRAIN_DIFFICULTY)
    agent = Agent(env.obs_dim, env.act_dim, dual=dual, **agent_kwargs)
    t0 = time.time()
    hist, raw = collect_and_train(agent, env, total_episodes=episodes,
                                   episodes_per_update=16, log_every=200, verbose=False)
    dt = time.time() - t0
    print(f'--- {name} seed={seed} done in {dt:.1f}s, final success={hist[-1]["success_rate"]:.2f} ---', flush=True)
    torch.save({'actor': agent.actor.state_dict(), 'v_opt': agent.v_opt.state_dict(),
                'v_pess': agent.v_pess.state_dict() if dual else None},
               f'{MODELS}/{name}_seed{seed}.pt')
    return dict(seed=seed, history=hist, elapsed=dt)


def eval_agent(agent, difficulty, n, seed, record_raw=True):
    env = make_env(seed=seed, difficulty=difficulty)
    succ, lost, rmse, rets = [], [], [], []
    for i in range(n):
        obs, _ = env.reset()
        done = False
        ep_ret = 0.0
        while not done:
            a_safe = fallback_action(env) if agent.dual else np.zeros(4, dtype=np.float32)
            act, logp, vopt, vpess, alpha = agent.act(obs, a_safe_np=a_safe, sample=False)
            obs, rew, done, info = env.step(act)
            ep_ret += rew
        succ.append(float(info['success'])); lost.append(float(info['lost']))
        rmse.append(info['rmse_true']); rets.append(ep_ret)
    out = dict(success_rate=float(np.mean(succ)), lost_rate=float(np.mean(lost)),
               mean_rmse=float(np.mean(rmse)), mean_return=float(np.mean(rets)),
               success_std=float(np.std(succ, ddof=1)) if len(succ) > 1 else 0.0)
    if record_raw:
        out['raw_success'] = succ
    return out


def main():
    t_start = time.time()
    all_results = {}
    for name, cfg in VARIANTS.items():
        print(f'=== variant {name} ===', flush=True)
        train_hist = []
        eval_list = []
        for sd in SEEDS:
            train_hist.append(train_one(name, cfg['dual'], sd, TRAIN_EPISODES, **cfg['kwargs']))
            with open(f'{RESULTS}/train_{name}.json', 'w') as f:
                json.dump(train_hist, f)

            env_dummy = make_env(seed=0, difficulty='moderate')
            agent = Agent(env_dummy.obs_dim, env_dummy.act_dim, dual=cfg['dual'], **cfg['kwargs'])
            ckpt = torch.load(f'{MODELS}/{name}_seed{sd}.pt', weights_only=True)
            agent.actor.load_state_dict(ckpt['actor'])
            agent.v_opt.load_state_dict(ckpt['v_opt'])
            if cfg['dual'] and ckpt['v_pess'] is not None:
                agent.v_pess.load_state_dict(ckpt['v_pess'])

            ev = eval_agent(agent, 'moderate', EVAL_EPISODES, EVAL_SEED)
            ev['seed'] = sd
            eval_list.append(ev)
            print(f'    eval seed={sd}: success={ev["success_rate"]:.4f}', flush=True)

            with open(f'{RESULTS}/eval_{name}.json', 'w') as f:
                json.dump(eval_list, f, indent=2)

        all_results[name] = eval_list

    with open(f'{RESULTS}/ablation_expanded_n10.json', 'w') as f:
        json.dump(all_results, f, indent=2)

    print(f'=== ALL DONE in {time.time()-t_start:.1f}s ===', flush=True)


if __name__ == '__main__':
    main()
