"""
Evaluation for the C&EE revision (all models retrained at matched budgets).
Usage: python eval_v2.py MODE [NAMES...]
  MODE kin     : kinematic tier, 3 presets x 300 episodes per seed (+ classical alpha-beta and KF fallbacks)
  MODE mujoco  : MuJoCo tier, 3 presets x 100 episodes per seed
  MODE real    : rendered-image tier (fixed pipeline), 5 seeds x 30 episodes, strict and lenient
  MODE replay  : real-motion replay (ViSP mire-2), 3 presets x 100 episodes per seed, sigma in {real, 0.5}
  MODE effort  : effort / jerk / convergence, 120 episodes per seed, all seeds
  MODE gate    : gate-response analysis for gated models
Outputs: results/v2_<mode>.json (merged per name; reruns overwrite only the named entries).
"""
import os, sys, json, time
os.environ.setdefault('MUJOCO_GL', 'osmesa'); os.environ.setdefault('PYOPENGL_PLATFORM', 'osmesa')
import numpy as np, torch
import torch._dynamo  # noqa: must load before mujoco
torch.set_num_threads(1)
from train import make_env
from ppo import Agent
from td3 import TD3Actor
from sac import SACActor
from controllers import fallback_action, classical_ibvs_action

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, '..', 'results'); MOD = os.path.join(HERE, '..', 'models_v2')
PRESETS = {'mild': (0.04, 0.25), 'moderate': (0.08, 0.18), 'severe': (0.14, 0.12)}
PPO_NAMES = ['faug_sc', 'sc_3k', 'dcug_3k', 'resid', 'faug_kf']
OFF_NAMES = ['sac', 'td3_smooth', 'td3']
ENV_KW = {'faug_kf': dict(estimator='kf')}
BASE = {'kin': dict(mild=1_000_000, moderate=2_000_000, severe=3_000_000),
        'mujoco': dict(mild=4_000_000, moderate=5_000_000, severe=6_000_000), 'real': 9_000_000,
        'replay': dict(mild=11_000_000, moderate=12_000_000, severe=13_000_000)}


class OffPolicyWrap:
    dual = False; uses_fallback = False
    def __init__(self, actor, kind): self.actor, self.kind = actor, kind
    def act(self, o, a_safe_np=None, sample=False):
        with torch.no_grad():
            x = torch.as_tensor(o, dtype=torch.float32).unsqueeze(0)
            a = self.actor(x, deterministic=True)[0] if self.kind == 'sac' else self.actor(x)
        return a.squeeze(0).numpy(), 0.0, 0.0, 0.0, 1.0


def load(name, seed):
    if name in OFF_NAMES:
        ck = torch.load(f'{MOD}/{name}_seed{seed}.pt', weights_only=False)
        actor = SACActor(22, 4) if name == 'sac' else TD3Actor(22, 4)
        actor.load_state_dict(ck['actor']); actor.eval()
        return OffPolicyWrap(actor, 'sac' if name == 'sac' else 'td3')
    if name == 'fixed':
        ck = torch.load(os.path.join(HERE, '..', 'models_expanded', f'abl_fixed_alpha_n10_seed{seed}.pt'), weights_only=True)
        ag = Agent(22, 4, dual=True, fixed_alpha=0.5)
    else:
        ck = torch.load(f'{MOD}/{name}_seed{seed}.pt', weights_only=False)
        ag = Agent(22, 4, **ck['cfg'][0])
    ag.actor.load_state_dict(ck['actor']); ag.v_opt.load_state_dict(ck['v_opt'])
    if ag.v_pess is not None and ck.get('v_pess') is not None:
        ag.v_pess.load_state_dict(ck['v_pess'])
    return ag


def seeds_of(name):
    if name in OFF_NAMES:   # all trained off-policy seeds present on disk (3 in revision 1, up to 10 in revision 2)
        return [s for s in range(1, 11) if os.path.exists(f'{MOD}/{name}_seed{s}.pt')]
    return list(range(1, 11))


def crn(env, key):
    """Common random numbers: episode `key` gets an identical initial pose, target motion,
    noise and dropout realization for every controller (env and channel share one RNG)."""
    env.rng = np.random.default_rng(int(key)); env.channel.rng = env.rng


def episode(env, ag, record=False, key=None):
    if key is not None:
        crn(env, key)
    o, _ = env.reset(); done = False; tr = []
    while not done:
        a_s = fallback_action(env) if getattr(ag, 'uses_fallback', False) else np.zeros(4, np.float32)
        a, _, _, _, alpha = ag.act(o, a_safe_np=a_s, sample=False)
        o, r, done, info = env.step(a)
        if record:
            tr.append(dict(rmse=info['rmse_true'], a=np.clip(a, -1, 1).tolist(), alpha=float(alpha),
                           tau=env.channel.steps_since_valid, zeta=float(env.cov_trace), vis=bool(info['visible'])))
    return float(info['success']), float(info['lost']), tr


def classical(env, n, base=0):
    s, l = [], []
    for i in range(n):
        crn(env, base + i)
        env.reset(); done = False
        while not done:
            _, _, done, info = env.step(classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred))
        s.append(float(info['success'])); l.append(float(info['lost']))
    return dict(success_rate=float(np.mean(s)), lost_rate=float(np.mean(l)), raw_success=s)


def merge(fname, upd):
    path = f'{RES}/{fname}'
    cur = json.load(open(path)) if os.path.exists(path) else {}
    for k, v in upd.items():
        if isinstance(v, dict) and isinstance(cur.get(k), dict):
            cur[k].update(v)
        else:
            cur[k] = v
    json.dump(cur, open(path + '.tmp', 'w')); os.replace(path + '.tmp', path)


def m_kin(names):
    for name in names:
        out = {}
        for pre in PRESETS:
            rs = []
            for sd in seeds_of(name):
                ag = load(name, sd); env = make_env(seed=999, difficulty=pre, **ENV_KW.get(name, {}))
                S, L = [], []
                for i in range(300):
                    s, l, _ = episode(env, ag, key=BASE['kin'][pre] + i); S.append(s); L.append(l)
                rs.append(dict(seed=sd, success_rate=float(np.mean(S)), lost_rate=float(np.mean(L)), raw_success=S))
            out[pre] = rs
            print(f'kin {name} {pre}: {np.mean([r["success_rate"] for r in rs]):.4f}', flush=True)
        merge('v2_kin.json', {name: out})


def m_kin_classical():
    out = {}
    for est in ['ab', 'kf']:
        out[est] = {pre: classical(make_env(seed=999, difficulty=pre, estimator=est), 300, BASE['kin'][pre]) for pre in PRESETS}
        print('classical', est, {p: out[est][p]['success_rate'] for p in PRESETS}, flush=True)
    merge('v2_kin.json', {'classical': out})


def m_mujoco(names):
    from mujoco_env import MuJoCoIBVSEnv
    if 'classical' in names:
        out = {}
        for est in ['ab', 'kf']:
            out[est] = {pre: classical(MuJoCoIBVSEnv(seed=999, p_lose=pl, p_recover=pr, estimator=est), 100, BASE['mujoco'][pre])
                        for pre, (pl, pr) in PRESETS.items()}
            print('mujoco classical', est, {k: v['success_rate'] for k, v in out[est].items()}, flush=True)
        merge('v2_mujoco.json', {'classical': out}); names = [n for n in names if n != 'classical']
    for name in names:
        out = {}
        for pre, (pl, pr) in PRESETS.items():
            rs = []
            for sd in seeds_of(name):
                ag = load(name, sd); env = MuJoCoIBVSEnv(seed=999, p_lose=pl, p_recover=pr, **ENV_KW.get(name, {}))
                S, L = zip(*[episode(env, ag, key=BASE['mujoco'][pre] + i)[:2] for i in range(100)])
                rs.append(dict(seed=sd, success_rate=float(np.mean(S)), lost_rate=float(np.mean(L))))
            out[pre] = rs
            print(f'mujoco {name} {pre}: {np.mean([r["success_rate"] for r in rs]):.3f}', flush=True)
        merge('v2_mujoco.json', {name: out})


def m_real(names):
    from mujoco_realimage_env import RealImageMuJoCoEnv
    if 'classical' in names:
        out = {}
        for strict in [True, False]:
            for est in ['ab', 'kf']:
                env = RealImageMuJoCoEnv(p_lose=0.08, p_recover=0.18, seed=999, strict_detection_termination=strict, estimator=est)
                out[('strict' if strict else 'lenient') + ('' if est == 'ab' else '_kf')] = classical(env, 30, BASE['real']); env.renderer.close()
        print('real classical', {k: v['success_rate'] for k, v in out.items()}, flush=True)
        merge('v2_real.json', {'classical': out}); names = [n for n in names if n != 'classical']
    for name in names:
        out = {}
        for strict in [True, False]:
            rs = []
            for sd in [1, 2, 3, 4, 5]:
                ag = load(name, sd)
                env = RealImageMuJoCoEnv(p_lose=0.08, p_recover=0.18, seed=999, strict_detection_termination=strict, **ENV_KW.get(name, {}))
                S, L = zip(*[episode(env, ag, key=BASE['real'] + i)[:2] for i in range(30)]); env.renderer.close()
                rs.append(dict(seed=sd, success_rate=float(np.mean(S)), lost_rate=float(np.mean(L))))
            out['strict' if strict else 'lenient'] = rs
            print(f'real {name} {"strict" if strict else "lenient"}: {np.mean([r["success_rate"] for r in rs]):.3f}', flush=True)
        merge('v2_real.json', {name: out})


def m_replay(names):
    from replay_env import RealMotionEnv, SIGMA_REAL
    for name in names:
        out = {}
        for sig_name, sig, spd in [('real', SIGMA_REAL, 1), ('stress', 0.5, 3)]:
            for pre, (pl, pr) in PRESETS.items():
                if name == 'classical':
                    out[f'{sig_name}_{pre}'] = {est: classical(RealMotionEnv(pl, pr, seed=4242, speed=spd, pixel_noise_std=sig, estimator=est), 100, BASE['replay'][pre])
                                                for est in ['ab', 'kf']}
                    continue
                rs = []
                for sd in seeds_of(name):
                    ag = load(name, sd); env = RealMotionEnv(pl, pr, seed=4242, speed=spd, pixel_noise_std=sig, **ENV_KW.get(name, {}))
                    S, L = zip(*[episode(env, ag, key=BASE['replay'][pre] + i)[:2] for i in range(100)])
                    rs.append(dict(seed=sd, success_rate=float(np.mean(S)), lost_rate=float(np.mean(L))))
                out[f'{sig_name}_{pre}'] = rs
            print(f'replay {name} {sig_name}: ' + str({p: (round(float(np.mean([r["success_rate"] for r in out[f"{sig_name}_{p}"]])), 3)
                                                         if name != 'classical' else {e: out[f"{sig_name}_{p}"][e]['success_rate'] for e in ['ab', 'kf']})
                                                        for p in PRESETS}), flush=True)
        merge('v2_replay.json', {name: out})


def m_effort(names):
    for name in names:
        rs = []
        for sd in seeds_of(name):
            ag = load(name, sd); env = make_env(seed=77, difficulty='moderate', **ENV_KW.get(name, {}))
            E, Jk, Cv = [], [], []
            for i in range(120):
                _, _, tr = episode(env, ag, record=True, key=7_000_000 + i)
                A = np.array([t['a'] for t in tr]); E.append(float(np.mean(np.sum(A ** 2, 1))))
                Jk.append(float(np.mean(np.sum(np.diff(A, axis=0) ** 2, 1))) if len(A) > 1 else 0.0)
            rs.append(dict(seed=sd, effort=float(np.mean(E)), jerk=float(np.mean(Jk))))
        print(f'effort {name}: effort {np.mean([r["effort"] for r in rs]):.4f} jerk {np.mean([r["jerk"] for r in rs]):.5f}', flush=True)
        merge('v2_effort.json', {name: rs})
    if 'classical' in sys.argv:
        pass


def m_gate(names):
    from scipy import stats
    for name in names:
        ps, pooled = [], {}
        bins = [0, 1, 2, 4, 7, 11, 21]
        for sd in seeds_of(name):
            ag = load(name, sd); env = make_env(seed=2024, difficulty='moderate', **ENV_KW.get(name, {}))
            A, T, Z = [], [], []
            for i in range(60):
                _, _, tr = episode(env, ag, record=True, key=8_000_000 + i)
                A += [t['alpha'] for t in tr]; T += [t['tau'] for t in tr]; Z += [t['zeta'] for t in tr]
            A, T, Z = map(np.array, (A, T, Z))
            for b in range(len(bins) - 1):
                pooled.setdefault(b, []).extend(A[(T >= bins[b]) & (T < bins[b + 1])].tolist())
            ps.append(dict(seed=sd, n=int(len(A)), rho_tau=float(stats.spearmanr(A, T).correlation),
                           rho_zeta=float(stats.spearmanr(A, Z).correlation), alpha_vis=float(A[T == 0].mean()),
                           alpha_drop=float(A[T > 0].mean())))
        out = dict(per_seed=ps, by_tau=[dict(lo=bins[b], hi=bins[b + 1] - 1, n=len(v), mean=float(np.mean(v)), sd=float(np.std(v)))
                                        for b, v in sorted(pooled.items())])
        print(f'gate {name}: rho_tau ' + str([round(p["rho_tau"], 2) for p in ps]), flush=True)
        merge('v2_gate.json', {name: out})


if __name__ == '__main__':
    mode, names = sys.argv[1], sys.argv[2:]
    t0 = time.time()
    if mode == 'kin':
        if 'classical' in names:
            m_kin_classical(); names = [n for n in names if n != 'classical']
        m_kin(names)
    else:
        dict(mujoco=m_mujoco, real=m_real, replay=m_replay, effort=m_effort, gate=m_gate)[mode](names)
    print(f'DONE {mode} {names} in {time.time() - t0:.0f}s', flush=True)
