"""Real-motion environments.

RealMotionEnv : closed-loop replay of REAL target motion recovered from a ViSP sequence
                (default 'mire-2'; held-out: 'mbt-cube', 'cube', 'ellipse-1'). Each episode replays a
                random window of the real target-centroid trajectory as the target's in-plane motion
                (`speed` recorded frames per 0.1 s control step). Sequences shorter than the episode
                hold their last position (the target stops). Pixels -> metres at the nominal depth:
                dx[m] = dpx * (360 / W) * Z_DESIRED / F, W = recorded image width.
RealMixEnv    : real-data-driven TRAINING environment (mire-2 only; held-out sequences are never used):
                per episode, the target follows (i) the synthetic random-walk drift, (ii) a randomized
                window of recorded mire-2 motion (speed 1-3 frames/step, random rotation, mirror and
                amplitude 0.5-2x), or (iii) a static target with random hand-like repositioning jumps;
                pixel noise is randomized in [0.1, 1.0] px."""
import json, os, numpy as np
from env import IBVSDropoutEnv, Z_DESIRED, F
HERE = os.path.dirname(os.path.abspath(__file__))
RDIR = os.path.join(HERE, '..', '..', '..', 'realdata')
TR = json.load(open(os.path.join(RDIR, 'mire2_tracks.json')))
RD = json.load(open(os.path.join(RDIR, 'realdata_results.json')))
SIGMA_REAL = RD['sigma_meas_px'] * (360.0 / 384.0)


def centroid_xy(tracks, width):
    C = np.array(tracks).reshape(-1, 4, 2).mean(1)
    return (C - C[0]) * (360.0 / width) * Z_DESIRED / F


SOURCES = {'mire-2': centroid_xy(TR['tracks'], 384)}
_HO = os.path.join(RDIR, 'heldout_tracks.json')
if os.path.exists(_HO):
    for k, v in json.load(open(_HO)).items():
        SOURCES[k] = centroid_xy(v['tracks'], v['width'])
XY = SOURCES['mire-2']
HELDOUT = ['mbt-cube', 'cube', 'ellipse-1']


def window(src, speed, rng, T=100):
    span = T * speed + 1
    st = int(rng.integers(0, len(src) - span)) if len(src) > span else 0
    w = src[st:st + span:speed] - src[st]
    if len(w) < T + 1:
        w = np.vstack([w, np.repeat(w[-1:], T + 1 - len(w), 0)])
    return w


class RealMotionEnv(IBVSDropoutEnv):
    def __init__(self, p_lose, p_recover, seed=0, speed=1, source='mire-2', **kw):
        kw.setdefault('pixel_noise_std', SIGMA_REAL)
        self.speed, self.source = int(speed), source
        super().__init__(p_lose=p_lose, p_recover=p_recover, seed=seed, **kw)
        self.target_traj = None

    def reset(self, difficulty=None):
        self.target_traj = None
        o, info = super().reset(difficulty)
        self.target_traj = window(SOURCES[self.source], self.speed, self.rng)
        return o, info


class RealMixEnv(IBVSDropoutEnv):
    def __init__(self, p_lose, p_recover, seed=0, **kw):
        super().__init__(p_lose=p_lose, p_recover=p_recover, seed=seed, **kw)
        self.target_traj = None

    def _jumps(self, T=101):
        xy, p, v = np.zeros((T, 2)), np.zeros(2), np.zeros(2); left = 0
        for t in range(1, T):
            if left == 0 and self.rng.random() < 0.03:
                d = self.rng.uniform(0.01, 0.04); ang = self.rng.uniform(0, 2 * np.pi); left = int(self.rng.integers(2, 5))
                v = d / left * np.array([np.cos(ang), np.sin(ang)])
            if left > 0: p = p + v; left -= 1
            xy[t] = p
        return xy

    def reset(self, difficulty=None):
        self.target_traj = None
        self.pixel_noise_std = float(self.rng.uniform(0.1, 1.0))
        o, info = super().reset(difficulty)
        u = self.rng.random()
        if u < 0.4:
            self.target_traj = None                                    # synthetic random-walk drift
        elif u < 0.8:
            w = window(XY, int(self.rng.integers(1, 4)), self.rng)
            a = self.rng.uniform(0, 2 * np.pi); R = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
            if self.rng.random() < 0.5: w = w * np.array([1.0, -1.0])
            self.target_traj = (w @ R.T) * self.rng.uniform(0.5, 2.0)
        else:
            self.target_traj = self._jumps()
        return o, info


PRESETS = {'mild': (0.04, 0.25), 'moderate': (0.08, 0.18), 'severe': (0.14, 0.12)}
