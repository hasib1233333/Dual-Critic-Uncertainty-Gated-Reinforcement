"""
Evaluate FAUG-PPO (fallback-anchored, uncertainty-feature-gated PPO; the
`abl_no_vdiff` configuration: learned gate on shared-trunk features, no
critic-disagreement input) on every evaluation tier used in the paper.

Checkpoints: models_expanded/abl_no_vdiff_n10_seed{1..10}.pt (10 seeds,
3000 episodes each, trained on the moderate preset).

Usage: python eval_faug.py {kin|mujoco|real}
Outputs go to results/faug_*.json. Nothing here overwrites earlier results.
"""
import os, sys, json, time
os.environ.setdefault('MUJOCO_GL', 'osmesa')
os.environ.setdefault('PYOPENGL_PLATFORM', 'osmesa')
import numpy as np
import torch
import torch._dynamo  # must load before mujoco (import-order segfault otherwise)

from train import make_env
from ppo import Agent
from controllers import fallback_action

HERE = os.path.dirname(os.path.abspath(__file__))
RESULTS = os.path.join(HERE, '..', 'results')
MODELS = os.path.join(HERE, '..', 'models_expanded')
SEEDS = list(range(1, 11))


def load_faug(seed):
    env = make_env(seed=0, difficulty='moderate')
    agent = Agent(env.obs_dim, env.act_dim, dual=True, use_vdiff=False)
    ck = torch.load(f'{MODELS}/abl_no_vdiff_n10_seed{seed}.pt', weights_only=True)
    agent.actor.load_state_dict(ck['actor'])
    agent.v_opt.load_state_dict(ck['v_opt'])
    agent.v_pess.load_state_dict(ck['v_pess'])
    return agent


def run_episode(env, agent):
    obs, _ = env.reset()
    done = False
    while not done:
        a_safe = fallback_action(env)
        act, *_ = agent.act(obs, a_safe_np=a_safe, sample=False)
        obs, rew, done, info = env.step(act)
    return float(info['success']), float(info['lost'])


def kin():
    out = {}
    for diff in ['mild', 'moderate', 'severe']:
        res = []
        for sd in SEEDS:
            agent = load_faug(sd)
            env = make_env(seed=999, difficulty=diff)
            s, l = zip(*[run_episode(env, agent) for _ in range(300)])
            res.append(dict(seed=sd, success_rate=float(np.mean(s)), lost_rate=float(np.mean(l)),
                            raw_success=list(s)))
            print(f'kin {diff} seed {sd}: {np.mean(s):.4f}', flush=True)
        out[diff] = res
        json.dump(out, open(f'{RESULTS}/faug_eval_kinematic.json', 'w'), indent=1)


def mujoco():
    from mujoco_env import MuJoCoIBVSEnv
    presets = {'mild': dict(p_lose=0.04, p_recover=0.25),
               'moderate': dict(p_lose=0.08, p_recover=0.18),
               'severe': dict(p_lose=0.14, p_recover=0.12)}
    out = {}
    for diff, kw in presets.items():
        res = []
        for sd in SEEDS:
            agent = load_faug(sd)
            env = MuJoCoIBVSEnv(seed=999, **kw)
            s, l = zip(*[run_episode(env, agent) for _ in range(100)])
            res.append(dict(seed=sd, success_rate=float(np.mean(s)), lost_rate=float(np.mean(l))))
            print(f'mujoco {diff} seed {sd}: {np.mean(s):.3f}', flush=True)
        out[diff] = res
        json.dump(out, open(f'{RESULTS}/faug_eval_mujoco.json', 'w'), indent=1)


def real():
    from mujoco_realimage_env import RealImageMuJoCoEnv
    from run_experiments import load_agent
    from controllers import classical_ibvs_action
    out = {}
    # --- reproduction check against published numbers before trusting new ones
    env = RealImageMuJoCoEnv(p_lose=0.08, p_recover=0.18, seed=999)
    sc_ = []
    for _ in range(30):
        obs, _ = env.reset(); done = False
        while not done:
            obs, rew, done, info = env.step(classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred))
        sc_.append(info['success'])
    env.renderer.close()
    d1 = load_agent('dcug_full', 1, dual=True)
    chk = {'classical_ab_fallback_strict': float(np.mean(sc_))}
    for strict in [True, False]:
        env = RealImageMuJoCoEnv(p_lose=0.08, p_recover=0.18, seed=999, strict_detection_termination=strict)
        chk[f'dcug_seed1_{"strict" if strict else "lenient"}'] = float(np.mean([run_episode(env, d1)[0] for _ in range(30)]))
        env.renderer.close()
    print('REPRODUCTION CHECK (published: classical 0.633, dcug s1 strict 0.600, lenient 0.933):', chk, flush=True)
    out['reproduction_check'] = chk
    for strict in [True, False]:
        key = 'strict' if strict else 'lenient'
        res = []
        for sd in [1, 2, 3, 4, 5]:
            agent = load_faug(sd)
            env = RealImageMuJoCoEnv(p_lose=0.08, p_recover=0.18, seed=999,
                                     strict_detection_termination=strict)
            s, l = zip(*[run_episode(env, agent) for _ in range(30)])
            env.renderer.close()  # osmesa: a second live renderer renders corrupted frames
            res.append(dict(seed=sd, success_rate=float(np.mean(s)), lost_rate=float(np.mean(l))))
            print(f'real {key} seed {sd}: {np.mean(s):.3f} lost {np.mean(l):.3f}', flush=True)
        out[key] = res
        json.dump(out, open(f'{RESULTS}/faug_eval_realimage.json', 'w'), indent=1)


if __name__ == '__main__':
    t0 = time.time()
    {'kin': kin, 'mujoco': mujoco, 'real': real}[sys.argv[1]]()
    print(f'DONE {sys.argv[1]} in {time.time()-t0:.0f}s', flush=True)
