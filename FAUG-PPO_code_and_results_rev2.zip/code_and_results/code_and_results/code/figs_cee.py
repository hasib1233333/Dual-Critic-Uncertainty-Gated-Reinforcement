"""Figures for the Computers & Electrical Engineering (Elsevier) manuscript.
Grayscale with one accent colour for the proposed method. Widths: 90 mm (single) / 190 mm (double)."""
import json, os, sys, glob, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

R = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results')
OUT = os.environ.get('FIGOUT', '/home/claude/project/paper_cee')
SINGLE, DOUBLE = 3.54, 7.48
plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Liberation Serif', 'Times New Roman'], 'mathtext.fontset': 'stix',
                     'font.size': 8, 'axes.labelsize': 8, 'axes.titlesize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7,
                     'legend.fontsize': 6.8, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.grid': True,
                     'grid.color': '#D0D0D0', 'grid.linewidth': 0.4, 'grid.linestyle': ':', 'legend.frameon': False,
                     'savefig.bbox': 'tight', 'savefig.pad_inches': 0.02, 'figure.dpi': 200, 'axes.linewidth': 0.6,
                     'axes.axisbelow': True})
BLUE = '#2B5C8A'
# name -> (label, face colour, hatch)
STY = {'classical_ab': (r'IBVS + $\alpha\beta$', '#FFFFFF', '////'), 'classical_kf': ('IBVS + KF', '#FFFFFF', '\\\\\\\\'),
       'sc_3k': ('PPO', '#E6E6E6', ''), 'resid': ('Residual PPO', '#CFCFCF', ''), 'fixed': (r'Fixed $\alpha$=0.5', '#B5B5B5', ''),
       'dcug_3k': ('DCUG-PPO', '#9A9A9A', ''), 'sac': ('SAC', '#7A7A7A', ''), 'td3_smooth': ('TD3-smooth', '#5E5E5E', ''),
       'td3': ('TD3', '#444444', ''), 'faug_kf_rm': ('FAUG-PPO (KF, real-data trained)', '#6F8FB0', ''),
       'faug_kf@cov3a03': ('FAUG-PPO (KF) + cap', '#163A5F', ''), 'faug_kf_rm@cov3a03': ('FAUG-PPO (KF, real-data) + cap', '#163A5F', '....'),
       'kf_fixed': (r'KF + fixed $\alpha$=0.5', '#B5B5B5', '\\\\'), 'faug_sc': (r'FAUG-PPO ($\alpha\beta$)', '#9DB7D0', ''), 'faug_kf': ('FAUG-PPO (KF)', BLUE, '')}
PRE = ['mild', 'moderate', 'severe']
J = lambda f: json.load(open(os.path.join(R, f))) if os.path.exists(os.path.join(R, f)) else {}


def per_seed(d, name, pre, key='success_rate'):
    v = d.get(name, {}).get(pre)
    if v is None: return None
    return np.array([r[key] for r in v]) * 100 if isinstance(v, list) else np.array([v[key] * 100])


def grouped(ax, d, names, key, ylabel, classical_from=None):
    n = len(names); w = 0.8 / n
    for j, name in enumerate(names):
        lab, fc, hat = STY[name]
        for i, pre in enumerate(PRE):
            if name.startswith('classical'):
                est = name.split('_')[1]; c = d.get('classical', {}).get(est, {}).get(pre)
                if c is None: continue
                vals = np.array([c[key] * 100])
            else:
                vals = per_seed(d, name, pre, key)
                if vals is None: continue
            x = i - 0.4 + w * (j + 0.5)
            ax.bar(x, vals.mean(), w * 0.92, color=fc, edgecolor='black', lw=0.45, hatch=hat, label=lab if i == 0 else None, zorder=2)
            if len(vals) > 1:
                ax.errorbar(x, vals.mean(), yerr=vals.std(ddof=1), color='black', lw=0.5, capsize=1.2, zorder=3)
                ax.scatter(np.full(len(vals), x) + np.random.RandomState(j).uniform(-w * .25, w * .25, len(vals)), vals,
                           s=1.6, color='black', zorder=4, lw=0)
    ax.set_xticks(range(3)); ax.set_xticklabels(['Mild', 'Moderate\n(training)', 'Severe']); ax.set_ylabel(ylabel)


def fig_main():
    d = dict(J('v2_kin.json')); T = J('v3_tiers.json')
    if 'faug_kf@cov3a03' in T: d['faug_kf@cov3a03'] = {p: T['faug_kf@cov3a03'][f'kin|{p}'] for p in PRE}
    names = [n for n in ['classical_ab', 'classical_kf', 'sc_3k', 'resid', 'fixed', 'dcug_3k', 'sac', 'td3_smooth', 'td3', 'faug_sc', 'faug_kf', 'faug_kf@cov3a03']
                                   if n.startswith('classical') or n in d]
    fig, axs = plt.subplots(1, 2, figsize=(DOUBLE, 2.3), gridspec_kw=dict(wspace=0.18))
    grouped(axs[0], d, names, 'success_rate', 'Success rate (%)'); axs[0].set_ylim(40, 101); axs[0].set_title('(a) Success')
    grouped(axs[1], d, names, 'lost_rate', 'Target-loss rate (%)'); axs[1].set_ylim(0, 40); axs[1].set_title('(b) Target loss')
    h, l = axs[0].get_legend_handles_labels(); fig.legend(h, l, loc='upper center', ncol=min(len(l), 6), bbox_to_anchor=(0.5, -0.02))
    fig.savefig(os.path.join(OUT, 'cee_main.pdf'))


def fig_learning():
    L = J('v2_learning.json')['runs']
    def curves(name):
        if name == 'fixed':
            return [[(h['episode'], h['success_rate']) for h in r['history']] for r in J('train_abl_fixed_alpha_n10.json')]
        return [[(h['episode'], h['success_rate']) for h in json.load(open(f))['history']] for f in sorted(glob.glob(f'{R}/train_v2_{name}_seed*.json'))]
    fig, axs = plt.subplots(1, 2, figsize=(DOUBLE, 2.1), gridspec_kw=dict(width_ratios=[1.7, 1], wspace=0.25))
    ls = {'sc_3k': (0, (1, 1.2)), 'resid': (0, (3, 1, 1, 1)), 'fixed': (0, (4, 1.5)), 'dcug_3k': (0, (6, 1.5)), 'faug_sc': '-', 'faug_kf': '-'}
    col = {'sc_3k': '#9A9A9A', 'resid': '#7A7A7A', 'fixed': '#5E5E5E', 'dcug_3k': '#333333', 'faug_sc': '#9DB7D0', 'faug_kf': BLUE}
    for n in ['sc_3k', 'resid', 'fixed', 'dcug_3k', 'faug_sc', 'faug_kf']:
        C = curves(n); E = np.array([e for e, _ in C[0]]); M = np.array([[s for _, s in c][:len(E)] for c in C]) * 100
        axs[0].plot(E, M.mean(0), color=col[n], ls=ls[n], lw=1.3 if n.startswith('faug') else 0.9, label=STY[n][0])
        axs[0].fill_between(E, M.mean(0) - M.std(0), M.mean(0) + M.std(0), color=col[n], alpha=0.12, lw=0)
    axs[0].set_xlabel('Training episode'); axs[0].set_ylabel('Stochastic training success (%)'); axs[0].set_xlim(0, 3000)
    axs[0].legend(loc='upper left', ncol=2); axs[0].set_title('(a) Learning curves (mean ± s.d., 10 seeds)')
    names = ['sc_3k', 'resid', 'fixed', 'dcug_3k', 'faug_sc', 'faug_kf']
    for i, n in enumerate(names):
        v = np.array(L[n]['auc'])
        axs[1].scatter(np.full(len(v), i) + np.random.RandomState(i).uniform(-.12, .12, len(v)), v, s=4, color=col[n], zorder=3, lw=0)
        axs[1].errorbar(i + 0.25, v.mean(), yerr=v.std(ddof=1), fmt='o', ms=2.5, color='black', lw=0.6, capsize=1.5)
    axs[1].set_xticks(range(len(names))); axs[1].set_xticklabels(['PPO', 'Resid.', 'Fixed', 'DCUG', 'FAUG\n($\\alpha\\beta$)', 'FAUG\n(KF)'], fontsize=6.5)
    axs[1].set_ylabel('Learning-curve area (0–3000)'); axs[1].set_title('(b) Learning speed')
    fig.savefig(os.path.join(OUT, 'cee_learning.pdf'))


def fig_gate():
    g = J('v2_gate.json')
    fig, axs = plt.subplots(1, 2, figsize=(DOUBLE, 2.0), gridspec_kw=dict(width_ratios=[1.4, 1], wspace=0.25))
    labs = ['0', '1', '2–3', '4–6', '7–10', '11–20']
    for k, (n, c, m, off) in enumerate([('faug_sc', '#8FA9C2', 's', -0.12), ('dcug_3k', '#666666', 'D', 0.0), ('faug_kf', BLUE, 'o', 0.12)]):
        if n not in g or 'by_tau' not in g[n]: continue
        b = g[n]['by_tau']; x = np.arange(len(b)) + off
        axs[0].errorbar(x, [r['mean'] for r in b], yerr=[r['sd'] for r in b], color=c, marker=m, ms=3, lw=1.0, capsize=1.5, label=STY[n][0])
    # authority cap, Eq. (14), evaluated on the Kalman covariance propagated through a dropout (bin means)
    from train import make_env as _mk
    _e = _mk(seed=3, difficulty='moderate', estimator='kf'); _e.reset(); _e.channel.p_lose = 0.0
    for _ in range(20): _e.step(np.zeros(4))
    caps = [0.3 * 9 / (9 + _e.P[0, 0])]; _e.channel.p_lose, _e.channel.p_recover = 1.0, 0.0
    for _ in range(20): _e.step(np.zeros(4)); caps.append(0.3 * 9 / (9 + _e.P[0, 0]))
    cb = [caps[0], caps[1], np.mean(caps[2:4]), np.mean(caps[4:7]), np.mean(caps[7:11]), np.mean(caps[11:21])]
    axs[0].plot(range(6), cb, color='black', ls='--', lw=1.0, marker='x', ms=3, label='authority cap (deployment bound)')
    axs[0].legend(loc='lower left')
    axs[0].set_xticks(range(6)); axs[0].set_xticklabels(labs); axs[0].set_xlabel(r'Dropout age $\tau_t$ (steps; 0 = visible)')
    axs[0].set_ylabel(r'Gate $\alpha_t$ (mean ± s.d.)'); axs[0].set_title('(a) Learned gate and cap vs. dropout age'); axs[0].set_ylim(0, 0.42)
    for i, (n, c) in enumerate([('faug_sc', '#8FA9C2'), ('dcug_3k', '#666666'), ('faug_kf', BLUE)]):
        if n not in g: continue
        r = [p['rho_tau'] for p in g[n]['per_seed']]
        axs[1].scatter(np.full(len(r), i) + np.random.RandomState(i).uniform(-.12, .12, len(r)), r, s=7, color=c, lw=0)
        axs[1].plot([i - .25, i + .25], [np.mean(r)] * 2, color='black', lw=0.8)
    axs[1].axhline(0, color='black', lw=0.5); axs[1].set_xticks(range(3)); axs[1].set_xticklabels([STY[n][0] for n in ['faug_sc', 'dcug_3k', 'faug_kf']], fontsize=6.3)
    axs[1].set_ylabel(r'Spearman $\rho(\alpha_t,\tau_t)$'); axs[1].set_title('(b) Per-seed gate–age correlation'); axs[1].set_ylim(-0.7, 0.1)
    fig.savefig(os.path.join(OUT, 'cee_gate.pdf'))


def fig_effort():
    e = J('v3_effort.json')
    names = [n for n in ['classical_kf', 'sc_3k', 'resid', 'fixed', 'dcug_3k', 'faug_sc', 'sac', 'td3', 'td3_smooth', 'faug_kf', 'faug_kf@cov3a03'] if n in e]
    fig, axs = plt.subplots(1, 3, figsize=(DOUBLE, 2.0), gridspec_kw=dict(wspace=0.32))
    for ax, key, lab in [(axs[0], 'effort', r'Effort $\|\mathbf{a}_t\|^2$'), (axs[1], 'action_rate', r'Action rate $\|\mathbf{a}_t-\mathbf{a}_{t-1}\|^2$'),
                         (axs[2], 'jerk_rms', r'Commanded jerk (m/s$^3$, RMS)')]:
        for i, n in enumerate(names):
            v = np.array([r[key] for r in e[n]['moderate']]); _, fc, hat = STY[n]
            ax.bar(i, v.mean(), 0.72, color=fc, edgecolor='black', lw=0.45, hatch=hat, zorder=2)
            if len(v) > 1: ax.scatter(np.full(len(v), i) + np.random.RandomState(i).uniform(-.15, .15, len(v)), v, s=2, color='black', lw=0, zorder=3)
        ax.set_yscale('log'); ax.set_xticks(range(len(names)))
        ax.set_xticklabels([{'faug_kf@cov3a03': 'FAUG (KF)+cap', 'faug_kf': 'FAUG (KF)', 'faug_sc': 'FAUG (αβ)', 'classical_kf': 'IBVS+KF',
                             'resid': 'Residual', 'fixed': 'Fixed', 'dcug_3k': 'DCUG', 'sc_3k': 'PPO', 'td3_smooth': 'TD3-sm.'}.get(n, STY[n][0]) for n in names],
                           rotation=55, ha='right', fontsize=6)
        ax.set_title(lab, fontsize=7.5)
    axs[0].set_ylabel('Per step (moderate preset)')
    fig.savefig(os.path.join(OUT, 'cee_effort.pdf'))


def fig_transfer():
    m, r, p = dict(J('v2_mujoco.json')), dict(J('v2_real.json')), dict(J('v2_replay.json')); T = J('v3_tiers.json'); R3 = J('v3_real.json')
    if 'faug_kf@cov3a03' in T:
        m['faug_kf@cov3a03'] = {q: T['faug_kf@cov3a03'][f'mujoco|{q}'] for q in PRE}
        p['faug_kf@cov3a03'] = {f'real_{q}': T['faug_kf@cov3a03'][f'replay|1|{q}'] for q in PRE}
    if 'faug_kf@cov3a03' in R3: r['faug_kf@cov3a03'] = R3['faug_kf@cov3a03']
    if not m: print('transfer: no MuJoCo data yet'); return
    fig, axs = plt.subplots(1, 3, figsize=(DOUBLE, 2.15), gridspec_kw=dict(width_ratios=[1.6, 1, 1.6], wspace=0.3))
    names = [n for n in ['classical_ab', 'classical_kf', 'sc_3k', 'resid', 'dcug_3k', 'sac', 'td3_smooth', 'td3', 'faug_sc', 'faug_kf', 'faug_kf@cov3a03'] if n.startswith('classical') or n in m]
    grouped(axs[0], m, names, 'success_rate', 'Success rate (%)'); axs[0].set_ylim(30, 101); axs[0].set_title('(a) Tier 2: MuJoCo dynamics')
    axs[0].set_xticklabels(['Mild', 'Moderate', 'Severe'])
    if r:
        rn = [n for n in ['classical_ab', 'classical_kf', 'sc_3k', 'resid', 'dcug_3k', 'faug_sc', 'faug_kf', 'faug_kf@cov3a03'] if n.startswith('classical') or n in r]
        for k, mode in enumerate(['strict', 'lenient']):
            for j, n in enumerate(rn):
                if n.startswith('classical'):
                    key = mode + ('' if n.endswith('ab') else '_kf'); c = r.get('classical', {}).get(key)
                    if c is None: continue
                    vals = np.array([c['success_rate'] * 100])
                else:
                    vals = np.array([s['success_rate'] for s in r[n][mode]]) * 100
                w = 0.8 / len(rn); x = k - 0.4 + w * (j + .5); _, fc, hat = STY[n]
                axs[1].bar(x, vals.mean(), w * .92, color=fc, edgecolor='black', lw=0.45, hatch=hat, zorder=2)
                if len(vals) > 1: axs[1].errorbar(x, vals.mean(), yerr=vals.std(ddof=1), color='black', lw=0.5, capsize=1.2, zorder=3)
        axs[1].set_xticks([0, 1]); axs[1].set_xticklabels(['Strict', 'Lenient']); axs[1].set_ylim(30, 101)
        axs[1].set_title('(b) Tier 3: rendered + OpenCV'); axs[1].set_ylabel('Success rate (%)')
    if p:
        pn = [n for n in ['classical_ab', 'classical_kf', 'sc_3k', 'resid', 'fixed', 'dcug_3k', 'sac', 'td3_smooth', 'td3', 'faug_sc', 'faug_kf', 'faug_kf@cov3a03'] if n.startswith('classical') or n in p]
        pp = {n: {pre: p[n][f'real_{pre}'] for pre in PRE} for n in pn if not n.startswith('classical')}
        pp['classical'] = {e: {pre: p['classical'][f'real_{pre}'][e] for pre in PRE} for e in ['ab', 'kf']} if 'classical' in p else {}
        grouped(axs[2], pp, pn, 'success_rate', 'Success rate (%)'); axs[2].set_ylim(30, 101); axs[2].set_xticklabels(['Mild', 'Moderate', 'Severe'])
        axs[2].set_title('(c) Real-motion replay (ViSP mire-2)')
    h, l = axs[2 if p else 0].get_legend_handles_labels(); fig.legend(h, l, loc='upper center', ncol=6, bbox_to_anchor=(0.5, -0.02))
    fig.savefig(os.path.join(OUT, 'cee_transfer.pdf'))


def fig_heldout():
    H = J('v3_heldout.json')
    names = [n for n in ['classical_ab', 'classical_kf', 'resid', 'fixed', 'faug_sc', 'sac', 'td3', 'td3_smooth', 'faug_kf', 'faug_kf_rm', 'faug_kf@cov3a03'] if n in H]
    conds = [('mbt-cube', 1), ('mbt-cube', 3), ('cube', 1), ('cube', 3), ('ellipse-1', 1), ('ellipse-1', 3)]
    fig, axs = plt.subplots(1, 2, figsize=(DOUBLE, 2.35), gridspec_kw=dict(width_ratios=[2.5, 1], wspace=0.62))
    w = 0.85 / len(names)
    for j, n in enumerate(names):
        lab, fc, hat = STY[n]
        for i, (src, spd) in enumerate(conds):
            v = np.array([r['success_rate'] for r in H[n][f'{src}|{spd}|severe']]) * 100
            x = i - 0.425 + w * (j + .5)
            axs[0].bar(x, v.mean(), w * .92, color=fc, edgecolor='black', lw=0.4, hatch=hat, label=lab if i == 0 else None, zorder=2)
            if len(v) > 1: axs[0].errorbar(x, v.mean(), yerr=v.std(ddof=1), color='black', lw=0.4, capsize=0.8, zorder=3)
    axs[0].set_xticks(range(len(conds))); axs[0].set_xticklabels([f'{s}\n{"recorded" if k == 1 else "3x"} speed' for s, k in conds], fontsize=6.5)
    axs[0].set_ylim(40, 101); axs[0].set_ylabel('Success rate (%)'); axs[0].set_title('(a) Held-out real sequences, severe dropout')
    for j, n in enumerate(names):
        keys = [k for k in H[n] if k.endswith('severe')]
        v = np.mean([[r['success_rate'] for r in H[n][k]] for k in keys], 0) * 100
        lab, fc, hat = STY[n]
        axs[1].barh(j, v.mean(), 0.7, color=fc, edgecolor='black', lw=0.4, hatch=hat, zorder=2)
        if len(v) > 1:
            axs[1].scatter(v, np.full(len(v), j) + np.random.RandomState(j).uniform(-.18, .18, len(v)), s=2.5, color='black', lw=0, zorder=3)
    SH = {'faug_kf_rm': 'FAUG (KF, real-data)', 'faug_kf@cov3a03': 'FAUG (KF) + cap', 'faug_kf': 'FAUG (KF)', 'faug_sc': 'FAUG (αβ)'}
    axs[1].set_yticks(range(len(names))); axs[1].set_yticklabels([SH.get(n, STY[n][0]) for n in names], fontsize=6.2)
    axs[1].set_xlim(55, 100); axs[1].set_xlabel('Mean severe success (%)'); axs[1].set_title('(b) Pooled over 6 conditions')
    axs[1].axvline(np.mean([[r['success_rate'] for r in H['classical_kf'][k]] for k in H['classical_kf'] if k.endswith('severe')]) * 100,
                   color='black', lw=0.6, ls='--')
    h, l = axs[0].get_legend_handles_labels(); fig.legend(h, l, loc='upper center', ncol=6, bbox_to_anchor=(0.42, -0.04), fontsize=6.3)
    fig.savefig(os.path.join(OUT, 'cee_heldout.pdf'))


def fig_budget():
    """Learning against environment interactions (runs with per-entry interaction logging only)."""
    fig, axs = plt.subplots(1, 2, figsize=(DOUBLE, 2.1), gridspec_kw=dict(wspace=0.28))
    spec = [('faug_kf_log', 'FAUG-PPO (KF)', BLUE, '-'), ('kf_age', 'KF + gate (age only)', '#8FA9C2', (0, (4, 1.5))),
            ('td3_smooth', 'TD3-smooth', '#444444', (0, (1, 1))), ('sac', 'SAC', '#888888', (0, (3, 1, 1, 1)))]
    for name, lab, c, ls in spec:
        H = [json.load(open(f))['history'] for f in sorted(glob.glob(f'{R}/train_v2_{name}_seed*.json'))]
        H = [h for h in H if h and 'env_steps' in h[-1]]
        if not H: continue
        grid = np.linspace(0, min(h[-1]['env_steps'] for h in H), 60)
        Y = np.array([np.interp(grid, [e['env_steps'] for e in h], [e['success_rate'] for e in h]) for h in H]) * 100
        axs[0].plot(grid / 1e3, Y.mean(0), color=c, ls=ls, lw=1.2, label=f'{lab} ({len(H)})')
        axs[0].fill_between(grid / 1e3, Y.min(0), Y.max(0), color=c, alpha=0.12, lw=0)
        G = np.array([np.interp(grid, [e['episode'] for e in h], [e['success_rate'] for e in h]) for h in H])
    axs[0].set_xlabel('Environment interactions ($\\times10^3$)'); axs[0].set_ylabel('Stochastic training success (%)')
    axs[0].set_title('(a) Learning vs. interactions (range over seeds)'); axs[0].legend(loc='lower right')
    B = J('v3_budget.json')
    if B:
        rows = []
        for lab, key, name in [('FAUG-PPO\n(KF)', 'FAUG-PPO', 'faug_kf'), ('SAC', 'SAC', 'sac'), ('TD3-smooth', 'TD3', 'td3_smooth'), ('TD3', 'TD3', 'td3')]:
            R_ = [json.load(open(f)) for f in glob.glob(f'{R}/train_v2_{name}_seed*.json')]
            st, up = np.mean([r['env_steps'] for r in R_]), np.mean([r['grad_updates'] for r in R_])
            rows.append((lab, st * B[key]['env_step_ms'] / 1e3, up * B[key]['update_ms'] / 1e3, st, up))
        x = np.arange(len(rows))
        axs[1].bar(x, [r[1] for r in rows], 0.6, color='#CFCFCF', edgecolor='black', lw=0.4, label='environment interactions')
        axs[1].bar(x, [r[2] for r in rows], 0.6, bottom=[r[1] for r in rows], color=BLUE, edgecolor='black', lw=0.4, label='gradient updates')
        for i, r in enumerate(rows):
            axs[1].text(i, r[1] + r[2] + 12, f'{r[3]/1e3:.0f}k / {r[4]/1e3:.1f}k', ha='center', fontsize=6)
        axs[1].set_xticks(x); axs[1].set_xticklabels([r[0] for r in rows], fontsize=6.8); axs[1].set_ylabel('Compute per training run (s, one core)')
        axs[1].set_title('(b) Estimated compute (interactions / updates)'); axs[1].legend(loc='upper right', fontsize=6)
        axs[1].set_ylim(0, max(r[1] + r[2] for r in rows) * 1.4)
    fig.savefig(os.path.join(OUT, 'cee_budget.pdf'))


if __name__ == '__main__':
    for f in (sys.argv[1:] or ['main', 'learning', 'gate', 'effort', 'transfer']):
        globals()['fig_' + f](); print('done', f)
