"""Statistics for the FAUG-PPO manuscript (Welch t, Holm correction, Hedges g,
seed-bootstrap CIs, Wilson intervals, Fisher exact, hierarchical bootstrap)."""
import json, os, numpy as np
from scipy import stats
from statsmodels.stats.proportion import proportion_confint
from statsmodels.stats.multitest import multipletests
RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results')
J = lambda f: json.load(open(os.path.join(RES, f)))
ev = J('eval_results.json'); fk = J('faug_eval_kinematic.json'); td3 = J('eval_td3.json')
rows = []
for d in ['mild', 'moderate', 'severe']:
    f = np.array([x['success_rate'] for x in fk[d]])
    comps = {'DCUG-PPO': [x['success_rate'] for x in ev[d]['dcug_full']],
             'Single-critic PPO': [x['success_rate'] for x in ev[d]['single_critic']],
             'TD3': [x['success_rate'] for x in td3[d][:3]]}
    for k, v in comps.items():
        v = np.array(v); r = stats.ttest_ind(f, v, equal_var=False); diff = f.mean() - v.mean()
        sp = np.sqrt(((len(f)-1)*f.var(ddof=1) + (len(v)-1)*v.var(ddof=1)) / (len(f)+len(v)-2))
        g = diff / sp * (1 - 3 / (4*(len(f)+len(v)) - 9))
        rng = np.random.default_rng(0)
        bs = [rng.choice(f, len(f)).mean() - rng.choice(v, len(v)).mean() for _ in range(20000)]
        rows.append((d, k, diff, r.statistic, r.pvalue, g, np.percentile(bs, 2.5), np.percentile(bs, 97.5)))
    ab = ev[d]['classical_ekf_fallback']['success_rate']; r = stats.ttest_1samp(f, ab)
    rows.append((d, 'IBVS+ab fallback', f.mean()-ab, r.statistic, r.pvalue, np.nan, np.nan, np.nan))
rej, padj, _, _ = multipletests([r[4] for r in rows], method='holm')
print('%-9s %-18s %7s %7s %9s %9s %6s %18s' % ('sev', 'vs', 'diff', 't', 'p', 'p_holm', 'g', 'boot95CI'))
for r, pa, rj in zip(rows, padj, rej):
    print('%-9s %-18s %+7.3f %7.2f %9.3g %9.3g %6.2f  [%+.3f,%+.3f] %s' % (*r[:4], r[4], pa, r[5], r[6], r[7], '*' if rj else ''))
out = {'tests': [dict(sev=r[0], vs=r[1], diff=r[2], t=r[3], p=r[4], p_holm=pa, g=r[5], ci=[r[6], r[7]]) for r, pa in zip(rows, padj)]}
for name, k, n in [('FAUG', 0, 10), ('SC', 1, 10), ('DCUG', 0, 10), ('fallback-anchored pooled (FAUG+DCUG+fixed)', 0, 30)]:
    lo, hi = proportion_confint(k, n, method='wilson'); print(f'{name} {k}/{n} Wilson [{lo*100:.1f}, {hi*100:.1f}]%')
print('Fisher 0/10 vs 1/10 p=%.3f ; 0/30 vs 1/10 p=%.3f' % (stats.fisher_exact([[0, 10], [1, 9]])[1], stats.fisher_exact([[0, 30], [1, 9]])[1]))
for d in ['mild', 'moderate', 'severe']:
    S = [np.array(x['raw_success']) for x in fk[d]]; rng = np.random.default_rng(1)
    bs = [np.mean([rng.choice(S[i], len(S[i])).mean() for i in rng.integers(0, 10, 10)]) for _ in range(4000)]
    print(d, 'FAUG pooled %.3f, hierarchical bootstrap 95%% CI [%.3f, %.3f]' % (np.mean(np.concatenate(S)), np.percentile(bs, 2.5), np.percentile(bs, 97.5)))
for d in ['mild', 'moderate', 'severe']:
    sc = [x['success_rate'] for x in ev[d]['single_critic']][1:]; f = [x['success_rate'] for x in fk[d]]
    print(d, 'FAUG vs SC excluding collapsed seed: %.3f vs %.3f, p=%.3g' % (np.mean(f), np.mean(sc), stats.ttest_ind(f, sc, equal_var=False).pvalue))
json.dump(out, open(os.path.join(RES, 'faug_stats.json'), 'w'), indent=1)
