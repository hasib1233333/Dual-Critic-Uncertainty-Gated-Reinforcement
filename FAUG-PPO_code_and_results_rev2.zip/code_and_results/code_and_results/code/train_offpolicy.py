"""Off-policy baselines for the C&EE revision: SAC and smoothness-regularized TD3
(action-rate penalty 0.1 instead of 0.01), 3 seeds x 1200 episodes, 800 warm-up steps,
one gradient update per environment step (TD3 protocol of the paper). Resumable in chunks.
Usage: python train_offpolicy.py NAME SEED     NAME in {sac, td3_smooth}"""
import os, sys, json, time
import numpy as np, torch
torch.set_num_threads(1)
from train import make_env
from td3 import TD3Agent, ReplayBuffer
from sac import SACAgent
from train_td3 import collect_and_train_td3
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, '..', 'results'); MOD = os.path.join(HERE, '..', 'models_v2'); os.makedirs(MOD, exist_ok=True)
name, seed = sys.argv[1], int(sys.argv[2])
ekw = dict(smooth_coef=0.1) if name == 'td3_smooth' else {}
Agent = SACAgent if name == 'sac' else TD3Agent
final = f'{MOD}/{name}_seed{seed}.pt'
if os.path.exists(final):
    print('exists', final); sys.exit()
ck = f'{MOD}/{name}_seed{seed}_ckpt.pt'
env = make_env(seed=seed, difficulty='moderate', **ekw)
np.random.seed(seed); torch.manual_seed(seed)
agent = Agent(env.obs_dim, env.act_dim); buf = ReplayBuffer(env.obs_dim, env.act_dim)
done_eps, hist, t_used, steps = 0, [], 0.0, 0
if os.path.exists(ck):
    c = torch.load(ck, weights_only=False)
    agent, buf, done_eps, hist, t_used, steps = c['agent'], c['buf'], c['done'], c['hist'], c['t'], c['steps']
    print('resumed at', done_eps, flush=True)
cnt = {'env': steps}
_st = env.step
def step_c(a): cnt['env'] += 1; return _st(a)
env.step = step_c
t0 = time.time()
while done_eps < 1200:
    s0, w0 = cnt['env'], t_used + time.time() - t0
    h = collect_and_train_td3(agent, env, buf, total_episodes=100, log_every=100,
                              warmup_steps=max(0, 800 - buf.size), verbose=False)
    for e in h:
        e['episode'] += done_eps; e['env_steps'] = e.get('env_steps', 0) + s0; e['wall'] = e.get('wall', 0.0) + w0
    hist += h; done_eps += 100
    torch.save(dict(agent=agent, buf=buf, done=done_eps, hist=hist, t=t_used + time.time() - t0, steps=cnt['env']), ck + '.tmp')
    os.replace(ck + '.tmp', ck)
    print(f'{name} seed {seed} episode {done_eps} succ {hist[-1]["success_rate"]:.2f} elapsed {t_used + time.time() - t0:.0f}s', flush=True)
torch.save(dict(actor=agent.actor.state_dict()), final)
json.dump(dict(name=name, seed=seed, history=hist, elapsed=t_used + time.time() - t0, env_steps=cnt['env'],
               grad_updates=agent.update_count), open(f'{RES}/train_v2_{name}_seed{seed}.json', 'w'))
os.remove(ck)
print('DONE', name, seed, flush=True)
