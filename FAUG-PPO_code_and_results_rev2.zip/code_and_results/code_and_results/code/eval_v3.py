"""Revision-2 evaluations (common random numbers throughout).
  heldout  : closed-loop replay of HELD-OUT real sequences (mbt-cube, cube, ellipse-1), speeds 1 and 3,
             moderate and severe dropout, pixel noise 0.5 px. Never used for training or tuning.
  devcap   : (see cap_dev.py)
  tiers    : kin / mujoco / replay(mire-2) evaluation of capped controllers (NAME@CAP).
Controller names: classical_ab, classical_kf, any eval_v2 name, optionally suffixed '@CAP' (cap from cap_dev.CAPS).
Usage: python eval_v3.py MODE NAME [NAME ...]"""
import sys, os, json, time, numpy as np, torch
torch.set_num_threads(1)
import eval_v2 as E
from train import make_env, fallback_action
from controllers import classical_ibvs_action
from replay_env import RealMotionEnv, HELDOUT, PRESETS
from cap_dev import CAPS
RES = E.RES
ENV_KW = dict(E.ENV_KW); ENV_KW.update({'faug_kf_rm': dict(estimator='kf'), 'kf_fixed_rm': dict(estimator='kf'),
                                        'kf_fixed': dict(estimator='kf'), 'kf_age': dict(estimator='kf', obs_mask=('zeta',)),
                                        'kf_cov': dict(estimator='kf', obs_mask=('tau',)), 'kf_none': dict(estimator='kf', obs_mask=('tau', 'zeta')),
                                        'kf_proxy': dict(estimator='kf', unc='proxy'), 'ab_kfcov': dict(unc='kfcov')})
HO_BASE = {'mbt-cube': 21_000_000, 'cube': 22_000_000, 'ellipse-1': 23_000_000}


def parse(name):
    base, cap = (name.split('@') + [None])[:2]
    return base, cap


def env_kw(base):
    if base == 'classical_kf': return dict(estimator='kf')
    if base == 'classical_ab': return {}
    return ENV_KW.get(base, {})


def seeds(base):
    if base.startswith('classical'): return [0]
    if base in E.PPO_NAMES + E.OFF_NAMES + ['fixed']: return E.seeds_of(base)
    return [s for s in range(1, 11) if os.path.exists(os.path.join(E.MOD, f'{base}_seed{s}.pt'))]


def run_episode(env, ag, key, capf):
    E.crn(env, key); o, _ = env.reset(); done = False; t = 0
    while not done:
        if ag is None:
            a = classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred)
        else:
            a_s = fallback_action(env) if getattr(ag, 'uses_fallback', False) else np.zeros(4, np.float32)
            cap = capf(env) if capf else None
            a = ag.act(o, a_safe_np=a_s, sample=False, alpha_cap=cap)[0] if cap is not None else ag.act(o, a_safe_np=a_s, sample=False)[0]
        o, _, done, info = env.step(a); t += 1
    return float(info['success']), float(info['lost']), (t if info['success'] else np.nan), info['rmse_true']


def evaluate(name, mk, base_key, n):
    base, cap = parse(name); capf = CAPS[cap] if cap else None; rs = []
    for sd in seeds(base):
        ag = None if base.startswith('classical') else E.load(base, sd)
        if base.startswith('classical'): pass
        env = mk(env_kw(base))
        R = [run_episode(env, ag, base_key + i, capf) for i in range(n)]
        S, L, T, F = map(np.array, zip(*R))
        rs.append(dict(seed=sd, success_rate=float(S.mean()), lost_rate=float(L.mean()),
                       time_to_success=float(np.nanmean(T)) if np.any(~np.isnan(T)) else None, final_rmse=float(np.median(F)),
                       raw_success=S.tolist()))
    return rs


def merge(fname, upd):
    path = f'{RES}/{fname}'; d = json.load(open(path)) if os.path.exists(path) else {}
    for k, v in upd.items(): d.setdefault(k, {}).update(v)
    json.dump(d, open(path, 'w'))


def m_heldout(names):
    for name in names:
        t0 = time.time(); out = {}
        for src in HELDOUT:
            for spd in [1, 3]:
                for pre in ['moderate', 'severe']:
                    pl, pr = PRESETS[pre]
                    mk = lambda kw, src=src, spd=spd, pl=pl, pr=pr: RealMotionEnv(pl, pr, seed=7070, speed=spd, source=src, pixel_noise_std=0.5, **kw)
                    out[f'{src}|{spd}|{pre}'] = evaluate(name, mk, HO_BASE[src] + spd * 100_000 + (0 if pre == 'moderate' else 50_000), 100)
        merge('v3_heldout.json', {name: out})
        sev = [np.mean([r['success_rate'] for r in out[k]]) for k in out if k.endswith('severe')]
        print(f'heldout {name}: mean severe {np.mean(sev):.3f}  ' + ' '.join(f"{k}:{np.mean([r['success_rate'] for r in out[k]]):.2f}" for k in out), f'({time.time()-t0:.0f}s)', flush=True)


def m_tiers(names):
    for name in names:
        out = {}
        for pre in ['mild', 'moderate', 'severe']:
            out[f'kin|{pre}'] = evaluate(name, lambda kw, pre=pre: make_env(seed=999, difficulty=pre, **kw), E.BASE['kin'][pre], 300)
            pl, pr = PRESETS[pre]
            out[f'replay|1|{pre}'] = evaluate(name, lambda kw, pl=pl, pr=pr: RealMotionEnv(pl, pr, seed=4242, speed=1, **kw), E.BASE['replay'][pre], 100)
            out[f'replay|3|{pre}'] = evaluate(name, lambda kw, pl=pl, pr=pr: RealMotionEnv(pl, pr, seed=4242, speed=3, pixel_noise_std=0.5, **kw), E.BASE['replay'][pre], 100)
        merge('v3_tiers.json', {name: out})
        print(f'tiers {name}: ' + ' '.join(f"{k}:{np.mean([r['success_rate'] for r in out[k]]):.3f}" for k in out), flush=True)


def m_mujoco(names):
    from mujoco_env import MuJoCoIBVSEnv
    for name in names:
        out = {}
        for pre, (pl, pr) in PRESETS.items():
            out[f'mujoco|{pre}'] = evaluate(name, lambda kw, pl=pl, pr=pr: MuJoCoIBVSEnv(seed=999, p_lose=pl, p_recover=pr, **kw), E.BASE['mujoco'][pre], 100)
        merge('v3_tiers.json', {name: out})
        print(f'mujoco {name}: ' + ' '.join(f"{k}:{np.mean([r['success_rate'] for r in out[k]]):.3f}" for k in out), flush=True)


STRESS = {  # name: (preset, env kwargs)
    'lat200': ('moderate', dict(latency=2)), 'lat300': ('moderate', dict(latency=3)),
    'motion_dropout': ('moderate', dict(md_dropout=3.0)), 'long_burst': ('burst', {}),
    'actuator50': ('moderate', dict(act_scale=0.5)), 'noise2px': ('moderate', dict(pixel_noise_std=2.0)),
}
STRESS_BASE = 31_000_000


def m_stress(names):
    from env import IBVSDropoutEnv
    for name in names:
        out = {}
        for j, (sn, (pre, kw)) in enumerate(STRESS.items()):
            pl, pr = (0.06, 0.06) if pre == 'burst' else PRESETS[pre]
            mk = lambda ekw, pl=pl, pr=pr, kw=kw: IBVSDropoutEnv(seed=999, p_lose=pl, p_recover=pr, **{**ekw, **kw})
            out[sn] = evaluate(name, mk, STRESS_BASE + j * 100_000, 100)
        merge('v3_stress.json', {name: out})
        print(f'stress {name}: ' + ' '.join(f"{k}:{np.mean([r['success_rate'] for r in out[k]]):.3f}" for k in out), flush=True)


def m_arm(names):
    from arm_env import ArmIBVSEnv
    for name in names:
        out = {}
        for j, (cn, pre, lat) in enumerate([('moderate', 'moderate', 0), ('severe', 'severe', 0), ('severe_lat200', 'severe', 2)]):
            pl, pr = PRESETS[pre]
            mk = lambda ekw, pl=pl, pr=pr, lat=lat: ArmIBVSEnv(seed=999, p_lose=pl, p_recover=pr, latency=lat,
                                                               **{k: v for k, v in ekw.items() if k in ('estimator',)})
            out[cn] = evaluate(name, mk, 41_000_000 + j * 100_000, 100)
        merge('v3_arm.json', {name: out})
        print(f'arm {name}: ' + ' '.join(f"{k}:{np.mean([r['success_rate'] for r in out[k]]):.3f}" for k in out), flush=True)


def m_effort(names):
    """Effort ||a||^2, action-rate energy ||a_t - a_{t-1}||^2, commanded translational jerk (m/s^3, second
    difference of the commanded velocity / dt^2), and the fraction of STOCHASTIC (training-mode) actions
    whose pre-clip sample leaves [-1, 1] (where the Gaussian likelihood is only approximate)."""
    from env import IBVSDropoutEnv, DT
    for name in names:
        base, cap = parse(name); capf = CAPS[cap] if cap else None; rs = []
        for sd in seeds(base):
            ag = None if base.startswith('classical') else E.load(base, sd)
            env = make_env(seed=77, difficulty='moderate', **env_kw(base))
            Ef, Ar, Jk, Cl = [], [], [], []
            for i in range(120):
                E.crn(env, 61_000_000 + i); o, _ = env.reset(); done = False; V = []
                while not done:
                    if ag is None:
                        a = classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred)
                    else:
                        a_s = fallback_action(env) if getattr(ag, 'uses_fallback', False) else np.zeros(4, np.float32)
                        c = capf(env) if capf else None
                        kw = {} if c is None else dict(alpha_cap=c)
                        a = ag.act(o, a_safe_np=a_s, sample=False, **kw)[0]
                        if hasattr(ag, 'actor') and hasattr(ag.actor, 'trunk'):
                            a_st = ag.act(o, a_safe_np=a_s, sample=True, **kw)[0]; Cl.append(float(np.any(np.abs(a_st) > 1)))
                    a = np.clip(a, -1, 1)
                    Ef.append(float(np.sum(a ** 2))); Ar.append(float(np.sum((a - env.prev_action) ** 2)))
                    V.append(a[:3] * IBVSDropoutEnv.V_LIM[:3])
                    o, _, done, _ = env.step(a)
                V = np.array(V)
                if len(V) >= 3: Jk += list(np.linalg.norm((V[2:] - 2 * V[1:-1] + V[:-2]) / DT ** 2, axis=1))
            rs.append(dict(seed=sd, effort=float(np.mean(Ef)), action_rate=float(np.mean(Ar)), jerk_rms=float(np.sqrt(np.mean(np.square(Jk)))),
                           stoch_clip_frac=(float(np.mean(Cl)) if Cl else None)))
        merge('v3_effort.json', {name: {'moderate': rs}})
        print(f"effort {name}: effort {np.mean([r['effort'] for r in rs]):.3e} action-rate {np.mean([r['action_rate'] for r in rs]):.3e} "
              f"jerk {np.mean([r['jerk_rms'] for r in rs]):.3e} clip {rs[0]['stoch_clip_frac']}", flush=True)


def m_real(names):
    """Tier 3 (rendered RGB + OpenCV detection), moderate preset, 5 seeds x 30 episodes, strict and lenient rules."""
    from mujoco_realimage_env import RealImageMuJoCoEnv
    for name in names:
        base, cap = parse(name); capf = CAPS[cap] if cap else None; out = {}
        for strict in [True, False]:
            rs = []
            for sd in ([0] if base.startswith('classical') else [1, 2, 3, 4, 5]):
                ag = None if base.startswith('classical') else E.load(base, sd)
                env = RealImageMuJoCoEnv(p_lose=0.08, p_recover=0.18, seed=999, strict_detection_termination=strict,
                                         **{k: v for k, v in env_kw(base).items() if k == 'estimator'})
                R = [run_episode(env, ag, E.BASE['real'] + i, capf) for i in range(30)]; env.renderer.close()
                S, L, T, F = map(np.array, zip(*R))
                rs.append(dict(seed=sd, success_rate=float(S.mean()), lost_rate=float(L.mean()), raw_success=S.tolist()))
            out['strict' if strict else 'lenient'] = rs
        merge('v3_real.json', {name: out})
        print(f'real {name}: ' + ' '.join(f"{k}:{np.mean([r['success_rate'] for r in out[k]]):.3f}" for k in out), flush=True)


if __name__ == '__main__':
    globals()['m_' + sys.argv[1]](sys.argv[2:])
