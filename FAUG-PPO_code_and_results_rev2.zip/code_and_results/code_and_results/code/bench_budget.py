"""Isolated compute cost on one CPU core (run with no other jobs): time per environment interaction
(simulator step + action selection [+ fallback]) and per gradient update (one minibatch of 256).
Combined with the logged interaction and update counts this gives the compute budget of each method.
Output: results/v3_budget.json"""
import json, time, numpy as np, torch
torch.set_num_threads(1)
from train import make_env, fallback_action
from ppo import Agent, RolloutBuffer
from sac import SACAgent
from td3 import TD3Agent, ReplayBuffer

def t_env(agent, kind, n=3000):
    env = make_env(seed=1, difficulty='moderate', estimator='kf'); o, _ = env.reset(); t0 = time.perf_counter()
    for _ in range(n):
        if kind == 'ppo':
            a = agent.act(o, a_safe_np=fallback_action(env), sample=True)[0]
        else:
            a = agent.act(o, sample=True)[0]
        o, _, d, _ = env.step(a)
        if d: o, _ = env.reset()
    return (time.perf_counter() - t0) / n * 1e3

out = {}
ag = Agent(22, 4, gate_single=True); env = make_env(seed=1, difficulty='moderate', estimator='kf')
buf = RolloutBuffer(); o, _ = env.reset()
for _ in range(16 * 70):
    a_s = fallback_action(env); a, lp, v, vp, al = ag.act(o, a_safe_np=a_s, sample=True)
    o2, r, d, _ = env.step(a); buf.add(o, a, r, d, lp, v, vp, a_s, 0.0); o = o2
    if d: o, _ = env.reset()
n_mb = int(np.ceil(len(buf.obs) / 256)) * 8
t0 = time.perf_counter(); ag.update(buf); upd = (time.perf_counter() - t0) / n_mb * 1e3
out['FAUG-PPO'] = dict(env_step_ms=t_env(ag, 'ppo'), update_ms=upd)
for name, A in [('SAC', SACAgent), ('TD3', TD3Agent)]:
    ag = A(22, 4); rb = ReplayBuffer(22, 4)
    for _ in range(2000): rb.add(np.random.randn(22), np.random.uniform(-1, 1, 4), 0.0, np.random.randn(22), 0.0)
    for _ in range(20): ag.update(rb)
    t0 = time.perf_counter()
    for _ in range(500): ag.update(rb)
    out[name] = dict(env_step_ms=t_env(ag, 'off'), update_ms=(time.perf_counter() - t0) / 500 * 1e3)
print(json.dumps(out, indent=1))
json.dump(out, open('../results/v3_budget.json', 'w'), indent=1)
