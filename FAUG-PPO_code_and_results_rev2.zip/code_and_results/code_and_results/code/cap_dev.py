"""Development-set sweep of risk-aware authority caps alpha_exec = min(alpha_PPO, alpha_max(state)).
Development data only: kinematic simulator (severe) and mire-2 real-motion replay (severe).
Held-out real sequences (mbt-cube, cube, ellipse-1) are NOT used here.
Usage: python cap_dev.py MODEL [seeds]   -> results/cap_dev_MODEL.json"""
import sys, json, numpy as np, torch
torch.set_num_threads(1)
import eval_v2 as E
from train import make_env, fallback_action
from replay_env import RealMotionEnv

CAPS = {
    'none': lambda env: None,
    'const0.2': lambda env: 0.2,
    'const0.1': lambda env: 0.1,
    'cov3': lambda env: 0.5 * 9.0 / (9.0 + env.P[0, 0]),
    'cov6': lambda env: 0.5 * 36.0 / (36.0 + env.P[0, 0]),
    'cov12': lambda env: 0.5 * 144.0 / (144.0 + env.P[0, 0]),
    'age3': lambda env: 0.5 * np.exp(-env.channel.steps_since_valid / 3.0),
    'age6': lambda env: 0.5 * np.exp(-env.channel.steps_since_valid / 6.0),
    'switch': lambda env: (None if env.channel.steps_since_valid == 0 else 0.0),     # hard switch to fallback in dropout
    'cov1': lambda env: 0.5 * 1.0 / (1.0 + env.P[0, 0]),
    'cov2': lambda env: 0.5 * 4.0 / (4.0 + env.P[0, 0]),
    'cov3a03': lambda env: 0.3 * 9.0 / (9.0 + env.P[0, 0]),                            # theorem-compliant ceiling 0.3
    'cov2a03': lambda env: 0.3 * 4.0 / (4.0 + env.P[0, 0]),
    'cov3m03': lambda env: min(0.3, 0.5 * 9.0 / (9.0 + env.P[0, 0])),
    'const0.3': lambda env: 0.3,                                                        # ceiling only (component ablation)
    'switch03': lambda env: (0.3 if env.channel.steps_since_valid == 0 else 0.0),     # ceiling + hard switch (component ablation)
}


def episode(env, ag, key, capf):
    E.crn(env, key); o, _ = env.reset(); done = False
    while not done:
        a_s = fallback_action(env)
        a, *_ = ag.act(o, a_safe_np=a_s, sample=False, alpha_cap=capf(env))
        o, _, done, info = env.step(a)
    return float(info['success']), float(info['lost'])


if __name__ == '__main__':
    name = sys.argv[1]; seeds = [int(x) for x in sys.argv[2].split(',')] if len(sys.argv) > 2 else list(range(1, 11))
    caps = sys.argv[3].split(',') if len(sys.argv) > 3 else list(CAPS)
    doms = {'sim': (lambda: make_env(seed=999, difficulty='severe', estimator='kf'), E.BASE['kin']['severe']),
            'replay': (lambda: RealMotionEnv(0.14, 0.12, seed=4242, speed=1, estimator='kf'), E.BASE['replay']['severe']),
            'stress': (lambda: RealMotionEnv(0.14, 0.12, seed=4242, speed=3, pixel_noise_std=0.5, estimator='kf'), E.BASE['replay']['severe'])}
    out = {}
    for c in caps:
        out[c] = {}
        for d, (mk, base) in doms.items():
            rs = []
            for sd in seeds:
                ag = E.load(name, sd); env = mk()
                S, L = zip(*[episode(env, ag, base + i, CAPS[c]) for i in range(100)])
                rs.append(dict(seed=sd, success_rate=float(np.mean(S)), lost_rate=float(np.mean(L))))
            out[c][d] = rs
        print(name, c, {d: round(float(np.mean([r['success_rate'] for r in out[c][d]])), 3) for d in doms}, flush=True)
    fn = f'../results/cap_dev_{name}.json'
    import os
    old = json.load(open(fn)) if os.path.exists(fn) else {}
    old.update(out); json.dump(old, open(fn, 'w'), indent=1)
