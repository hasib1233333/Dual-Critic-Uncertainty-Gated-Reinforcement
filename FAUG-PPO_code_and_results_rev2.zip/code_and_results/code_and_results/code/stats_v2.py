"""Statistics for the C&EE revision (matched budgets, common random numbers)."""
import json, os, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.proportion import proportion_confint
RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results')
K = json.load(open(f'{RES}/v2_kin.json'))
P = ['mild', 'moderate', 'severe']
names = [n for n in ['faug_kf', 'faug_sc', 'fixed', 'resid', 'dcug_3k', 'sc_3k', 'sac', 'td3_smooth', 'td3'] if n in K]
def per_seed(n, p): return np.array([r['success_rate'] for r in K[n][p]])
summary = {}
for n in names:
    summary[n] = {p: dict(mean=float(per_seed(n, p).mean()), sd=float(per_seed(n, p).std(ddof=1)), min=float(per_seed(n, p).min()),
                          lost=float(np.mean([r['lost_rate'] for r in K[n][p]])),
                          collapses=int(sum(r['success_rate'] < 0.05 for r in K[n][p])), n=len(K[n][p])) for p in P}
    print(f"{n:10s}", ' | '.join(f"{p}: {summary[n][p]['mean']*100:5.1f}±{summary[n][p]['sd']*100:4.1f} (min {summary[n][p]['min']*100:4.1f}, lost {summary[n][p]['lost']*100:4.1f}, coll {summary[n][p]['collapses']})" for p in P))
for e in ['ab', 'kf']:
    print('classical', e, {p: round(K['classical'][e][p]['success_rate'] * 100, 1) for p in P})
def tests(ref):
    rows = []
    for p in P:
        a = per_seed(ref, p)
        for n in names:
            if n == ref: continue
            b = per_seed(n, p); r = stats.ttest_ind(a, b, equal_var=False)
            sp = np.sqrt(((len(a)-1)*a.var(ddof=1) + (len(b)-1)*b.var(ddof=1)) / (len(a)+len(b)-2))
            g = (a.mean() - b.mean()) / sp * (1 - 3 / (4*(len(a)+len(b)) - 9)) if sp > 0 else np.nan
            # episode-paired (common random numbers): per-episode success fraction across seeds, Wilcoxon
            ea = np.mean([r_['raw_success'] for r_ in K[ref][p]], 0); eb = np.mean([r_['raw_success'] for r_ in K[n][p]], 0)
            w = stats.wilcoxon(ea, eb, zero_method='zsplit').pvalue if np.any(ea != eb) else 1.0
            rows.append(dict(preset=p, vs=n, diff=float(a.mean() - b.mean()), t=float(r.statistic), p=float(r.pvalue), g=float(g), p_episode=float(w)))
        for est in ['ab', 'kf']:
            c = K['classical'][est][p]['success_rate']; r = stats.ttest_1samp(a, c)
            rows.append(dict(preset=p, vs=f'classical_{est}', diff=float(a.mean() - c), t=float(r.statistic), p=float(r.pvalue), g=float('nan'), p_episode=float('nan')))
    rej, padj, _, _ = multipletests([r['p'] for r in rows], method='holm')
    for r, pa in zip(rows, padj): r['p_holm'] = float(pa)
    return rows
out = dict(summary=summary, classical={e: {p: K['classical'][e][p]['success_rate'] for p in P} for e in ['ab', 'kf']})
for ref in ['faug_kf', 'faug_sc']:
    rows = tests(ref); out[f'tests_{ref}'] = rows
    print(f'\n=== {ref} vs comparators (Welch, Holm over {len(rows)}) ===')
    for r in rows:
        print(f"{r['preset']:8s} {r['vs']:14s} {r['diff']*100:+6.1f}  p={r['p']:.2e}  holm={r['p_holm']:.2e}  g={r['g']:5.2f}  p_ep={r['p_episode']:.2e}")
tot = sum(summary[n]['moderate']['collapses'] for n in ['faug_kf', 'faug_sc', 'fixed', 'resid', 'dcug_3k'] if n in summary)
print('\ncollapses (moderate): ', {n: summary[n]['moderate']['collapses'] for n in names})
json.dump(out, open(f'{RES}/v2_stats.json', 'w'), indent=1)
