"""Calibrate the constant-velocity Kalman filter's acceleration-noise std q so that
the normalized estimation error squared (NEES, 1-D per feature coordinate) is ~1.
Calibration rollouts: env seeds 500-519; validation: 600-619 (moderate preset,
fallback IBVS controller acting on the KF prediction). Output: results/kf_calibration.json"""
import json, numpy as np
from train import make_env
from controllers import fallback_action
from eval_faug import RESULTS

def nees(q, seeds, eps=15):
    vals, vis_v, drop_v, cover = [], [], [], []
    for sd in seeds:
        env = make_env(seed=sd, difficulty='moderate', estimator='kf', kf_q=q)
        for _ in range(eps):
            env.reset(); done = False
            while not done:
                _, _, done, info = env.step(fallback_action(env))
                e2 = (env.true_s - env.s_pred) ** 2 / env.P[0, 0]
                vals.append(e2.mean()); cover.append(np.mean(np.sqrt(e2) < 1.96))
                (vis_v if info['visible'] else drop_v).append(e2.mean())
    return float(np.mean(vals)), float(np.mean(vis_v)), float(np.mean(drop_v) if drop_v else np.nan), float(np.mean(cover))

grid = [5, 10, 20, 40, 80, 160, 320, 640]
res = {q: nees(q, range(500, 520)) for q in grid}
for q, r in res.items(): print(f'q={q:5}: NEES all {r[0]:.2f} visible {r[1]:.2f} dropout {r[2]:.2f} 95%-coverage {r[3]:.3f}')
best = min(grid, key=lambda q: abs(np.log(res[q][0])))
# refine geometrically around best
fine = [best * f for f in [0.6, 0.75, 0.9, 1.0, 1.15, 1.3, 1.6]]
rf = {q: nees(q, range(500, 520)) for q in fine}
best = min(fine, key=lambda q: abs(np.log(rf[q][0])))
val = nees(best, range(600, 620))
print('best q', best, 'calibration', rf[best], 'held-out validation', val)
json.dump(dict(grid={str(k): v for k, v in res.items()}, fine={str(k): v for k, v in rf.items()},
               q=best, validation=dict(nees_all=val[0], nees_visible=val[1], nees_dropout=val[2], coverage95=val[3])),
          open(f'{RESULTS}/kf_calibration.json', 'w'), indent=1)
