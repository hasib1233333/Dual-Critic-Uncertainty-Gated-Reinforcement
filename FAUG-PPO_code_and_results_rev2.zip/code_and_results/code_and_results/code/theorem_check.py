"""Numerical check of Theorem 1's assumptions and bound on FAUG-PPO (KF) rollouts (kinematic tier).
Per step we measure: fallback saturation (A3), executed-action clipping (A3), gate alpha (A3),
||J^+||_2 (A1), gamma_t = ||dJ^+/dt e|| / ||eps|| (A2), estimation error ||s_hat - s|| (A4),
target-induced feature motion ||d|| (A4), and the task-space error eps = J^+ e.
Then: c = (1-alpha_bar) kappa lambda - gamma_bar, b = kappa lambda sigma_bar e_bar + 2 alpha_bar ||D|| + sigma_bar d_bar,
and the predicted ultimate bound b/c is compared with the observed late-episode ||eps||.
Output: results/theorem_check.json"""
import json, sys, numpy as np, torch
torch.set_num_threads(1)
import eval_v2 as E
from train import make_env
from env import image_jacobian, project, IBVSDropoutEnv, DT
from controllers import fallback_action
KAPPA_LAMBDA = 0.5 * 1.2
CAP = len(sys.argv) > 1 and sys.argv[1] == 'cap'
CAPF = (lambda env: 0.3 * 9.0 / (9.0 + env.P[0, 0])) if CAP else (lambda env: None)
D = np.diag(IBVSDropoutEnv.V_LIM)
out = {}
for pre in ['moderate', 'severe']:
    S = dict(sat=[], clip=[], alpha=[], sig=[], gam=[], es=[], d=[], eps=[], eps_late=[], es_drop=[])
    for sd in range(1, 11):
        ag = E.load('faug_kf', sd); env = make_env(seed=999, difficulty=pre, estimator='kf')
        for i in range(30):
            E.crn(env, E.BASE['kin'][pre] + i); o, _ = env.reset(); done = False; t = 0
            while not done:
                J = image_jacobian(env.pose, target_xy=env.target_xy); Jp = np.linalg.pinv(J)
                e = env.true_s - env.s_star; eps = Jp @ e
                Jo = image_jacobian(env.pose); err = env.s_pred - env.s_star
                raw = -KAPPA_LAMBDA * (np.linalg.pinv(Jo) @ err) / IBVSDropoutEnv.V_LIM
                a_s = fallback_action(env)
                c_ = CAPF(env)
                a, _, _, _, al = ag.act(o, a_safe_np=a_s, sample=False, **({} if c_ is None else dict(alpha_cap=c_)))
                pose0, tx0, s_hat = env.pose.copy(), env.target_xy.copy(), env.s_pred.copy()
                o, _, done, info = env.step(a)
                s_mov, _, _, _ = project(pose0, target_xy=env.target_xy); s_fix, _, _, _ = project(pose0, target_xy=tx0)
                Jp1 = np.linalg.pinv(image_jacobian(env.pose, target_xy=env.target_xy))
                ne = np.linalg.norm(eps)
                S['sat'].append(float(np.abs(raw).max() > 1)); S['clip'].append(float(np.abs(a).max() > 1 + 1e-9)); S['alpha'].append(al)
                S['sig'].append(np.linalg.norm(Jp, 2)); S['es'].append(np.linalg.norm(s_hat - (env.true_s if False else project(pose0, target_xy=tx0)[0])))
                S['d'].append(np.linalg.norm((s_mov - s_fix) / DT)); S['eps'].append(ne)
                if ne > 1e-3: S['gam'].append(np.linalg.norm((Jp1 - Jp) / DT @ e) / ne)
                if not info['visible']: S['es_drop'].append(S['es'][-1])
                if t >= 40: S['eps_late'].append(ne)
                t += 1
    A = {k: np.array(v) for k, v in S.items()}
    ns = A['sat'] == 0
    q = lambda x, p=95: float(np.percentile(x, p))
    abar = 0.3 if CAP else q(A['alpha'], 99); sig = q(A['sig']); gam = q(A['gam']); ebar = q(A['es']); dbar = q(A['d'])
    c = (1 - abar) * KAPPA_LAMBDA - gam; b = KAPPA_LAMBDA * sig * ebar + 2 * abar * np.linalg.norm(D, 2) + sig * dbar
    out[pre] = dict(n_steps=len(A['sat']), frac_fallback_saturated=float(A['sat'].mean()), frac_action_clipped=float(A['clip'].mean()),
                    alpha_p99=abar, alpha_max=float(A['alpha'].max()), sigma_bar_p95=sig, gamma_p95=gam, gamma_median=float(np.median(A['gam'])),
                    e_bar_p95=ebar, e_bar_dropout_p95=q(A['es_drop']), d_bar_p95=dbar, c=c, b=b, bound=(b / c if c > 0 else None),
                    eps_late_p50=float(np.median(A['eps_late'])) if len(A['eps_late']) else None,
                    eps_late_p95=q(A['eps_late']) if len(A['eps_late']) else None, eps_p95=q(A['eps']))
    print(pre, json.dumps(out[pre]), flush=True)
json.dump(out, open('../results/theorem_check%s.json' % ('_cap' if CAP else ''), 'w'), indent=1)
