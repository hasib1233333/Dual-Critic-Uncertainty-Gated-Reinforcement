"""Shared constant-velocity Kalman-filter step (per feature coordinate, shared 2x2 covariance)."""
import numpy as np

def kf_init(env, sigma):
    env.P = np.array([[max(sigma, 0.5) ** 2, 0.0], [0.0, 25.0]])

def kf_step(env, visible, z, dt, q, sigma):
    F = np.array([[1.0, dt], [0.0, 1.0]])
    Q = q ** 2 * np.array([[dt ** 4 / 4, dt ** 3 / 2], [dt ** 3 / 2, dt ** 2]])
    env.s_pred = env.s_pred + env.s_vel * dt
    env.P = F @ env.P @ F.T + Q
    if visible:
        R = max(sigma, 0.5) ** 2
        K = env.P[:, 0] / (env.P[0, 0] + R); inn = z - env.s_pred
        env.s_pred = env.s_pred + K[0] * inn; env.s_vel = env.s_vel + K[1] * inn
        env.P = env.P - np.outer(K, env.P[0, :])
    env.cov_trace = 8 * env.P[0, 0]
