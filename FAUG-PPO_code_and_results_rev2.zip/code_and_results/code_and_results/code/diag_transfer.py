"""Diagnose the real-motion transfer gap: FAUG-PPO (KF) vs the classical Kalman controller on
mire-2 replay (development data) and the kinematic simulator, severe preset, common random numbers."""
import numpy as np, torch, json, sys
import eval_v2 as E
from train import make_env, fallback_action
from controllers import classical_ibvs_action
from replay_env import RealMotionEnv, SIGMA_REAL


def roll(env, ag, key):
    E.crn(env, key); o, _ = env.reset(); done = False; rec = []
    while not done:
        a_s = fallback_action(env) if ag is not None else None
        if ag is None:
            a = classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred); al = 0.0
        else:
            a, _, _, _, al = ag.act(o, a_safe_np=a_s, sample=False)
        o, r, done, info = env.step(a)
        rec.append(dict(vis=info['visible'], tau=env.channel.steps_since_valid, nis=env.nis, alpha=float(al),
                        dev=float(np.abs(np.clip(a, -1, 1) - (a_s if a_s is not None else a)).max()), rmse=info['rmse_true'],
                        err_pred=float(np.sqrt(np.mean((env.s_pred - env.true_s) ** 2)))))
    return info['success'], info['lost'], rec


out = {}
for dom in ['replay', 'sim']:
    mk = (lambda: RealMotionEnv(0.14, 0.12, seed=4242, speed=1, estimator='kf')) if dom == 'replay' else \
         (lambda: make_env(seed=999, difficulty='severe', estimator='kf'))
    base = E.BASE['replay']['severe'] if dom == 'replay' else E.BASE['kin']['severe']
    n = 100
    cl = [roll(mk(), None, base + i) for i in range(n)]
    fa = {sd: [roll(mk(), E.load('faug_kf', sd), base + i) for i in range(n)] for sd in [1, 2, 3]}
    nis = np.array([r['nis'] for _, _, rec in cl for r in rec if r['vis']]); nis = nis[np.isfinite(nis)]
    errp = np.array([r['err_pred'] for _, _, rec in cl for r in rec if not r['vis']])
    S_cl = np.array([s for s, _, _ in cl])
    worse = better = 0
    for sd in fa:
        S_fa = np.array([s for s, _, _ in fa[sd]]); worse += int(np.sum(S_cl & ~S_fa)); better += int(np.sum(~S_cl & S_fa))
    dev_drop = np.array([r['dev'] for sd in fa for _, _, rec in fa[sd] for r in rec if not r['vis']])
    al = np.array([r['alpha'] for sd in fa for _, _, rec in fa[sd] for r in rec])
    out[dom] = dict(cl_success=float(S_cl.mean()), fa_success={sd: float(np.mean([s for s, _, _ in fa[sd]])) for sd in fa},
                    eps_classical_only=worse, eps_faug_only=better, nis_median=float(np.median(nis)), nis_p95=float(np.percentile(nis, 95)),
                    nis_frac_gt3=float(np.mean(nis > 3)), pred_err_dropout_median=float(np.median(errp)), pred_err_dropout_p95=float(np.percentile(errp, 95)),
                    faug_dev_dropout_median=float(np.median(dev_drop)), alpha_mean=float(al.mean()))
    print(dom, json.dumps(out[dom]), flush=True)
json.dump(out, open('../results/diag_transfer.json', 'w'), indent=1)
