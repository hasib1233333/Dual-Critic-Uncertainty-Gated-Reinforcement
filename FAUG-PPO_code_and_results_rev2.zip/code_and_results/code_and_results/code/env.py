"""
Eye-in-hand Image-Based Visual Servoing (IBVS) environment with
Markov-modulated intermittent camera dropout.

Camera looks straight down at a planar square target (4 corner features).
Controllable DOF: [vx, vy, vz, wz]  (horizontal translation, height rate, yaw rate)
State integrated in the world frame; target is static at the world origin.
"""
import numpy as np

F = 400.0          # focal length in pixel units
IMG_HALF = 180.0
KF_Q_DEFAULT = 72.0   # px/s^2; calibrated by calibrate_kf.py (held-out NEES 0.96, 95% coverage 0.956)
TARGET_HALF = 0.10 # half side length of square target (m)
Z_DESIRED = 0.60    # desired camera height above target (m)
DT = 0.1
MAX_STEPS = 100
SUCCESS_TOL = 5.5   # px RMSE considered "converged"
SUCCESS_HOLD = 8    # must stay converged this many consecutive steps

# 4 target corners in world frame (z = 0 plane)
TARGET_PTS = np.array([
    [-TARGET_HALF, -TARGET_HALF, 0.0],
    [ TARGET_HALF, -TARGET_HALF, 0.0],
    [ TARGET_HALF,  TARGET_HALF, 0.0],
    [-TARGET_HALF,  TARGET_HALF, 0.0],
])


def project(pose, pts=TARGET_PTS, target_xy=(0.0, 0.0)):
    """pose = (px, py, pz, theta). Returns feature vector s (8,) and per-point zc (4,)."""
    px, py, pz, th = pose
    tx, ty = target_xy
    dx = (pts[:, 0] + tx) - px
    dy = (pts[:, 1] + ty) - py
    ct, st = np.cos(th), np.sin(th)
    xc = dx * ct + dy * st
    yc = -dx * st + dy * ct
    zc = np.full(4, pz)
    u = F * xc / zc
    v = F * yc / zc
    s = np.stack([u, v], axis=1).reshape(-1)
    return s, zc, u, v


def image_jacobian(pose, pts=TARGET_PTS, target_xy=(0.0, 0.0)):
    """Analytic interaction matrix J (8x4) mapping [vx,vy,vz,wz] -> ds/dt."""
    px, py, pz, th = pose
    tx, ty = target_xy
    dx = (pts[:, 0] + tx) - px
    dy = (pts[:, 1] + ty) - py
    ct, st = np.cos(th), np.sin(th)
    xc = dx * ct + dy * st
    yc = -dx * st + dy * ct
    zc = pz
    u = F * xc / zc
    v = F * yc / zc
    rows = []
    for i in range(4):
        Ju = [-F * ct / zc, -F * st / zc, -u[i] / zc, v[i]]
        Jv = [ F * st / zc, -F * ct / zc, -v[i] / zc, -u[i]]
        rows.append(Ju)
        rows.append(Jv)
    return np.array(rows)


class DropoutChannel:
    """Two-state Markov chain: VISIBLE <-> DROPOUT."""
    def __init__(self, p_lose, p_recover, rng):
        self.p_lose = p_lose
        self.p_recover = p_recover
        self.rng = rng
        self.visible = True
        self.steps_since_valid = 0

    def reset(self):
        self.visible = True
        self.steps_since_valid = 0

    def step(self):
        if self.visible:
            if self.rng.random() < self.p_lose:
                self.visible = False
        else:
            if self.rng.random() < self.p_recover:
                self.visible = True
        if self.visible:
            self.steps_since_valid = 0
        else:
            self.steps_since_valid += 1
        return self.visible


class IBVSDropoutEnv:
    """
    Observation (RL agents): 8 (predicted/observed feature error, normalized)
                              + 8 (feature velocity estimate, normalized)
                              + 1 (steps_since_valid, normalized)
                              + 1 (EKF covariance-trace proxy, normalized)
                              + 4 (previous action)  = 22 dims
    Action: 4 continuous in [-1,1], scaled to physical velocity limits.
    """
    V_LIM = np.array([0.25, 0.25, 0.20, 0.8])  # vx,vy,vz,wz limits (m/s, rad/s)

    def __init__(self, p_lose=0.06, p_recover=0.20, pose_range=None, seed=0,
                 pixel_noise_std=0.5, target_drift_std=0.006, process_noise_std=0.006,
                 estimator='ab', kf_q=None, smooth_coef=0.01, obs_mask=(), unc='native',
                 latency=0, md_dropout=0.0, act_scale=1.0):
        self.rng = np.random.default_rng(seed)
        # estimator: 'ab' = fixed-gain alpha-beta filter with heuristic uncertainty ramp (original);
        #            'kf' = constant-velocity Kalman filter whose covariance is propagated exactly.
        self.estimator = estimator
        self.kf_q = KF_Q_DEFAULT if kf_q is None else kf_q   # accel. noise std (px/s^2)
        self.smooth_coef = smooth_coef
        # factorial ablation: obs_mask zeroes 'tau' and/or 'zeta' in the observation;
        # unc='proxy' feeds the heuristic alpha-beta uncertainty ramp even when estimator='kf'.
        self.obs_mask = tuple(obs_mask); self.unc = unc
        # stress tests: command latency (control steps), motion-dependent dropout gain, actuator authority scale
        self.latency, self.md_dropout, self.act_scale = int(latency), float(md_dropout), float(act_scale)
        self.p_lose = p_lose
        self.p_recover = p_recover
        self.channel = DropoutChannel(p_lose, p_recover, self.rng)
        self.pixel_noise_std = pixel_noise_std
        self.target_drift_std = target_drift_std   # target platform drift speed std (m/s)
        self.process_noise_std = process_noise_std  # unmodeled camera-platform disturbance
        self.pose_range = pose_range or dict(xy=0.15, z=(0.45, 0.85), th=0.5)
        self.s_star, _, _, _ = project((0.0, 0.0, Z_DESIRED, 0.0))
        self.obs_dim = 22
        self.act_dim = 4

    def reset(self, difficulty=None):
        r = self.pose_range
        x0 = self.rng.uniform(-r['xy'], r['xy'])
        y0 = self.rng.uniform(-r['xy'], r['xy'])
        z0 = self.rng.uniform(*r['z'])
        th0 = self.rng.uniform(-r['th'], r['th'])
        if difficulty is not None:
            scale = difficulty
            x0, y0, th0 = x0 * scale, y0 * scale, th0 * scale
        self.pose = np.array([x0, y0, z0, th0])
        self.target_xy = np.zeros(2)
        self.target_vel = self.rng.normal(0, self.target_drift_std, size=2)
        self.channel.reset()
        self.t = 0
        self.prev_action = np.zeros(4)
        self.true_s, self.zc, _, _ = project(self.pose, target_xy=self.target_xy)
        self.s_pred = self.true_s.copy()   # EKF predicted features
        self.s_vel = np.zeros(8)           # EKF predicted feature velocity
        self.cov_trace = 0.0
        r2 = max(self.pixel_noise_std, 0.5) ** 2
        self.P = np.array([[r2, 0.0], [0.0, 25.0]])  # per-coordinate [pos, vel] covariance (px^2, px^2/s^2)
        if self.estimator == 'kf':
            self.cov_trace = 8 * self.P[0, 0]
        self.proxy_zeta = 0.0
        self.nis = float('nan')
        self.queue = [np.zeros(4)] * self.latency
        self.P_sh = self.P.copy(); self.kfcov_zeta = 8 * self.P_sh[0, 0]   # covariance-only shadow KF (unc='kfcov')
        self._success_streak = 0
        self.last_valid_s = self.true_s.copy()
        return self._obs(), {}

    def _fov_violation(self, s):
        return np.any(np.abs(s) > IMG_HALF * 1.6)

    def _kf_step(self, visible):
        F = np.array([[1.0, DT], [0.0, 1.0]]); q2 = self.kf_q ** 2
        Q = q2 * np.array([[DT ** 4 / 4, DT ** 3 / 2], [DT ** 3 / 2, DT ** 2]])
        self.s_pred = self.s_pred + self.s_vel * DT
        self.P = F @ self.P @ F.T + Q
        if visible:
            z = self.true_s + self.rng.normal(0, self.pixel_noise_std, size=8)
            R = max(self.pixel_noise_std, 0.5) ** 2
            S = self.P[0, 0] + R; K = self.P[:, 0] / S
            innov = z - self.s_pred
            self.nis = float(np.mean(innov ** 2 / S))
            self.s_pred = self.s_pred + K[0] * innov
            self.s_vel = self.s_vel + K[1] * innov
            self.P = self.P - np.outer(K, self.P[0, :])
            self.last_valid_s = z
        self.cov_trace = 8 * self.P[0, 0]   # sum of the 8 feature-position variances (px^2)

    def _obs(self):
        err = (self.s_pred - self.s_star) / IMG_HALF
        vel = self.s_vel / IMG_HALF
        t_since = np.array([min(self.channel.steps_since_valid, 20) / 20.0])
        z = {'proxy': self.proxy_zeta, 'kfcov': self.kfcov_zeta}.get(self.unc, self.cov_trace)
        cov = np.array([min(z, 400.0) / 400.0])
        if 'tau' in self.obs_mask: t_since = t_since * 0.0
        if 'zeta' in self.obs_mask: cov = cov * 0.0
        return np.concatenate([err, vel, t_since, cov, self.prev_action]).astype(np.float32)

    def step(self, action):
        action = np.clip(action, -1, 1)
        a_cmd = action
        if self.latency:
            self.queue.append(action.copy()); a_cmd = self.queue.pop(0)
        v_phys = a_cmd * self.V_LIM * self.act_scale
        disturb = self.rng.normal(0, self.process_noise_std, size=4)
        # integrate true pose (with small unmodeled platform disturbance)
        self.pose = self.pose + (np.array([v_phys[0], v_phys[1], v_phys[2], v_phys[3]]) + disturb) * DT
        self.pose[2] = np.clip(self.pose[2], 0.2, 1.2)
        # target continues to drift (e.g. conveyor / handheld part) regardless of camera dropout
        self.target_vel = self.target_vel + self.rng.normal(0, self.target_drift_std * 0.3, size=2)
        self.target_vel = np.clip(self.target_vel, -0.05, 0.05)
        if getattr(self, 'target_traj', None) is not None:      # real-motion replay (optional)
            self.target_xy = self.target_traj[min(self.t + 1, len(self.target_traj) - 1)].copy()
        else:
            self.target_xy = self.target_xy + self.target_vel * DT
        self.true_s, self.zc, _, _ = project(self.pose, target_xy=self.target_xy)

        if self.md_dropout:                      # motion-dependent dropout: blur at speed raises the loss probability
            spd = float(np.linalg.norm(a_cmd[:3]))
            self.channel.p_lose = min(0.95, self.p_lose * (1 + self.md_dropout * spd))
        visible = self.channel.step()
        self.nis = float('nan')
        self.proxy_zeta = 5.0 if visible else self.proxy_zeta + 8.0 * (1 + 0.15 * self.channel.steps_since_valid)
        if self.unc == 'kfcov':
            Fm = np.array([[1.0, DT], [0.0, 1.0]]); qq = self.kf_q ** 2
            self.P_sh = Fm @ self.P_sh @ Fm.T + qq * np.array([[DT ** 4 / 4, DT ** 3 / 2], [DT ** 3 / 2, DT ** 2]])
            if visible:
                Kk = self.P_sh[:, 0] / (self.P_sh[0, 0] + max(self.pixel_noise_std, 0.5) ** 2); self.P_sh = self.P_sh - np.outer(Kk, self.P_sh[0, :])
            self.kfcov_zeta = 8 * self.P_sh[0, 0]
        if self.estimator == 'kf':
            self._kf_step(visible)
        elif visible:
            noisy_s = self.true_s + self.rng.normal(0, self.pixel_noise_std, size=8)
            # EKF update (simple alpha-beta / constant-velocity filter)
            innov = noisy_s - self.s_pred
            self.s_vel = 0.7 * self.s_vel + 0.3 * (innov / DT)
            self.s_pred = noisy_s
            self.cov_trace = 5.0  # low uncertainty right after an update
            self.last_valid_s = noisy_s
        else:
            # propagate forward with constant-velocity model, grow uncertainty
            self.s_pred = self.s_pred + self.s_vel * DT
            self.cov_trace = self.cov_trace + 8.0 * (1 + 0.15 * self.channel.steps_since_valid)

        err_true = self.true_s - self.s_star
        rmse_true = np.sqrt(np.mean(err_true ** 2))
        action_pen = 0.01 * np.sum(action ** 2)
        smooth_pen = self.smooth_coef * np.sum((action - self.prev_action) ** 2)
        proximity_bonus = 0.30 * np.exp(-rmse_true / 15.0)
        reward = -0.02 * rmse_true - action_pen - smooth_pen - 0.02 + proximity_bonus

        lost = self._fov_violation(self.true_s) or self.pose[2] <= 0.21 or self.pose[2] >= 1.19
        if lost:
            reward -= 15.0

        if rmse_true < SUCCESS_TOL:
            self._success_streak += 1
            reward += 0.05
        else:
            self._success_streak = 0
        success = self._success_streak >= SUCCESS_HOLD

        self.prev_action = action.copy()
        self.t += 1
        done = lost or success or (self.t >= MAX_STEPS)
        info = dict(rmse_true=rmse_true, visible=visible, lost=lost, success=success,
                    cov_trace=self.cov_trace, pose=self.pose.copy())
        return self._obs(), reward, done, info
