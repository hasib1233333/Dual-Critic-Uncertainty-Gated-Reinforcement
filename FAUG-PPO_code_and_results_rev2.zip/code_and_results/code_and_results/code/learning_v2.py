"""Learning speed (matched 0-3000 window) and training-budget table for v2 runs."""
import json, glob, numpy as np
from scipy import stats
R = '/home/claude/project/code_and_results/code_and_results/results'
def curves(name):
    if name == 'fixed':
        return [[(h['episode'], h['success_rate']) for h in r['history']] for r in json.load(open(f'{R}/train_abl_fixed_alpha_n10.json'))]
    return [[(h['episode'], h['success_rate']) for h in json.load(open(f))['history']] for f in sorted(glob.glob(f'{R}/train_v2_{name}_seed*.json'))]
def metrics(c, hi=3000):
    e, s = np.array([x[0] for x in c]), np.array([x[1] for x in c])
    m = e <= hi; auc = np.mean(s[m])
    first = next((int(ei) for ei, si in zip(e, s) if si >= 0.5), None)
    s2400 = s[np.argmin(abs(e - 2400))]
    return auc, first, s2400
out = {}
for n in ['sc_3k', 'fixed', 'resid', 'dcug_3k', 'faug_sc', 'faug_kf']:
    M = [metrics(c) for c in curves(n)]
    out[n] = dict(auc=[m[0] for m in M], first50=[m[1] for m in M], s2400=[m[2] for m in M])
    if n != 'fixed':
        B = [json.load(open(f)) for f in sorted(glob.glob(f'{R}/train_v2_{n}_seed*.json'))]
        out[n]['env_steps'] = [b['env_steps'] for b in B]; out[n]['grad_updates'] = [b['grad_updates'] for b in B]
for n in ['sac', 'td3_smooth', 'td3']:
    B = [json.load(open(f)) for f in sorted(glob.glob(f'{R}/train_v2_{n}_seed*.json'))]
    if B: out[n] = dict(env_steps=[b['env_steps'] for b in B], grad_updates=[b['grad_updates'] for b in B],
                        first50=[next((h['episode'] for h in b['history'] if h['success_rate'] >= .5), None) for b in B])
for n, d in out.items():
    s = f'{n:10s}'
    if 'auc' in d: s += f" AUC {np.mean(d['auc']):.3f}±{np.std(d['auc'],ddof=1):.3f}  s2400 {np.mean(d['s2400']):.3f}  first50 {d['first50']}"
    if 'env_steps' in d: s += f"  steps {np.mean(d['env_steps']):.0f}  grads {np.mean(d['grad_updates']):.0f}"
    print(s)
tests = {}
for a, b in [('faug_sc', 'fixed'), ('faug_kf', 'fixed'), ('faug_sc', 'resid'), ('faug_sc', 'dcug_3k'), ('faug_kf', 'faug_sc'), ('faug_sc', 'sc_3k')]:
    t = stats.ttest_ind(out[a]['auc'], out[b]['auc'], equal_var=False); tests[f'{a}_vs_{b}'] = dict(diff=float(np.mean(out[a]['auc']) - np.mean(out[b]['auc'])), p=float(t.pvalue))
    print(a, b, tests[f'{a}_vs_{b}'])
json.dump(dict(runs=out, auc_tests=tests), open(f'{R}/v2_learning.json', 'w'), indent=1)
