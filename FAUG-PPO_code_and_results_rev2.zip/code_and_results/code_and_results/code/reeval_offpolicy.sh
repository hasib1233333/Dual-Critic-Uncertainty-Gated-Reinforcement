#!/bin/bash
# Re-evaluate SAC and TD3-smooth with all 10 seeds on every tier (revision 2: equal seed counts for the main competitors).
cd "$(dirname "$0")"
export MUJOCO_GL=osmesa
python3 -u eval_v2.py kin sac td3_smooth
python3 -u eval_v2.py replay sac td3_smooth
python3 -u eval_v2.py mujoco sac td3_smooth 2>&1 | grep -v Warn
python3 -u eval_v3.py heldout sac td3_smooth
python3 -u eval_v3.py arm sac td3_smooth
python3 -u eval_v3.py stress sac td3_smooth
python3 -u eval_v3.py effort sac td3_smooth
echo REEVAL DONE
