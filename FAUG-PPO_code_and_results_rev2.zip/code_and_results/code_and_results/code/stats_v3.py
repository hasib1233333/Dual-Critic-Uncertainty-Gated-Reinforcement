"""Statistics for revision 2: held-out real sequences, arm twin, stress tests, factorial ablation.
Seed-level tests (seed = unit of replication): Welch t between learned controllers, one-sample t against a
deterministic classical controller; Holm correction within each family; episode-paired Wilcoxon (common
random numbers) as a secondary test. Output: results/v3_stats.json"""
import json, os, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results')
J = lambda f: json.load(open(os.path.join(R, f))) if os.path.exists(os.path.join(R, f)) else {}


def seedvec(d, name, keys):
    """per-seed success averaged over the condition keys"""
    runs = [d[name][k] for k in keys]
    return np.array([np.mean([runs[j][i]['success_rate'] for j in range(len(keys))]) for i in range(len(runs[0]))])


def epvec(d, name, keys):
    """per-episode success (averaged over seeds), concatenated over conditions"""
    return np.concatenate([np.mean([r['raw_success'] for r in d[name][k]], 0) for k in keys])


def family(d, ref, comps, keys):
    rows = []; a = seedvec(d, ref, keys); ea = epvec(d, ref, keys)
    for c in comps:
        if c not in d or any(k not in d[c] for k in keys): continue
        b = seedvec(d, c, keys); eb = epvec(d, c, keys)
        t = stats.ttest_1samp(a, b[0]) if len(b) == 1 else stats.ttest_ind(a, b, equal_var=False)
        w = stats.wilcoxon(ea, eb, zero_method='zsplit').pvalue if np.any(ea != eb) else 1.0
        rows.append(dict(vs=c, ref_mean=float(a.mean()), ref_sd=float(a.std(ddof=1)), comp_mean=float(b.mean()),
                         comp_sd=(float(b.std(ddof=1)) if len(b) > 1 else None), diff=float(a.mean() - b.mean()), p=float(t.pvalue), p_episode=float(w)))
    if rows:
        _, ph, _, _ = multipletests([r['p'] for r in rows], method='holm')
        for r, x in zip(rows, ph): r['p_holm'] = float(x)
    return rows


out = {}
H = J('v3_heldout.json')
if H:
    sev = [k for k in next(iter(H.values())) if k.endswith('severe')]
    mod = [k for k in next(iter(H.values())) if k.endswith('moderate')]
    comps = ['classical_kf', 'classical_ab', 'faug_kf', 'faug_kf_rm', 'faug_kf_rm@cov3a03', 'td3_smooth', 'sac', 'td3', 'faug_sc', 'fixed', 'resid', 'dcug_3k', 'sc_3k', 'kf_fixed@cov3a03']
    for ref in ['faug_kf@cov3a03']:
        out[f'heldout_severe_{ref}'] = family(H, ref, [c for c in comps if c != ref], sev)
        out[f'heldout_moderate_{ref}'] = family(H, ref, [c for c in comps if c != ref], mod)
    out['heldout_summary'] = {n: {k: dict(mean=float(np.mean([r['success_rate'] for r in v[k]])), lost=float(np.mean([r['lost_rate'] for r in v[k]])),
                                          sd=(float(np.std([r['success_rate'] for r in v[k]], ddof=1)) if len(v[k]) > 1 else None)) for k in v}
                              for n, v in H.items()}
    print('== held-out severe (FAUG-PPO + cap vs ...)')
    for r in out['heldout_severe_faug_kf@cov3a03']:
        print(f"  {r['vs']:20s} ref {r['ref_mean']*100:5.1f} comp {r['comp_mean']*100:5.1f} diff {r['diff']*100:+5.1f}  p_holm {r['p_holm']:.2e}  p_ep {r['p_episode']:.2e}")
A = J('v3_arm.json')
if A:
    for cond in ['moderate', 'severe', 'severe_lat200']:
        if 'faug_kf@cov3a03' in A:
            out[f'arm_{cond}'] = family(A, 'faug_kf@cov3a03', [c for c in A if c != 'faug_kf@cov3a03'], [cond])
S = J('v3_stress.json')
if S and 'faug_kf@cov3a03' in S:
    for cond in next(iter(S.values())):
        out[f'stress_{cond}'] = family(S, 'faug_kf@cov3a03', [c for c in S if c != 'faug_kf@cov3a03'], [cond])
T = J('v3_tiers.json')
if T and 'faug_kf@cov3a03' in T:
    for cond in T['faug_kf@cov3a03']:
        out[f'tiers_{cond}'] = family(T, 'faug_kf@cov3a03', [c for c in T if c != 'faug_kf@cov3a03'], [cond])
json.dump(out, open(os.path.join(R, 'v3_stats.json'), 'w'), indent=1)
