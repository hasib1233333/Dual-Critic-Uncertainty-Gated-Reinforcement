# FAUG-PPO: Code and Results (Computers & Electrical Engineering submission)

Public mirror: https://github.com/hasib1233333/Dual-Critic-Uncertainty-Gated-Reinforcement.git

Current manuscript: "Fallback-anchored uncertainty-gated reinforcement learning for image-based
visual servoing under intermittent camera dropout" (Computers and Electrical Engineering, Elsevier).
Earlier title: "Dual-Critic Uncertainty-Gated Reinforcement Learning for Vision-Dropout-Robust
Image-Based Visual Servoing" (DCUG-PPO, retained as an ablation).

## Revision 2 (assessment response): authority cap, held-out real sequences, factorial, arm twin

| Step | Script | Output |
|---|---|---|
| Held-out real sequences (KLT + RANSAC homography; ellipse moments) | `../../realdata/track_more.py` | `realdata/heldout_tracks.json` |
| Estimator calibration under shift (incl. adaptive KF) | `../../realdata/realdata_heldout.py` | `realdata/realdata_heldout_results.json` |
| Transfer diagnosis (episode-paired, NIS, prediction-error tails) | `diag_transfer.py` | `results/diag_transfer.json` |
| Authority-cap development sweep (dev data only; 14 candidates + component ablation) | `cap_dev.py` | `results/cap_dev_faug_kf.json`, `results/cap_selection.json` |
| Factorial and real-data-driven training (`kf_*`, `ab_kfcov`, `faug_kf_rm`, `kf_fixed_rm`) | `train_queue.py W N name[:K],...` | `models_v2/`, `results/train_v2_*.json` |
| Evaluations: heldout / tiers / mujoco / arm / stress / effort / real (name@cov3a03 = capped) | `eval_v3.py MODE NAMES...` | `results/v3_*.json` |
| Off-policy 10-seed re-evaluation | `reeval_offpolicy.sh` | `results/v2_*.json`, `results/v3_*.json` |
| Theorem-assumption check (uncapped / capped) | `theorem_check.py [cap]` | `results/theorem_check*.json` |
| Compute microbenchmark | `bench_budget.py` | `results/v3_budget.json` |
| Statistics | `stats_v2.py`, `stats_v3.py` | `results/v2_stats.json`, `results/v3_stats.json`, `results/v3_kin_cap_tests.json` |
| Tables (generated, inlined into the manuscript) | `make_tables_v3.py`, `../../paper_cee/fill_tables.py` | `paper_cee/tab_*.tex` |
| Articulated 6R digital twin | `arm_env.py` | (used by `eval_v3.py arm`) |

The cap: alpha <- min(alpha, 0.3 * 9 / (9 + P_pos)), P_pos = mean Kalman position variance (px^2); selected on
development data (simulator + mire-2) and frozen (`results/cap_selection.json`) before the held-out sequences were evaluated.
Retraining faug_kf seeds 1-3 (`faug_kf_log`) reproduces the original weights exactly (max abs. difference 0).

## v2 pipeline (all numbers in the C&EE manuscript)

| Step | Script | Output |
|---|---|---|
| Kalman calibration (q = 72 px/s^2, NEES 0.96 held-out) | `calibrate_kf.py` | `results/kf_calibration.json` |
| Matched-budget PPO retraining (10 seeds x 3000 ep): `faug_kf`, `faug_sc`, `sc_3k`, `dcug_3k`, `resid` | `train_queue.py` | `models_v2/`, `results/train_v2_*.json` |
| Off-policy baselines (3 seeds x 1200 ep): `sac`, `td3`, `td3_smooth` | `train_offpolicy.py NAME SEED` | `models_v2/`, `results/train_v2_*.json` |
| Evaluation with common random numbers (kin / mujoco / real / replay / effort / gate) | `eval_v2.py MODE NAMES...` | `results/v2_*.json` |
| Statistics (Welch + Holm over 30, Hedges g, episode-paired Wilcoxon) | `stats_v2.py` | `results/v2_stats.json` |
| Learning speed and budgets | `learning_v2.py` | `results/v2_learning.json` |
| Figures | `figs_cee.py`, `../../realdata/fig_realdata.py` | `paper_cee/cee_*.pdf` |
| Real data (ViSP mire-2: detection, noise, estimator benchmark) | `../../realdata/detect_mire.py`, `realdata_analysis.py` | `realdata/*.json` |
| Real-motion closed-loop replay | `replay_env.py` (used by `eval_v2.py replay`) | `results/v2_replay.json` |

Rendering note: MuJoCo must be imported after `torch._dynamo`, use `MUJOCO_GL=osmesa`, and only
one renderer may exist per process at a time (close it before creating the next).

---
Historical notes (earlier rounds) follow.

# FAUG-PPO (formerly DCUG-PPO) / DCUG-TD3: Code and Results

Public mirror: https://github.com/hasib1233333/Dual-Critic-Uncertainty-Gated-Reinforcement.git

Covers the main paper ("Dual-Critic Uncertainty-Gated Reinforcement Learning for
Vision-Dropout-Robust Image-Based Visual Servoing", submitted to Discover Robotics)
and its extension paper ("Does Fallback-Anchored Uncertainty Gating Help Off-Policy
Reinforcement Learning?").

## Fixes made during the major-revision round (this archive reflects the corrected state)

Two independent reviewers verified the manuscript's numbers against an earlier version
of this code and found several real bugs, all fixed here:

- **`gather_extra.py`**: the distance-sensitivity sweep scored the two classical
  controllers on a final-step-only RMSE check while the learned controllers used the
  true 8-consecutive-step success criterion. Fixed to use the same criterion for all
  four controllers (`record_classical` now returns the environment's real `success`
  flag). See `fix_distance_sensitivity.py` for the corrected re-run.
- **`mujoco_realimage_env.py`**: added a `strict_detection_termination` flag. The
  original behavior (any single missed detection ends the episode as an unrecoverable
  loss) is preserved as the default; setting it `False` treats a failed detection as a
  recoverable dropout event instead. See `tier3_termination_check.py` for a comparison
  of both definitions.
- **`figs.py`**: (a) three hardcoded "5 seeds" labels left over from before the
  PPO-family seed count was doubled to ten, now say "10 seeds"; (b) the `LABEL` dict and
  three other hardcoded strings called the fallback estimator "EKF" — it is not a
  Kalman filter (see `env.py`: raw pass-through position estimate, fixed 0.7/0.3
  exponential velocity smoothing, hand-coded covariance ramp) — now say
  "$\alpha\beta$ fallback" throughout; (c) all TD3 comparisons now explicitly slice to
  the first 3 seeds of `eval_td3.json` (see note below on why that file has more than 3).
- **`fix_realism_tiers_fig.py`**: the original three-fidelity-tier bar chart's
  generating script was lost from an earlier archive; this rebuilds it from
  `eval_results.json` + `mujoco_transfer.json` + `realimage_transfer.json`, reproducing
  the exact numbers already reported in the paper (68.0/66.0/63.3 for the classical
  baseline; 91.4/88.9/72.0 for DCUG-PPO; 83.1/82.5/58.0 for single-critic PPO).

None of these fixes required retraining except one: `record_classical`'s consistent
success criterion needed re-evaluating the distance-sensitivity sweep on trained
policies, so `dcug_full` seed 1 and `single_critic` seed 2 were retrained (included in
`models/`) specifically to regenerate that one figure. The corrected numbers changed by
at most 2.5 percentage points, confined to the classical baseline's bars.

**Note on `eval_td3.json`**: this file contains 10 seeds' worth of TD3 evaluations, not
3. The main paper's TD3 comparisons (Table 5, the abstract, `sec:td3`) were run and
verified against only the *first 3* seeds in this file, matching the paper's stated
"TD3: 3 seeds" — the extra 7 seeds were added later for the extension paper's
matched-power comparison against DCUG-TD3. Every script in this archive that touches
`eval_td3.json` for a main-paper figure now explicitly slices to `[:3]`.

## IEEE revision: FAUG-PPO as the proposed method

The revised manuscript ("Fallback-Anchored Uncertainty-Gated Reinforcement Learning for
Image-Based Visual Servoing Under Intermittent Camera Dropout"; previously titled
"Dual-Critic Uncertainty-Gated Reinforcement Learning for Vision-Dropout-Robust
Image-Based Visual Servoing") proposes **FAUG-PPO**: the learned gate without the
critic-disagreement input. Its checkpoints are `models_expanded/abl_no_vdiff_n10_seed{1..10}.pt`.
DCUG-PPO is retained as an ablation. The selection was made on the moderate kinematic
preset; everything below was evaluated afterwards.

New scripts (all numbers in the manuscript come from these):
- `code/eval_faug.py kin|mujoco|real` -> `results/faug_eval_kinematic.json`, `faug_eval_mujoco.json`, `faug_eval_realimage.json`
- `code/gather_faug.py` -> `results/extra_faug.json` (qualitative episode, effort/jerk incl. 10-seed FAUG, heatmap, pose sweep, noise, disturbance, timing)
- `code/gate_analysis_faug.py` -> `results/faug_gate_analysis.json` (gate vs dropout age, all 10 seeds; pre-clip bound exceedance)
- `code/stats_faug.py` -> `results/faug_stats.json` (Welch t, Holm, Hedges g, bootstrap CIs, Wilson, Fisher)
- `code/figs_ieee.py` -> all IEEE-style data figures (`ieee_*.pdf`)

Reproduction checks performed before trusting new numbers:
- Kinematic moderate FAUG results reproduce `eval_abl_no_vdiff_n10.json` exactly.
- MuJoCo classical baselines reproduce the archived 0.14 / 0.66 (moderate) exactly.
- Rendered tier: reproduces the archived classical 0.633 and DCUG seed-1 lenient 0.933 exactly.

**Rendering bug found in this revision.** Under the software (osmesa) OpenGL backend, creating
a second `mujoco.Renderer` in one process produces corrupted frames (no markers detected).
`eval_faug.py real` now closes each renderer before creating the next. The first, invalid
run is kept as `results/INVALID_faug_eval_realimage_renderer_bug.json` for transparency.
The archived multi-seed DCUG/single-critic rendered-tier numbers came from a script that
created several renderers per process (under EGL), and the archive already contained two
different values for the same DCUG seed-1 strict setting (0.600 vs 0.833); they are therefore
reported separately and treated as provisional.

**Correction of an earlier training-speed comparison.** A previous version compared learning
curves averaged over unequal episode windows (FAUG to 3000 episodes, seven DCUG seeds to 2400).
Over the matched 0-2400 window, DCUG-PPO learns modestly faster (AUC 0.537 vs 0.487, p = 0.026)
while reaching equal training success by episode 2400 (p = 0.61) and lower final deterministic
success (91.4 vs 96.0 %, p = 0.005).

**Implementation note.** The FAUG checkpoints were trained with the ablation code, in which the
pessimistic critic is still trained but never read by the actor; because one global gradient-norm
clip covers all parameters, it can rescale actor updates. A strictly single-critic FAUG has not
been trained.

## Contents

### Core environment and PPO/DCUG-PPO (main paper)
- `code/env.py` — IBVS-under-dropout kinematic simulation environment
- `code/controllers.py` — classical IBVS, $\alpha\beta$-filter-fallback, and DCUG-PPO fallback-action controllers
- `code/ppo.py` — PPO implementation with optional dual-critic / uncertainty-gated (DCUG) actor
- `code/train.py`, `code/train_one.py` — PPO training loops
- `code/run_experiments.py` — full evaluation sweeps
- `code/gather_extra.py` — qualitative trajectories, dropout-parameter heatmap, distance sensitivity (fixed scoring, see above), timing
- `code/gather_extra2.py` — noise-robustness sweep, computational-scaling benchmark, disturbance-rejection test, failure-case mining
- `code/figs.py` — regenerates all 22 main-paper figures (fixed labels, see above)
- `code/fix_distance_sensitivity.py` — standalone re-run of the corrected distance-sensitivity sweep
- `code/fix_realism_tiers_fig.py` — standalone rebuild of the three-fidelity-tier figure
- `code/tier3_termination_check.py` — strict vs. lenient detection-termination comparison

### Cross-simulator validation
- `code/mujoco_env.py` — MuJoCo rigid-body environment
- `code/mujoco_eval.py`, `code/mujoco_eval_extend.py` — zero-shot MuJoCo evaluation
- `code/mujoco_realimage_env.py` — MuJoCo + real offscreen rendering + OpenCV feature detection (fixed termination logic, see above)
- `code/realimage_eval.py` — zero-shot evaluation in the rendered-image environment

### TD3 baseline and DCUG-TD3 (extension paper)
- `code/td3.py`, `code/train_td3.py`, `code/train_td3_one.py`, `code/eval_td3.py`
- `code/dcug_td3.py`, `code/train_dcug_td3.py`, `code/train_dcug_td3_one.py`, `code/train_dcug_td3_variant.py`, `code/eval_dcug_td3.py`
- `code/generate_stats_figures.py` — extension-paper forest plot and ablation chart
- `code/ieee_style.py` — shared matplotlib styling

## Results
All raw per-seed training histories, per-episode evaluation arrays, and derived
statistics underlying every figure and table in both papers. See filenames for
correspondence (`eval_*.json` = deterministic evaluation, `train_*.json` = training
history, `extra_data*.json` = secondary/robustness analyses).

## Models
`models/` contains two retrained checkpoints (`dcug_full_seed1.pt`,
`single_critic_seed2.pt`) used to regenerate the distance-sensitivity figure with
corrected scoring. Full model weights for all ten main seeds are not included in this
archive; retrain via `train_one.py` with the corresponding seed argument if needed.

## Budget-matched ablation re-run (resolves the earlier 2-seed underpowered ablation)

`code/expand_ablation.py` retrains both ablation variants (`abl_fixed_alpha`,
`abl_no_vdiff`) for all 10 seeds at the full 3000-episode budget, matching
`dcug_full`/`single_critic` exactly. This was run specifically to resolve the open
question flagged in the original ablation (Section 6.14): whether the 2-seed result
was a real null finding or just underpowered.

Result, now at full power: **both ablated variants significantly outperform full
DCUG-PPO** at deterministic convergence (fixed-α: 95.6±1.8%, gate-without-ΔV:
96.0±2.3%, vs. DCUG-PPO's 91.4±3.8%; seed-level Welch's t-test p=0.0072 and
p=0.0047 respectively), with tighter variance too. Training-time (stochastic-rollout)
dynamics tell a different story: DCUG-PPO trains significantly faster/more stably than
the fixed-blend variant (p<0.004) but is statistically indistinguishable from the
gate-without-ΔV variant (p=0.36–0.91), which itself trains far better than the fixed
blend (p<1e-5). Net reading: a learned, state-dependent gate helps training-time
sample efficiency regardless of what it's conditioned on; the critic-disagreement
(ΔV) signal specifically — DCUG-PPO's distinguishing mechanism — adds no measurable
benefit and a small, real cost at convergence. See the manuscript's Section 6.14 and
Discussion for the full writeup.

- `results/train_abl_fixed_alpha_n10.json`, `results/train_abl_no_vdiff_n10.json` —
  full 10-seed training histories at 3000 episodes.
- `results/eval_abl_fixed_alpha_n10.json`, `results/eval_abl_no_vdiff_n10.json` —
  per-seed deterministic evaluation (300 episodes/seed, moderate preset).
- `results/ablation_expanded_n10.json` — both combined.
- `results/eval_results.json`'s `ablation_moderate` key now holds this 10-seed data;
  the original 2-seed result is preserved under `ablation_moderate_original_n2` for
  audit.
- `models_expanded/` — the 20 new checkpoints (10 seeds × 2 variants).

## Known scope limits
See both papers' Discussion, Limitations, and the point-by-point response to reviewers
for a full account of open questions: no physical-robot validation, no SAC/PPO-LSTM/
Dreamer/distributional-RL baselines, and — now resolved rather than merely
underpowered — the gate's critic-disagreement conditioning does not improve, and
modestly hurts, final deterministic performance relative to a simpler fixed or
learned-but-unconditioned gate (see above).
