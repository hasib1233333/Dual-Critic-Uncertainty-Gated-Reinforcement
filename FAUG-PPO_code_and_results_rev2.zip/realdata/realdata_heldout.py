"""Estimator benchmark and uncertainty calibration UNDER DISTRIBUTION SHIFT on held-out real sequences.
The Kalman filter keeps the noise parameters calibrated on mire-2 (q*, R); nothing is re-tuned.
For each held-out sequence (mbt-cube, cube, ellipse-1) and dropout preset: prediction RMSE of zero-order
hold, the alpha-beta predictor and the KF over dropout frames, KF 95% coverage, NEES and the Spearman
correlation between predicted s.d. and error. Output: realdata_heldout_results.json"""
import json, numpy as np
from scipy import stats
from scipy.signal import savgol_filter

MIRE = json.load(open('realdata_results.json'))
Q_STAR = MIRE['kf_q_calibrated']; R = max(MIRE['sigma_meas_px'], 0.3) ** 2
HO = json.load(open('heldout_tracks.json'))


def run_akf(Z, vis, q, R, lam=0.8):
    """Innovation-adaptive KF: process-noise intensity scaled by an EWMA of the normalized innovation
    squared, q_t^2 = q^2 * max(1, NIS_ewma); identical to the KF when innovations are consistent."""
    T = len(Z); kf = np.zeros_like(Z); kvar = np.zeros(T)
    x = Z[0].copy(); v = np.zeros(8); P = np.array([[R, 0.0], [0.0, 25.0]]); Fm = np.array([[1.0, 1.0], [0.0, 1.0]]); r = 1.0
    for t in range(T):
        if t > 0:
            Q = q ** 2 * max(1.0, r) * np.array([[0.25, 0.5], [0.5, 1.0]])
            x = x + v; P = Fm @ P @ Fm.T + Q
            if vis[t]:
                Sg = P[0, 0] + R; inn = Z[t] - x; r = lam * r + (1 - lam) * float(np.mean(inn ** 2 / Sg))
                K = P[:, 0] / Sg; x = x + K[0] * inn; v = v + K[1] * inn; P = P - np.outer(K, P[0, :])
        kf[t] = x; kvar[t] = P[0, 0]
    return kf, kvar


def run_estimators(Z, vis, q, R):
    T = len(Z); zoh = np.zeros_like(Z); ab = np.zeros_like(Z); kf = np.zeros_like(Z); kvar = np.zeros(T)
    last = Z[0].copy(); s_ab = Z[0].copy(); v_ab = np.zeros(8)
    x = Z[0].copy(); v = np.zeros(8); P = np.array([[R, 0.0], [0.0, 25.0]])
    Fm = np.array([[1.0, 1.0], [0.0, 1.0]]); Q = q ** 2 * np.array([[0.25, 0.5], [0.5, 1.0]])
    for t in range(T):
        if t > 0:
            if vis[t]:
                v_ab = 0.7 * v_ab + 0.3 * (Z[t] - s_ab); s_ab = Z[t].copy()
            else:
                s_ab = s_ab + v_ab
            x = x + v; P = Fm @ P @ Fm.T + Q
            if vis[t]:
                K = P[:, 0] / (P[0, 0] + R); inn = Z[t] - x; x = x + K[0] * inn; v = v + K[1] * inn; P = P - np.outer(K, P[0, :])
                last = Z[t].copy()
        zoh[t] = last; ab[t] = s_ab; kf[t] = x; kvar[t] = P[0, 0]
    return zoh, ab, kf, kvar


def markov_mask(T, pl, pr, rng):
    vis = np.ones(T, bool)
    for t in range(1, T):
        vis[t] = (rng.random() >= pl) if vis[t - 1] else (rng.random() < pr)
    return vis


presets = {'mild': (0.04, 0.25), 'moderate': (0.08, 0.18), 'severe': (0.14, 0.12)}
out = {}
for name, v in HO.items():
    S = np.array(v['tracks']); T = len(S)
    sm = savgol_filter(S, 9, 2, axis=0) if T > 20 else S
    res = (S - sm)[5:-5]; mad = np.median(np.abs(res - np.median(res, 0)), 0) * 1.4826
    out[name] = dict(n_frames=T, width=v['width'], noise_est_px=float(np.median(mad)), presets={})
    for pre, (pl, pr) in presets.items():
        rng = np.random.default_rng(321); err = {k: [] for k in ['zoh', 'ab', 'kf']}; cov, nees, sd_all, e_all, acov, anees = [], [], [], [], [], []
        for rep in range(400):
            vis = markov_mask(T, pl, pr, rng)
            if (~vis).sum() == 0: continue
            zoh, ab, kf, kvar = run_estimators(S, vis, Q_STAR, R); m = ~vis
            for k, P_ in [('zoh', zoh), ('ab', ab), ('kf', kf)]:
                err[k] += np.sqrt(((S - P_) ** 2).mean(1))[m].tolist()
            e = S - kf; sd = np.sqrt(kvar + R)
            cov += (np.abs(e[m]) < 1.96 * sd[m, None]).mean(1).tolist(); nees += ((e[m] ** 2).mean(1) / (kvar[m] + R)).tolist()
            sd_all += sd[m].tolist(); e_all += np.sqrt((e[m] ** 2).mean(1)).tolist()
            ka, kva = run_akf(S, vis, Q_STAR, R); ea = S - ka; sda = np.sqrt(kva + R)
            err.setdefault('akf', []).extend(np.sqrt((ea ** 2).mean(1))[m].tolist())
            acov.extend((np.abs(ea[m]) < 1.96 * sda[m, None]).mean(1).tolist()); anees.extend(((ea[m] ** 2).mean(1) / (kva[m] + R)).tolist())
        r = {k: dict(rmse_mean=float(np.mean(x)), rmse_p95=float(np.percentile(x, 95))) for k, x in err.items()}
        r.update(kf_coverage95=float(np.mean(cov)), kf_nees=float(np.mean(nees)), spearman_kf=float(stats.spearmanr(sd_all, e_all).correlation),
                 akf_coverage95=float(np.mean(acov)), akf_nees=float(np.mean(anees)))
        out[name]['presets'][pre] = r
        print(f"{name:10s} {pre:9s} RMSE zoh {r['zoh']['rmse_mean']:6.2f} ab {r['ab']['rmse_mean']:6.2f} kf {r['kf']['rmse_mean']:6.2f} | "
              f"KF cov95 {r['kf_coverage95']:.3f} NEES {r['kf_nees']:.2f} rho {r['spearman_kf']:.2f} | AKF {r['akf']['rmse_mean']:6.2f} cov95 {r['akf_coverage95']:.3f} NEES {r['akf_nees']:.2f}")
json.dump(out, open('realdata_heldout_results.json', 'w'), indent=1)
