"""Track additional REAL ViSP sequences (held out from all training and tuning).
For each sequence we recover the image-plane trajectory of a planar target region:
pyramidal Lucas-Kanade (KLT) point tracking with a forward-backward consistency check,
RANSAC homography to the first frame (re-seeded when too few points survive), and the
four corners of the initial region mapped through the homography as 'features'.
ellipse-1 uses thresholded-region moments (centroid and principal-axis endpoints).
Output: realdata/heldout_tracks.json  {name: {width, height, n, tracks (n,8), inlier_frac}}"""
import json, os, numpy as np, cv2
BASE = '/usr/share/visp-images-data/ViSP-images'
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'heldout_tracks.json')
LK = dict(winSize=(21, 21), maxLevel=3, criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))


def klt_region(frames, roi):
    x0, y0, x1, y1 = roi
    corners0 = np.float32([[x0, y0], [x1, y0], [x1, y1], [x0, y1]]).reshape(-1, 1, 2)
    mask = np.zeros_like(frames[0]); mask[y0:y1, x0:x1] = 255
    ref_pts = cv2.goodFeaturesToTrack(frames[0], 300, 0.01, 4, mask=mask)
    H_acc = np.eye(3); prev = frames[0]; pts = ref_pts.copy(); H_seg = np.eye(3)
    tracks, inl = [corners0.reshape(-1)], []
    for f in frames[1:]:
        nxt, st, _ = cv2.calcOpticalFlowPyrLK(prev, f, pts, None, **LK)
        back, st2, _ = cv2.calcOpticalFlowPyrLK(f, prev, nxt, None, **LK)
        fb = np.linalg.norm((back - pts).reshape(-1, 2), axis=1)
        good = (st.ravel() == 1) & (st2.ravel() == 1) & (fb < 1.0)
        H, m = cv2.findHomography(pts[good], nxt[good], cv2.RANSAC, 2.0)
        inl.append(float(m.sum() / max(len(m), 1)))
        H_acc = H @ H_acc
        c = cv2.perspectiveTransform(corners0, H_acc)
        tracks.append(c.reshape(-1))
        pts = nxt[good][m.ravel() == 1].reshape(-1, 1, 2)
        if len(pts) < 60:                                    # re-seed inside the current region
            mk = np.zeros_like(f); cv2.fillConvexPoly(mk, c.reshape(-1, 2).astype(np.int32), 255)
            new = cv2.goodFeaturesToTrack(f, 300, 0.01, 4, mask=mk)
            if new is not None: pts = new
        prev = f
    return np.array(tracks), float(np.mean(inl))


def ellipse_tracks(frames):
    T = []; Vprev = None
    for f in frames:
        _, b = cv2.threshold(f, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        n, lab, stats, cen = cv2.connectedComponentsWithStats(b)
        k = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA]); ys, xs = np.nonzero(lab == k)
        c = np.array([xs.mean(), ys.mean()]); C = np.cov(np.vstack([xs, ys]))
        w, V = np.linalg.eigh(C); a = 2 * np.sqrt(w)              # semi-axes (2 sigma)
        if Vprev is not None:                                     # temporal consistency of axis signs
            for j in range(2):
                if V[:, j] @ Vprev[:, j] < 0: V[:, j] = -V[:, j]
        Vprev = V.copy()
        p = [c + a[1] * V[:, 1], c + a[0] * V[:, 0], c - a[1] * V[:, 1], c - a[0] * V[:, 0]]
        T.append(np.concatenate(p))
    return np.array(T)


def load(d, pat, n0, n1):
    return [cv2.imread(os.path.join(BASE, d, pat % i), 0) for i in range(n0, n1)]


out = {}
fr = load('mbt/cube', 'image%04d.png', 0, 218)
tr, il = klt_region(fr, (320, 200, 450, 350)); out['mbt-cube'] = dict(width=640, height=480, tracks=tr.tolist(), inlier_frac=il)
fr = load('cube', 'image.%04d.png', 0, 80)
tr, il = klt_region(fr, (180, 78, 252, 138)); out['cube'] = dict(width=384, height=288, tracks=tr.tolist(), inlier_frac=il)
fr = load('ellipse-1', 'image.%04d.png', 1, 51)
out['ellipse-1'] = dict(width=365, height=256, tracks=ellipse_tracks(fr).tolist(), inlier_frac=None)
for k, v in out.items():
    T = np.array(v['tracks']).reshape(-1, 4, 2); c = T.mean(1); sp = np.linalg.norm(np.diff(c, axis=0), axis=1)
    v['n'] = len(T)
    print(f"{k:10s} frames {len(T):3d}  inlier {v['inlier_frac']}  centroid speed px/frame median {np.median(sp):.2f} p95 {np.percentile(sp,95):.2f} max {sp.max():.2f}")
json.dump(out, open(OUT, 'w'))
