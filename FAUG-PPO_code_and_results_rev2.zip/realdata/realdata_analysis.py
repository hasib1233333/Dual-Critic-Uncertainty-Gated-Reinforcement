"""
Real-data perception and estimator analysis on the ViSP 'mire-2' sequence
(501 real camera frames of a hand-moved planar four-dot target, 384x288).

1. Detection-noise estimate: residual of each tracked coordinate about a local
   quadratic (Savitzky-Golay, window 9) fit; robust std via MAD.
2. Real target-motion statistics (px/frame, px/frame^2).
3. Estimator benchmark under injected Markov dropout on the REAL trajectories:
   zero-order hold (ZOH), the paper's alpha-beta filter, and a constant-velocity
   Kalman filter (KF) whose acceleration noise is calibrated on frames 0-249
   (NEES ~ 1) and evaluated on frames 250-500. Reference = tracked real features.
   Time unit: one frame (the sequence's frame rate is not documented).
Output: realdata_results.json
"""
import json, numpy as np
from scipy.signal import savgol_filter
from scipy import stats

D = json.load(open('mire2_tracks.json'))
S = np.array(D['tracks'])                      # (501, 8) real tracked features (px)
N = len(S)

# ---------------------------------------------------------------- 1. detection noise
smooth = savgol_filter(S, 9, 2, axis=0)
res = (S - smooth)[5:-5]
mad = np.median(np.abs(res - np.median(res, 0)), 0) * 1.4826
sigma_meas = float(np.median(mad))
# correction: residual about a 9-point quadratic fit underestimates sigma by sqrt(1 - h_ii);
h0 = savgol_filter(np.eye(9)[4], 9, 2)[4]      # leverage of the centre point
sigma_meas_corr = sigma_meas / np.sqrt(1 - h0)

# ---------------------------------------------------------------- 2. motion statistics
V = np.diff(smooth, axis=0); A = np.diff(smooth, n=2, axis=0)
speed = np.linalg.norm(V.reshape(-1, 4, 2), axis=2).mean(1)
acc_std = float(A.std())

# ---------------------------------------------------------------- 3. estimators
def run_estimators(Z, vis, q, R):
    """Z: (T,8) measurements; vis: (T,) bool. Returns predictions for zoh, ab, kf and kf variance, tau, zeta."""
    T = len(Z)
    zoh = np.zeros_like(Z); ab = np.zeros_like(Z); kf = np.zeros_like(Z)
    kvar = np.zeros(T); tau = np.zeros(T, int); zeta = np.zeros(T)
    # init on first frame (always visible)
    last = Z[0].copy(); s_ab = Z[0].copy(); v_ab = np.zeros(8)
    x = Z[0].copy(); v = np.zeros(8); P = np.array([[R, 0.0], [0.0, 25.0]])
    Fm = np.array([[1.0, 1.0], [0.0, 1.0]]); Q = q ** 2 * np.array([[0.25, 0.5], [0.5, 1.0]])
    t_since, z_ab = 0, 5.0
    for t in range(T):
        if t > 0:
            # alpha-beta (paper's estimator, dt = 1 frame)
            if vis[t]:
                innov = Z[t] - (s_ab + v_ab); v_ab = 0.7 * v_ab + 0.3 * (Z[t] - s_ab); s_ab = Z[t].copy()
                t_since = 0; z_ab = 5.0
            else:
                s_ab = s_ab + v_ab; t_since += 1; z_ab = z_ab + 8.0 * (1 + 0.15 * t_since)
            # KF
            x = x + v; P = Fm @ P @ Fm.T + Q
            if vis[t]:
                Sinn = P[0, 0] + R; K = P[:, 0] / Sinn; inn = Z[t] - x
                x = x + K[0] * inn; v = v + K[1] * inn; P = P - np.outer(K, P[0, :])
            if vis[t]:
                last = Z[t].copy()
        zoh[t] = last; ab[t] = s_ab; kf[t] = x; kvar[t] = P[0, 0]; tau[t] = t_since; zeta[t] = z_ab
    return zoh, ab, kf, kvar, tau, zeta


def markov_mask(T, pl, pr, rng):
    vis = np.ones(T, bool)
    for t in range(1, T):
        vis[t] = (rng.random() >= pl) if vis[t - 1] else (rng.random() < pr)
    vis[0] = True
    return vis


R = max(sigma_meas_corr, 0.3) ** 2
cal, test = S[:250], S[250:]

def nees_for(q, data, reps=60, pl=0.08, pr=0.18, seed=0):
    rng = np.random.default_rng(seed); vals = []
    for _ in range(reps):
        vis = markov_mask(len(data), pl, pr, rng)
        _, _, kf, kvar, _, _ = run_estimators(data, vis, q, R)
        e2 = ((data - kf) ** 2).mean(1) / (kvar + R)   # vs noisy reference: add measurement variance
        vals.append(e2[~vis].mean() if (~vis).any() else np.nan)
    return float(np.nanmean(vals))

qs = np.geomspace(0.05, 5, 25)
nees_cal = [nees_for(q, cal) for q in qs]
q_star = float(qs[np.argmin(np.abs(np.log(nees_cal)))])

presets = {'mild': (0.04, 0.25), 'moderate': (0.08, 0.18), 'severe': (0.14, 0.12)}
out = dict(n_frames=N, sigma_meas_px=sigma_meas_corr, sigma_meas_raw_mad_px=sigma_meas,
           speed_px_per_frame=dict(median=float(np.median(speed)), p95=float(np.percentile(speed, 95)), max=float(speed.max())),
           acc_std_px_per_frame2=acc_std, kf_q_calibrated=q_star,
           kf_calibration_curve=dict(q=qs.tolist(), nees=nees_cal), presets={})
for name, (pl, pr) in presets.items():
    rng = np.random.default_rng(123)
    err = {k: [] for k in ['zoh', 'ab', 'kf']}; age_err = {k: {} for k in err}
    cover, nees_all, unc_ab, unc_kf, abs_err, kf_err = [], [], [], [], [], []
    for rep in range(300):
        vis = markov_mask(len(test), pl, pr, rng)
        if (~vis).sum() == 0:
            continue
        zoh, ab, kf, kvar, tau, zeta = run_estimators(test, vis, q_star, R)
        m = ~vis
        for k, P_ in [('zoh', zoh), ('ab', ab), ('kf', kf)]:
            e = np.sqrt(((test - P_) ** 2).mean(1))
            err[k] += e[m].tolist()
            for a, ee in zip(tau[m], e[m]):
                b = int(min(a, 11)); age_err[k].setdefault(b, []).append(ee)
        e_kf = (test - kf); sd = np.sqrt(kvar + R)
        cover += (np.abs(e_kf[m]) < 1.96 * sd[m, None]).mean(1).tolist()
        nees_all += ((e_kf[m] ** 2).mean(1) / (kvar[m] + R)).tolist()
        unc_ab += zeta[m].tolist(); unc_kf += sd[m].tolist()
        abs_err += np.sqrt(((test - ab) ** 2).mean(1))[m].tolist()
        kf_err += np.sqrt(((test - kf) ** 2).mean(1))[m].tolist()
    r = {k: dict(rmse_mean=float(np.mean(v)), rmse_median=float(np.median(v)), rmse_p95=float(np.percentile(v, 95)), n=len(v))
         for k, v in err.items()}
    r['by_age'] = {k: {str(b): float(np.mean(v)) for b, v in sorted(d_.items())} for k, d_ in age_err.items()}
    r['kf_coverage95'] = float(np.mean(cover)); r['kf_nees'] = float(np.mean(nees_all))
    # informativeness: rank correlation between each estimator's uncertainty signal and its own error
    e_kf_rmse = []  # recompute for KF
    r['spearman_ab_zeta_vs_ab_error'] = float(stats.spearmanr(unc_ab, abs_err).correlation)
    r['spearman_kf_sd_vs_kf_error'] = float(stats.spearmanr(unc_kf, kf_err).correlation)
    # error-weighted calibration: mean KF error within quintiles of predicted sd
    qe = np.quantile(unc_kf, [0, .2, .4, .6, .8, 1.0]); U = np.array(unc_kf); E = np.array(kf_err)
    r['kf_reliability'] = [dict(sd_lo=float(qe[i]), sd_hi=float(qe[i+1]), mean_pred_sd=float(U[(U>=qe[i])&(U<=qe[i+1])].mean()),
                                rmse=float(np.sqrt((E[(U>=qe[i])&(U<=qe[i+1])]**2).mean()))) for i in range(5)]
    print('   spearman ab-zeta', round(r['spearman_ab_zeta_vs_ab_error'],3), 'kf-sd', round(r['spearman_kf_sd_vs_kf_error'],3))
    out['presets'][name] = r
    print(name, {k: round(r[k]['rmse_mean'], 2) for k in ['zoh', 'ab', 'kf']}, 'KF coverage', round(r['kf_coverage95'], 3), 'NEES', round(r['kf_nees'], 2))
print('sigma_meas', round(sigma_meas_corr, 3), 'px; q*', round(q_star, 3), 'px/frame^2; speed median', round(float(np.median(speed)), 2))
json.dump(out, open('realdata_results.json', 'w'), indent=1)
