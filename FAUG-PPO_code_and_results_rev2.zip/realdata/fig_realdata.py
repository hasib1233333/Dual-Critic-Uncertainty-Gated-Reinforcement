"""Figure: real-data perception and estimator validation (ViSP mire-2)."""
import json, os, numpy as np, cv2
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT = os.environ.get('FIGOUT', '/home/claude/project/paper_cee')
os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Liberation Serif', 'Times New Roman'], 'mathtext.fontset': 'stix',
                     'font.size': 8, 'axes.labelsize': 8, 'axes.titlesize': 8, 'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5,
                     'legend.fontsize': 7, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.grid': True,
                     'grid.color': '#D0D0D0', 'grid.linewidth': 0.4, 'grid.linestyle': ':', 'legend.frameon': False,
                     'savefig.bbox': 'tight', 'savefig.pad_inches': 0.02, 'figure.dpi': 200, 'axes.linewidth': 0.6})
BLUE = '#2B5C8A'
D = json.load(open('/home/claude/project/realdata/mire2_tracks.json')); T = np.array(D['tracks']).reshape(-1, 4, 2)
Rr = json.load(open('/home/claude/project/realdata/realdata_results.json'))
img = cv2.imread('/usr/share/visp-images-data/ViSP-images/mire-2/image.0251.png', 0)

fig = plt.figure(figsize=(7.16, 2.15))
gs = fig.add_gridspec(1, 3, width_ratios=[1.25, 1, 1], wspace=0.32)
ax = fig.add_subplot(gs[0]); ax.imshow(img, cmap='gray', vmin=0, vmax=255); ax.grid(False)
mk = ['o', 's', 'D', '^']
for k in range(4):
    ax.plot(T[:, k, 0], T[:, k, 1], color='white', lw=0.5, alpha=0.9)
    ax.plot(T[:, k, 0], T[:, k, 1], color='black', lw=0.25, alpha=0.9, ls=':')
    ax.plot(T[250, k, 0], T[250, k, 1], marker=mk[k], ms=4.5, mfc=BLUE, mec='white', mew=0.6, ls='')
ax.set_xticks([]); ax.set_yticks([])
ax.set_title('(a) real sequence, frame 251 of 501')
ax = fig.add_subplot(gs[1])
sty = {'zoh': ('Zero-order hold', '#9A9A9A', (0, (1, 1.5)), 's'), 'ab': (r'$\alpha\beta$ filter', '#5E5E5E', (0, (4, 1.5)), 'D'),
       'kf': ('Calibrated KF', BLUE, '-', 'o')}
for pre, alpha_ in [('severe', 1.0), ('moderate', 0.45)]:
    for k, (lab, c, ls, m) in sty.items():
        d = Rr['presets'][pre]['by_age'][k]; x = np.array(sorted(int(a) for a in d)); y = [d[str(a)] for a in x]
        ax.plot(x, y, color=c, ls=ls, marker=m, ms=2.2, lw=1.2 if k == 'kf' else 0.9, alpha=alpha_,
                label=f'{lab}' if pre == 'severe' else None)
ax.set_xlabel(r'Dropout age $\tau$ (frames; 11 = $\geq$11)'); ax.set_ylabel('Prediction RMSE on real motion (px)')
ax.set_title('(b) prediction error vs. dropout age'); ax.legend(loc='upper left')
ax = fig.add_subplot(gs[2])
for pre, m in [('mild', 's'), ('moderate', 'D'), ('severe', 'o')]:
    rel = Rr['presets'][pre]['kf_reliability']
    ax.plot([r['mean_pred_sd'] for r in rel], [r['rmse'] for r in rel], marker=m, ms=3, lw=0.9, color=BLUE,
            alpha={'mild': 0.4, 'moderate': 0.7, 'severe': 1.0}[pre], label=pre)
mx = max(r['mean_pred_sd'] for p in Rr['presets'].values() for r in p['kf_reliability'])
ax.plot([0, mx], [0, mx], color='black', lw=0.6, ls='--', label='perfect calibration')
ax.set_xlabel('KF predicted s.d. (px)'); ax.set_ylabel('Observed RMSE (px)')
ax.set_title('(c) KF reliability (held-out half)'); ax.legend(loc='upper left')
fig.savefig(os.path.join(OUT, 'cee_realdata.pdf'))
print('saved')
