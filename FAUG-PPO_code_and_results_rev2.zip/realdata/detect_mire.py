"""Four-dot feature detector for the ViSP 'mire-2' real image sequence (501 frames, 384x288).
Finds the dark square target, then the small bright dots inside it (the large central disk is
excluded by area). Points are ordered consistently by nearest-neighbour tracking.
Output: mire2_tracks.json with per-frame 8-D feature vectors (NaN when not all 4 dots found)."""
import json, glob, numpy as np, cv2
R = '/usr/share/visp-images-data/ViSP-images/mire-2'
files = sorted(glob.glob(f'{R}/image.*.png'))

def detect(img):
    _, bw = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    n, lab, st, cen = cv2.connectedComponentsWithStats(bw, 8)
    H, W = img.shape
    def ring_mean(c, r):
        yy, xx = np.ogrid[:H, :W]; d = np.sqrt((xx - c[0]) ** 2 + (yy - c[1]) ** 2)
        m = (d > r + 2) & (d < r + 6)
        return np.percentile(img[m], 35) if m.any() else 255
    def blob_mean(i):
        return img[lab == i].mean()
    def circ(i):
        w, h, a = st[i, cv2.CC_STAT_WIDTH], st[i, cv2.CC_STAT_HEIGHT], st[i, cv2.CC_STAT_AREA]
        return a / (np.pi / 4 * w * h + 1e-9), max(w, h) / max(1, min(w, h))
    disks = [i for i in range(1, n) if 600 <= st[i, cv2.CC_STAT_AREA] <= 9000 and circ(i)[0] > 0.8 and circ(i)[1] < 3.6
             and ring_mean(cen[i], np.sqrt(st[i, cv2.CC_STAT_AREA] / np.pi)) < 0.6 * blob_mean(i)]
    if not disks:
        return None
    k = max(disks, key=lambda i: st[i, cv2.CC_STAT_AREA]); dc = cen[k]; dr = max(st[k, cv2.CC_STAT_WIDTH], st[k, cv2.CC_STAT_HEIGHT]) / 2
    small = []
    for i in range(1, n):
        a = st[i, cv2.CC_STAT_AREA]
        if 4 <= a <= 0.4 * st[k, cv2.CC_STAT_AREA] and circ(i)[1] < 3.6:
            r = np.sqrt(a / np.pi)
            dist = np.linalg.norm(cen[i] - dc)
            if 1.0 * dr < dist < 4.5 * dr and ring_mean(cen[i], r) < 0.6 * blob_mean(i):
                small.append((dist, a, cen[i]))
    if len(small) < 4:
        return None
    from itertools import combinations
    cands = sorted(small, key=lambda d: d[0])[:9]
    best, bscore = None, 1e9
    for comb in combinations(cands, 4):
        P = np.array([c[2] for c in comb], dtype=np.float32)
        hull = cv2.convexHull(P)
        if len(hull) != 4 or cv2.pointPolygonTest(hull, (float(dc[0]), float(dc[1])), False) <= 0:
            continue
        aa = np.array([c[1] for c in comb], float); dd = np.array([c[0] for c in comb])
        Hh = hull.reshape(4, 2).astype(float)          # ordered corners; diagonals 0-2 and 1-3
        p1, p2, p3, p4 = Hh[0], Hh[2], Hh[1], Hh[3]
        den = (p1[0] - p2[0]) * (p3[1] - p4[1]) - (p1[1] - p2[1]) * (p3[0] - p4[0])
        if abs(den) < 1e-6:
            continue
        tx = ((p1[0] - p3[0]) * (p3[1] - p4[1]) - (p1[1] - p3[1]) * (p3[0] - p4[0])) / den
        X = p1 + tx * (p2 - p1)
        diag = 0.5 * (np.linalg.norm(p2 - p1) + np.linalg.norm(p4 - p3))
        off = np.linalg.norm(X - dc) / diag
        if off > 0.30:
            continue
        score = np.log(aa.max() / aa.min()) + 0.5 * np.log(dd.max() / dd.min()) + 4 * off
        if score < bscore:
            best, bscore = comb, score
    if best is None:
        return None
    aa = np.array([c[1] for c in best], float); dd = np.array([c[0] for c in best])
    if aa.max() > 5 * aa.min() or dd.max() > 3.0 * dd.min():
        return None
    small = list(best)
    pts = []
    for _, _, c in small:
        x0, y0 = int(round(c[0])), int(round(c[1]))
        ya, xa = max(0, y0 - 6), max(0, x0 - 6)
        win = img[ya:y0 + 7, xa:x0 + 7].astype(float)
        win = np.clip(win - np.percentile(win, 50), 0, None)
        ys, xs = np.mgrid[ya:ya + win.shape[0], xa:xa + win.shape[1]]
        w = win.sum()
        pts.append([(xs * win).sum() / w, (ys * win).sum() / w] if w > 0 else list(c))
    return np.array(pts)

def track_local(img, prev, vel, prev_area):
    """Track each dot in a local window around its constant-velocity prediction
    (local Otsu threshold, nearest bright component, area gate)."""
    H, W = img.shape; out = []; areas = []
    for k in range(4):
        cx, cy = prev[k] + vel[k]
        x0, x1 = int(max(0, cx - 18)), int(min(W, cx + 19)); y0, y1 = int(max(0, cy - 18)), int(min(H, cy + 19))
        roi = img[y0:y1, x0:x1]
        if roi.size < 100:
            return None, None
        _, bw = cv2.threshold(roi, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        n, lab, st, cen = cv2.connectedComponentsWithStats(bw, 8)
        best, bd = None, 1e9
        for j in range(1, n):
            a = st[j, cv2.CC_STAT_AREA]
            if not (0.35 * prev_area[k] <= a <= 2.8 * prev_area[k]):
                continue
            if st[j, cv2.CC_STAT_LEFT] == 0 or st[j, cv2.CC_STAT_TOP] == 0 or \
               st[j, cv2.CC_STAT_LEFT] + st[j, cv2.CC_STAT_WIDTH] >= roi.shape[1] or st[j, cv2.CC_STAT_TOP] + st[j, cv2.CC_STAT_HEIGHT] >= roi.shape[0]:
                continue                                   # touching the window border: not an isolated dot
            d = np.hypot(cen[j][0] + x0 - cx, cen[j][1] + y0 - cy)
            if d < bd:
                best, bd = j, d
        if best is None or bd > 12:
            return None, None
        m = (lab == best)
        w = roi.astype(float) * m; ys, xs = np.mgrid[y0:y1, x0:x1]
        out.append([(xs * w).sum() / w.sum(), (ys * w).sum() / w.sum()]); areas.append(st[best, cv2.CC_STAT_AREA])
    P = np.array(out, np.float32)
    if len(cv2.convexHull(P)) != 4:
        return None, None
    return np.array(out), np.array(areas, float)

def dot_areas(img, pts):
    _, bw = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    n, lab, st, cen = cv2.connectedComponentsWithStats(bw, 8)
    return np.array([st[lab[int(round(p[1])), int(round(p[0]))], cv2.CC_STAT_AREA] if lab[int(round(p[1])), int(round(p[0]))] > 0 else 50 for p in pts], float)

tracks, src = [], []
prev = None; vel = np.zeros((4, 2)); prev_area = None
for f in files:
    img = cv2.imread(f, cv2.IMREAD_GRAYSCALE)
    p, mode = None, 'miss'
    if prev is not None:
        p, ar = track_local(img, prev, vel, prev_area)
        if p is not None:
            mode = 'track'
    if p is None:
        g = detect(img)
        if g is not None:
            if prev is None:
                c = g.mean(0); g = g[np.argsort(np.arctan2(g[:, 1] - c[1], g[:, 0] - c[0]))]
            else:
                from itertools import permutations
                dm = np.linalg.norm(prev[:, None, :] - g[None, :, :], axis=2)
                g = g[list(min(permutations(range(4)), key=lambda pm: sum(dm[i, pm[i]] for i in range(4))))]
            p, ar, mode = g, dot_areas(img, g), 'detect'
    if p is not None:
        vel = (p - prev) if (prev is not None and src and src[-1] != 'miss') else np.zeros((4, 2))
        vel = np.clip(vel, -15, 15)
        prev, prev_area = p, ar
        tracks.append(p.reshape(-1).tolist())
    else:
        tracks.append([float('nan')] * 8); prev = None; vel = np.zeros((4, 2))
    src.append(mode)
T = np.array(tracks)
ok = ~np.isnan(T).any(1)
print('frames', len(T), 'tracked/detected', int(ok.sum()), f'({ok.mean()*100:.1f}%)', {m: src.count(m) for m in set(src)})
json.dump(dict(files=[f.split('/')[-1] for f in files], tracks=tracks, source=src, image_size=[384, 288]), open('mire2_tracks.json', 'w'))
