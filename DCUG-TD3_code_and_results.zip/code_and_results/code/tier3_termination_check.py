import os
os.environ.setdefault('MUJOCO_GL', 'egl')
import json
import numpy as np

from mujoco_realimage_env import RealImageMuJoCoEnv
from run_experiments import load_agent, RESULTS
from controllers import fallback_action

N_EVAL = 30
agent = load_agent('dcug_full', 1, dual=True)

results = {}
for strict in [True, False]:
    env = RealImageMuJoCoEnv(p_lose=0.08, p_recover=0.18, seed=999,
                              strict_detection_termination=strict)
    succ, lost = [], []
    for i in range(N_EVAL):
        obs, _ = env.reset()
        done = False
        while not done:
            a_safe = fallback_action(env)
            act, *_ = agent.act(obs, a_safe_np=a_safe, sample=False)
            obs, rew, done, info = env.step(act)
        succ.append(float(info['success']))
        lost.append(float(info['lost']))
    key = 'strict' if strict else 'lenient'
    results[key] = dict(success_rate=float(np.mean(succ)), lost_rate=float(np.mean(lost)), n=N_EVAL)
    print(key, results[key], flush=True)

with open(f'{RESULTS}/tier3_termination_comparison.json', 'w') as f:
    json.dump(results, f, indent=2)
print('SAVED')
