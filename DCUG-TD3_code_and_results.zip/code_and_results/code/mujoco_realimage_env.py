"""
The highest-value validation without physical hardware: instead of computing
image features analytically (as in env.py and mujoco_env.py), this renders
an actual RGB image from the camera's simulated viewpoint each control step
and extracts the 4 target-corner features via real OpenCV color-blob
detection. Everything downstream (EKF, dropout channel, reward, success
criterion, the already-trained policies) is unchanged and consumes these
really-detected pixel coordinates instead of analytically projected ones.
"""
import os
os.environ.setdefault('MUJOCO_GL', 'egl')
import numpy as np
import cv2
import mujoco

from env import image_jacobian, Z_DESIRED, DropoutChannel, DT, SUCCESS_TOL, SUCCESS_HOLD

RES = 360          # square render resolution
F_PX = 400.0        # target focal length in pixels (matches env.py's analytic model)
IMG_HALF = RES / 2  # 180, matches env.py's IMG_HALF exactly
FOVY = 2 * np.degrees(np.arctan((RES / 2) / F_PX))  # ~48.47 deg, calibrated to match F_PX

MARKER_COLORS_BGR = [(0, 0, 220), (0, 200, 0), (220, 0, 0), (0, 200, 220)]  # red,green,blue,yellow
MARKER_HALF = 0.10

XML_TEMPLATE = """
<mujoco>
  <visual><global offwidth="{res}" offheight="{res}"/></visual>
  <option timestep="0.005" gravity="0 0 0" integrator="implicitfast"/>
  <worldbody>
    <light diffuse=".9 .9 .9" pos="0 0 3" dir="0 0 -1"/>
    <geom type="plane" size="1 1 0.1" rgba=".15 .15 .15 1"/>
    <body name="m0" pos="{m0x} {m0y} 0.0" mocap="true"><geom type="sphere" size=".013" rgba="1 0 0 1"/></body>
    <body name="m1" pos="{m1x} {m1y} 0.0" mocap="true"><geom type="sphere" size=".013" rgba="0 1 0 1"/></body>
    <body name="m2" pos="{m2x} {m2y} 0.0" mocap="true"><geom type="sphere" size=".013" rgba="0 0 1 1"/></body>
    <body name="m3" pos="{m3x} {m3y} 0.0" mocap="true"><geom type="sphere" size=".013" rgba="1 1 0 1"/></body>
    <body name="cam" pos="0 0 0.6">
      <joint name="jx" type="slide" axis="1 0 0" damping="3.0"/>
      <joint name="jy" type="slide" axis="0 1 0" damping="3.0"/>
      <joint name="jz" type="slide" axis="0 0 1" damping="3.0"/>
      <joint name="jyaw" type="hinge" axis="0 0 1" damping="0.8"/>
      <inertial pos="0 0 0" mass="0.6" diaginertia="0.001 0.001 0.001"/>
      <geom type="box" size="0.02 0.02 0.02" rgba=".3 .3 .8 1"/>
      <camera name="eye" pos="0 0 0" euler="0 0 0" fovy="{fovy}"/>
    </body>
  </worldbody>
  <actuator>
    <velocity name="ax" joint="jx" kv="40"/>
    <velocity name="ay" joint="jy" kv="40"/>
    <velocity name="az" joint="jz" kv="40"/>
    <velocity name="ayaw" joint="jyaw" kv="1.5"/>
  </actuator>
</mujoco>
"""
# camera looks along -Z of its own frame by MuJoCo convention with euler applied;
# euler "0 0 -90" combined with default orientation is calibrated below via sanity check.


def detect_features(img_rgb):
    """Color-blob centroid detection for the 4 markers. Returns (8,) pixel
    feature vector [u0,v0,...,u3,v3] in OUR (u,v) convention: origin at image
    center, u right, v matching the analytic model's sign convention. Returns
    None for any marker not found (caller must handle missing detections)."""
    img = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)
    out = []
    ok = True
    for (b, g, r) in MARKER_COLORS_BGR:
        mask = ((np.abs(img[:, :, 0].astype(int) - b) < 45) &
                (np.abs(img[:, :, 1].astype(int) - g) < 45) &
                (np.abs(img[:, :, 2].astype(int) - r) < 45))
        ys, xs = np.where(mask)
        if len(xs) < 3:
            out.extend([np.nan, np.nan])
            ok = False
            continue
        px = xs.mean() - RES / 2
        py = -(ys.mean() - RES / 2)
        out.append(px)
        out.append(py)
    return np.array(out, dtype=np.float64), ok


class RealImageMuJoCoEnv:
    V_LIM = np.array([0.25, 0.25, 0.20, 0.8])

    def __init__(self, p_lose=0.08, p_recover=0.18, seed=0, target_drift_std=0.006,
                 process_noise_std=0.006, pose_range=None, strict_detection_termination=True):
        # strict_detection_termination=True reproduces the originally-reported behavior:
        # a single frame where the CV detector fails to find a marker ends the episode as
        # an unrecoverable loss. Setting this False instead treats a failed detection as a
        # recoverable dropout event (constant-velocity extrapolation, same as the channel-based
        # dropout mechanism), so the episode continues and may still succeed if detection recovers.
        self.strict_detection_termination = strict_detection_termination
        self.corner_offsets = np.array([[-MARKER_HALF, -MARKER_HALF], [MARKER_HALF, -MARKER_HALF],
                                         [MARKER_HALF, MARKER_HALF], [-MARKER_HALF, MARKER_HALF]])
        xml = XML_TEMPLATE.format(res=RES, fovy=FOVY,
                                   m0x=self.corner_offsets[0, 0], m0y=self.corner_offsets[0, 1],
                                   m1x=self.corner_offsets[1, 0], m1y=self.corner_offsets[1, 1],
                                   m2x=self.corner_offsets[2, 0], m2y=self.corner_offsets[2, 1],
                                   m3x=self.corner_offsets[3, 0], m3y=self.corner_offsets[3, 1])
        self.model = mujoco.MjModel.from_xml_string(xml)
        self.data = mujoco.MjData(self.model)
        self.renderer = mujoco.Renderer(self.model, height=RES, width=RES)
        self.rng = np.random.default_rng(seed)
        self.channel = DropoutChannel(p_lose, p_recover, self.rng)
        self.target_drift_std = target_drift_std
        self.process_noise_std = process_noise_std
        self.pose_range = pose_range or dict(xy=0.15, z=(0.45, 0.85), th=0.5)
        self.obs_dim = 22
        self.act_dim = 4
        self.mocap_ids = [mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, f'm{i}') for i in range(4)]
        self.mocap_idx = [self.model.body_mocapid[i] for i in self.mocap_ids]
        self.s_star = self._calibrate_s_star()

    def _calibrate_s_star(self):
        """Render at the exact desired pose with zero target offset to get the
        empirically-measured desired feature vector, sidestepping any small
        residual mismatch between the analytic and rendered camera models."""
        saved_qpos = self.data.qpos.copy()
        self.data.qpos[:] = [0, 0, Z_DESIRED - 0.6, 0]
        self.data.qvel[:] = 0
        for i, idx in enumerate(self.mocap_idx):
            self.data.mocap_pos[idx][:2] = self.corner_offsets[i]
            self.data.mocap_pos[idx][2] = 0.0
        mujoco.mj_forward(self.model, self.data)
        img = self._render()
        s_star, ok = detect_features(img)
        assert ok, "calibration render failed to detect all 4 markers"
        self.data.qpos[:] = saved_qpos
        return s_star

    def _render(self):
        mujoco.mj_forward(self.model, self.data)
        self.renderer.update_scene(self.data, camera='eye')
        return self.renderer.render()

    def _pose(self):
        return np.array([self.data.qpos[0], self.data.qpos[1], self.data.qpos[2] + 0.6, self.data.qpos[3]])

    def reset(self, difficulty=None):
        r = self.pose_range
        x0 = self.rng.uniform(-r['xy'], r['xy'])
        y0 = self.rng.uniform(-r['xy'], r['xy'])
        z0 = self.rng.uniform(*r['z']) - 0.6
        th0 = self.rng.uniform(-r['th'], r['th'])
        if difficulty is not None:
            x0, y0, th0 = x0 * difficulty, y0 * difficulty, th0 * difficulty
        mujoco.mj_resetData(self.model, self.data)
        self.data.qpos[:] = [x0, y0, z0, th0]
        self.data.qvel[:] = 0.0
        self.target_xy = np.zeros(2)
        self.target_vel = self.rng.normal(0, self.target_drift_std, size=2)
        for i, idx in enumerate(self.mocap_idx):
            self.data.mocap_pos[idx][:2] = self.corner_offsets[i]
            self.data.mocap_pos[idx][2] = 0.0
        self.channel.reset()
        self.t = 0
        self.prev_action = np.zeros(4)
        self.pose = self._pose()
        img = self._render()
        feat, ok = detect_features(img)
        if not ok:
            feat = np.nan_to_num(feat, nan=0.0)
        self.true_s = feat
        self.s_pred = feat.copy()
        self.s_vel = np.zeros(8)
        self.cov_trace = 0.0
        self._success_streak = 0
        return self._obs(), {}

    def _fov_violation(self, s):
        return np.any(np.isnan(s)) or np.any(np.abs(s) > IMG_HALF * 1.6)

    def _obs(self):
        err = (self.s_pred - self.s_star) / IMG_HALF
        vel = self.s_vel / IMG_HALF
        t_since = np.array([min(self.channel.steps_since_valid, 20) / 20.0])
        cov = np.array([min(self.cov_trace, 400.0) / 400.0])
        return np.concatenate([err, vel, t_since, cov, self.prev_action]).astype(np.float32)

    def step(self, action):
        action = np.clip(action, -1, 1)
        v_cmd = action * self.V_LIM
        self.data.ctrl[:] = v_cmd
        for _ in range(20):
            self.data.qvel[:] += self.rng.normal(0, self.process_noise_std, size=4) * 0.005
            mujoco.mj_step(self.model, self.data)
        self.pose = self._pose()
        self.pose[2] = np.clip(self.pose[2], 0.2, 1.2)

        self.target_vel = self.target_vel + self.rng.normal(0, self.target_drift_std * 0.3, size=2)
        self.target_vel = np.clip(self.target_vel, -0.05, 0.05)
        self.target_xy = self.target_xy + self.target_vel * DT
        for i, idx in enumerate(self.mocap_idx):
            self.data.mocap_pos[idx][:2] = self.corner_offsets[i] + self.target_xy

        img = self._render()
        feat, ok = detect_features(img)
        lost_detection = not ok
        if not lost_detection:
            self.true_s = feat

        visible = self.channel.step() and not lost_detection
        if visible:
            innov = feat - self.s_pred
            self.s_vel = 0.7 * self.s_vel + 0.3 * (innov / DT)
            self.s_pred = feat
            self.cov_trace = 5.0
        else:
            self.s_pred = self.s_pred + self.s_vel * DT
            self.cov_trace = self.cov_trace + 8.0 * (1 + 0.15 * self.channel.steps_since_valid)

        err_true = self.true_s - self.s_star
        rmse_true = np.sqrt(np.mean(err_true ** 2))
        detection_failure_is_loss = lost_detection and self.strict_detection_termination
        lost = detection_failure_is_loss or self._fov_violation(self.true_s) or self.pose[2] <= 0.21 or self.pose[2] >= 1.19

        if rmse_true < SUCCESS_TOL and not lost_detection:
            self._success_streak += 1
        else:
            self._success_streak = 0
        success = self._success_streak >= SUCCESS_HOLD

        self.prev_action = action.copy()
        self.t += 1
        done = lost or success or (self.t >= 100)
        info = dict(rmse_true=rmse_true, visible=visible, lost=lost, success=success, pose=self.pose.copy())
        return self._obs(), 0.0, done, info
