import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch, Circle, Rectangle, FancyBboxPatch

FIGS = '/home/claude/project/figs'
RES = '/home/claude/project/results'

plt.rcParams.update({
    'font.size': 10, 'font.family': 'serif',
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': True, 'grid.alpha': 0.25, 'grid.linestyle': ':',
    'figure.dpi': 140, 'savefig.bbox': 'tight',
})

C = dict(no_fallback='#999999', ekf_fallback='#4C72B0', single_critic='#DD8452',
          dcug_full='#55A868', abl_fixed_alpha='#C44E52', abl_no_vdiff='#8172B2', td3='#64B5CD')
LABEL = dict(no_fallback='Classical IBVS (no fallback)', ekf_fallback=r'Classical IBVS + $\alpha\beta$ fallback',
             single_critic='Single-critic PPO', dcug_full='DCUG-PPO (proposed)',
             abl_fixed_alpha=r'Fixed $\alpha{=}0.5$ (no gate)', abl_no_vdiff='Gate w/o critic-disagreement',
             td3='TD3')

train_dcug = json.load(open(f'{RES}/train_dcug_full.json'))
train_sc = json.load(open(f'{RES}/train_single_critic.json'))
train_fa = json.load(open(f'{RES}/train_abl_fixed_alpha.json'))
train_nv = json.load(open(f'{RES}/train_abl_no_vdiff.json'))
train_td3 = [json.load(open(f'{RES}/train_td3_seed{sd}.json')) for sd in [1, 2, 3]]
ev = json.load(open(f'{RES}/eval_results.json'))
extra = json.load(open(f'{RES}/extra_data.json'))


# ============================================================ 1
def fig_system_schematic():
    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    ax.set_xlim(0, 10); ax.set_ylim(0, 7); ax.axis('off')
    # camera body
    cam = FancyBboxPatch((4.1, 5.1), 1.6, 1.0, boxstyle='round,pad=0.05', fc='#4C72B0', ec='k', lw=1.2)
    ax.add_patch(cam)
    ax.text(4.9, 5.6, 'Eye-in-hand\ncamera', ha='center', va='center', fontsize=8.5, color='white')
    # arm stub
    ax.plot([4.9, 4.9], [6.1, 6.8], color='k', lw=4)
    ax.text(4.9, 6.95, 'robot end-effector\n(pose known via kinematics)', ha='center', fontsize=7.5)
    # optical rays
    for dx in [-2.6, 0, 2.6]:
        ax.add_patch(FancyArrowPatch((4.9, 5.1), (4.9 + dx, 1.4), arrowstyle='-', color='#4C72B0',
                                      lw=0.9, ls='--', alpha=0.6))
    # target square
    tx, ty, s = 4.9, 1.2, 1.1
    sq = plt.Polygon([(tx - s, ty - s * 0.5), (tx + s, ty - s * 0.5),
                       (tx + s, ty + s * 0.5), (tx - s, ty + s * 0.5)],
                      closed=True, fc='#DD8452', ec='k', lw=1.2, alpha=0.9)
    ax.add_patch(sq)
    for cx, cy in [(tx - s, ty - s * 0.5), (tx + s, ty - s * 0.5), (tx + s, ty + s * 0.5), (tx - s, ty + s * 0.5)]:
        ax.add_patch(Circle((cx, cy), 0.07, fc='k'))
    ax.text(tx, ty - 0.9, 'planar target (4 point features)\ndrifting in-plane', ha='center', fontsize=7.8)
    # dropout channel icon
    ax.add_patch(FancyBboxPatch((7.3, 3.0), 2.1, 1.4, boxstyle='round,pad=0.06', fc='#EEEEEE', ec='#C44E52', lw=1.3))
    ax.text(8.35, 3.95, 'Vision pipeline', ha='center', fontsize=7.8, weight='bold')
    ax.text(8.35, 3.55, 'Markov dropout\nchannel', ha='center', fontsize=7.5)
    ax.text(8.35, 3.15, r'VISIBLE $\leftrightarrow$ DROPOUT', ha='center', fontsize=7)
    ax.add_patch(FancyArrowPatch((6.5, 3.7), (7.3, 3.7), arrowstyle='->', color='k', lw=1.1))
    ax.add_patch(FancyArrowPatch((7.3, 4.6), (5.7, 5.4), arrowstyle='->', color='k', lw=1.1,
                                  connectionstyle='arc3,rad=0.25'))
    ax.text(7.3, 4.9, 'feature stream\n(or blackout)', fontsize=7, ha='center')
    # controller box
    ax.add_patch(FancyBboxPatch((0.3, 3.0), 2.6, 1.6, boxstyle='round,pad=0.06', fc='#DCEEDC', ec='#55A868', lw=1.3))
    ax.text(1.6, 4.15, 'DCUG-PPO', ha='center', fontsize=8.5, weight='bold')
    ax.text(1.6, 3.75, r'raw action + gate $\alpha$', ha='center', fontsize=7.3)
    ax.text(1.6, 3.4, 'blended with fallback', ha='center', fontsize=7.3)
    ax.add_patch(FancyArrowPatch((2.9, 3.8), (4.1, 5.2), arrowstyle='->', color='k', lw=1.1,
                                  connectionstyle='arc3,rad=-0.2'))
    ax.text(3.0, 4.7, 'velocity\ncommand', fontsize=7, ha='left')
    ax.set_title('Eye-in-hand IBVS under intermittent camera dropout', fontsize=10.5)
    fig.savefig(f'{FIGS}/fig01_system_schematic.pdf')
    plt.close(fig)


# ============================================================ 2
def fig_dropout_process():
    fig, axes = plt.subplots(1, 2, figsize=(9.5, 3.2), gridspec_kw=dict(width_ratios=[1, 1.8]))
    ax = axes[0]
    ax.axis('off'); ax.set_xlim(0, 4); ax.set_ylim(0, 3)
    v = Circle((1, 1.5), 0.62, fc='#DCEEDC', ec='#55A868', lw=1.6)
    d = Circle((3, 1.5), 0.62, fc='#FBE0DE', ec='#C44E52', lw=1.6)
    ax.add_patch(v); ax.add_patch(d)
    ax.text(1, 1.5, 'VISIBLE', ha='center', va='center', fontsize=9, weight='bold')
    ax.text(3, 1.5, 'DROPOUT', ha='center', va='center', fontsize=9, weight='bold')
    ax.add_patch(FancyArrowPatch((1.62, 1.75), (2.38, 1.75), arrowstyle='->', lw=1.3,
                                  connectionstyle='arc3,rad=-0.3'))
    ax.text(2.0, 2.25, r'$p_{lose}$', ha='center', fontsize=9)
    ax.add_patch(FancyArrowPatch((2.38, 1.25), (1.62, 1.25), arrowstyle='->', lw=1.3,
                                  connectionstyle='arc3,rad=-0.3'))
    ax.text(2.0, 0.75, r'$p_{recover}$', ha='center', fontsize=9)
    ax.set_title('(a) Two-state dropout channel', fontsize=9.5)

    traj = extra['qualitative']['dcug_full']
    vis = [1 if s['visible'] else 0 for s in traj]
    t = np.arange(len(vis)) * 0.1
    ax2 = axes[1]
    ax2.fill_between(t, 0, 1, where=np.array(vis) == 0, color='#C44E52', alpha=0.25, step='post',
                      label='dropout interval')
    ax2.plot(t, vis, drawstyle='steps-post', color='k', lw=1.2)
    ax2.set_yticks([0, 1]); ax2.set_yticklabels(['dropout', 'visible'])
    ax2.set_xlabel('time (s)')
    ax2.set_title('(b) Example realized dropout timeline (severe preset)', fontsize=9.5)
    ax2.legend(loc='upper center', bbox_to_anchor=(0.5, 1.28), fontsize=8, framealpha=0.9)
    fig.savefig(f'{FIGS}/fig02_dropout_process.pdf')
    plt.close(fig)


# ============================================================ 3
def fig_architecture():
    fig, ax = plt.subplots(figsize=(8.6, 4.6))
    ax.axis('off'); ax.set_xlim(0, 12); ax.set_ylim(0, 7)

    def box(xy, w, h, text, fc, fs=8.3):
        b = FancyBboxPatch(xy, w, h, boxstyle='round,pad=0.06', fc=fc, ec='k', lw=1.1)
        ax.add_patch(b)
        ax.text(xy[0] + w / 2, xy[1] + h / 2, text, ha='center', va='center', fontsize=fs)
        return (xy[0] + w / 2, xy[1] + h / 2)

    box((0.2, 3.0), 1.8, 1.1, 'obs $o_t$\n(22-d)', '#EEEEEE')
    box((2.5, 2.9), 1.8, 1.3, 'shared\ntrunk MLP', '#CFE8FF')
    box((4.8, 4.8), 2.0, 0.9, r'$\mu_{raw},\ \sigma_{raw}$', '#DCEEDC')
    box((4.8, 1.3), 2.0, 0.9, 'gate head', '#FBE0DE')
    box((7.3, 4.3), 1.7, 0.9, r'$V_{opt}(o_t)$', '#CFE8FF')
    box((7.3, 2.3), 1.7, 0.9, r'$V_{pess}(o_t)$\n(expectile, $\tau{=}0.1$)', '#CFE8FF')
    box((9.4, 3.3), 1.8, 0.9, r'$\Delta V = V_{opt}{-}V_{pess}$', '#FFF3CF')
    box((0.2, 0.2), 1.8, 0.9, r'$a_{safe}$' + '\n(fallback ctrl.)', '#EEEEEE')
    box((7.5, 0.2), 2.2, 0.9, r'$\alpha \in (0,1)$', '#FBE0DE')
    box((2.9, 0.2) , 3.0, 0.9, r'$\mu_f=\alpha\mu_{raw}{+}(1{-}\alpha)a_{safe}$'+'\n'+r'$\sigma_f=\alpha\sigma_{raw}{+}\epsilon$', '#DCEEDC', fs=7.6)

    arrows = [((2.0, 3.55), (2.5, 3.55)),
              ((4.3, 3.9), (4.8, 5.2)),
              ((4.3, 3.3), (7.3, 4.7)),
              ((4.3, 3.1), (7.3, 2.7)),
              ((9.05, 4.7), (9.4, 3.9)),
              ((9.05, 2.7), (9.4, 3.6)),
              ((9.4, 3.55), (8.6, 1.65)),
              ((4.3, 3.0), (4.8, 1.9)),
              ((5.8, 1.3), (5.8, 1.1)),
              ((7.5, 0.65), (5.9, 0.65)),
              ((1.1, 1.1), (2.9, 0.6)),
              ((5.8, 4.8), (4.4, 1.1)),
              ]
    for a, b in arrows:
        ax.add_patch(FancyArrowPatch(a, b, arrowstyle='->', lw=1.0, color='#555555',
                                      connectionstyle='arc3,rad=0.08'))
    ax.text(6.0, 6.4, 'DCUG-PPO actor / dual-critic architecture', ha='center', fontsize=11, weight='bold')
    fig.savefig(f'{FIGS}/fig03_architecture.pdf')
    plt.close(fig)


def _mean_std_curve(train_json, key):
    seeds_hist = [np.array([[h['episode'], h[key]] for h in r['history']]) for r in train_json]
    minlen = min(len(s) for s in seeds_hist)
    seeds_hist = [s[:minlen] for s in seeds_hist]
    ep = seeds_hist[0][:, 0]
    vals = np.stack([s[:, 1] for s in seeds_hist])
    return ep, vals.mean(0), vals.std(0)


# ============================================================ 4 + 5
def fig_training_curves():
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.6))
    for name, tj, lbl in [('dcug_full', train_dcug, LABEL['dcug_full'] + ' (10 seeds)'),
                            ('single_critic', train_sc, LABEL['single_critic'] + ' (10 seeds)'),
                            ('td3', train_td3, LABEL['td3'] + ' (3 seeds)')]:
        ep, m, s = _mean_std_curve(tj, 'mean_return')
        axes[0].plot(ep, m, color=C[name], label=lbl, lw=1.8)
        axes[0].fill_between(ep, m - s, m + s, color=C[name], alpha=0.2)
        ep, m, s = _mean_std_curve(tj, 'success_rate')
        axes[1].plot(ep, m, color=C[name], label=lbl, lw=1.8)
        axes[1].fill_between(ep, m - s, m + s, color=C[name], alpha=0.2)
    axes[0].set_xlabel('training episode'); axes[0].set_ylabel('mean episodic return (200-ep window)')
    axes[0].set_title('(a) Training return')
    axes[1].set_xlabel('training episode'); axes[1].set_ylabel('success rate (200-ep window)')
    axes[1].set_title('(b) Training success rate')
    axes[1].legend(fontsize=8.5, loc='upper left')
    fig.savefig(f'{FIGS}/fig04_training_curves.pdf')
    plt.close(fig)


# ============================================================ 6
def fig_seed_reliability():
    fig, ax = plt.subplots(figsize=(7.6, 3.8))
    diffs = ['mild', 'moderate', 'severe']
    names = ['single_critic', 'td3', 'dcug_full']
    width = 0.24
    xs = np.arange(len(diffs))
    offs = {'single_critic': -width, 'td3': 0, 'dcug_full': width}
    for name in names:
        pts_x, pts_y = [], []
        means = []
        off = offs[name]
        for i, d in enumerate(diffs):
            succ = [x['success_rate'] for x in (td3_eval[d][:3] if name == 'td3' else ev[d][name])]
            means.append(np.mean(succ))
            pts_x += [xs[i] + off + np.random.uniform(-0.04, 0.04) for _ in succ]
            pts_y += succ
        ax.bar(xs + off, means, width=width, color=C[name], alpha=0.55, label=LABEL[name])
        ax.scatter(pts_x, pts_y, color=C[name], edgecolor='k', s=34, zorder=5, linewidth=0.6)
    ax.set_xticks(xs); ax.set_xticklabels(diffs)
    ax.set_ylabel('per-seed deterministic success rate')
    ax.set_title('Across-seed reliability: individual seeds shown as dots\n(TD3: 3 seeds; PPO variants: 10 seeds)', fontsize=10)
    ax.legend(fontsize=8.5, loc='upper center', bbox_to_anchor=(0.5, -0.18), ncol=3)
    fig.subplots_adjust(bottom=0.3)
    fig.savefig(f'{FIGS}/fig05_seed_reliability.pdf')
    plt.close(fig)


# ============================================================ 7
def fig_qualitative_trajectory():
    fig, ax = plt.subplots(figsize=(6.0, 5.4))
    from env import project
    order = ['no_fallback', 'ekf_fallback', 'single_critic', 'dcug_full']
    for name in order:
        traj = extra['qualitative'][name]
        xs = [s['pose'][0] for s in traj]
        ys = [s['pose'][1] for s in traj]
        ax.plot(xs, ys, color=C[name], lw=1.7, label=LABEL[name], alpha=0.9)
        ax.scatter([xs[0]], [ys[0]], color=C[name], marker='o', s=45, zorder=5)
        ax.scatter([xs[-1]], [ys[-1]], color=C[name], marker='X', s=60, zorder=5)
    ax.scatter([0], [0], color='k', marker='*', s=180, zorder=6, label='desired (over target)')
    ax.set_xlabel('camera $x$ (m)'); ax.set_ylabel('camera $y$ (m)')
    ax.set_title('Camera-frame trajectories, identical severe-dropout episode\n(circle = start, X = episode end, star = goal)', fontsize=9.5)
    ax.legend(fontsize=7.6, loc='upper center', bbox_to_anchor=(0.5, -0.14), ncol=2)
    ax.set_aspect('equal', adjustable='datalim')
    fig.subplots_adjust(bottom=0.32)
    fig.savefig(f'{FIGS}/fig06_qualitative_trajectory.pdf')
    plt.close(fig)


# ============================================================ 8 + 9
def fig_rmse_and_gate():
    fig, axes = plt.subplots(2, 1, figsize=(7.2, 5.6), sharex=True)
    order = ['no_fallback', 'ekf_fallback', 'single_critic', 'dcug_full']
    maxlen = max(len(extra['qualitative'][n]) for n in order)
    for name in order:
        traj = extra['qualitative'][name]
        t = np.arange(len(traj)) * 0.1
        rmse = [s['rmse'] for s in traj]
        axes[0].plot(t, rmse, color=C[name], lw=1.6, label=LABEL[name])
    axes[0].axhline(5.5, color='k', ls=':', lw=1, label='success threshold')
    axes[0].set_ylabel('true feature RMSE (px)')
    axes[0].set_yscale('log')
    axes[0].set_title('(a) Feature-error evolution, matched severe-dropout episode')
    axes[0].legend(fontsize=7.4, ncol=3, loc='upper center', bbox_to_anchor=(0.5, 1.32))

    dtraj = extra['qualitative']['dcug_full']
    t = np.arange(len(dtraj)) * 0.1
    alpha = [s['alpha'] for s in dtraj]
    vis = [s['visible'] for s in dtraj]
    axes[1].fill_between(t, 0, 1, where=~np.array(vis), color='#C44E52', alpha=0.20, step='post',
                          label='dropout interval')
    axes[1].plot(t, alpha, color='#55A868', lw=1.8, drawstyle='steps-post', label=r'gate $\alpha_t$')
    axes[1].set_ylabel(r'gate value $\alpha$')
    axes[1].set_xlabel('time (s)')
    axes[1].set_title(r'(b) DCUG-PPO learned gate $\alpha_t$ (1 = trust policy, 0 = trust fallback)')
    axes[1].legend(fontsize=8, loc='upper right')
    axes[1].set_ylim(0, 1.05)
    fig.savefig(f'{FIGS}/fig07_rmse_and_gate.pdf')
    plt.close(fig)


# ============================================================ 10 + 11
def fig_success_lost_vs_severity():
    fig, axes = plt.subplots(1, 2, figsize=(11.4, 3.8))
    diffs = ['mild', 'moderate', 'severe']
    names = ['no_fallback', 'ekf_fallback', 'single_critic', 'td3', 'dcug_full']
    x = np.arange(len(diffs))
    width = 0.16
    for i, name in enumerate(names):
        succ_m, succ_s, lost_m = [], [], []
        for d in diffs:
            if name in ('no_fallback', 'ekf_fallback'):
                key = 'classical_' + name
                succ_m.append(ev[d][key]['success_rate']); succ_s.append(0.0)
                lost_m.append(ev[d][key]['lost_rate'])
            elif name == 'td3':
                arr = [e['success_rate'] for e in td3_eval[d][:3]]
                larr = [e['lost_rate'] for e in td3_eval[d][:3]]
                succ_m.append(np.mean(arr)); succ_s.append(np.std(arr))
                lost_m.append(np.mean(larr))
            else:
                arr = [e['success_rate'] for e in ev[d][name]]
                larr = [e['lost_rate'] for e in ev[d][name]]
                succ_m.append(np.mean(arr)); succ_s.append(np.std(arr))
                lost_m.append(np.mean(larr))
        axes[0].bar(x + (i - 2) * width, succ_m, width=width, yerr=succ_s, color=C[name],
                    label=LABEL[name], capsize=2.5)
        axes[1].bar(x + (i - 2) * width, lost_m, width=width, color=C[name])
    axes[0].set_xticks(x); axes[0].set_xticklabels(diffs); axes[0].set_ylabel('success rate')
    axes[0].set_title('(a) Success rate vs. dropout severity')
    axes[1].set_xticks(x); axes[1].set_xticklabels(diffs); axes[1].set_ylabel('target-loss (FOV exit) rate')
    axes[1].set_title('(b) Target-loss rate vs. dropout severity')
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, fontsize=7.6, loc='upper center', bbox_to_anchor=(0.5, 1.16), ncol=5, columnspacing=1.2)
    fig.subplots_adjust(top=0.76)
    fig.savefig(f'{FIGS}/fig08_success_lost_vs_severity.pdf')
    plt.close(fig)


# ============================================================ 12
def fig_heatmaps():
    hm = extra['heatmap']
    dcug = np.array(hm['dcug']); ekf = np.array(hm['ekf'])
    pl = hm['p_lose_grid']; pr = hm['p_recover_grid']
    fig, axes = plt.subplots(1, 3, figsize=(15.5, 5.0), gridspec_kw=dict(width_ratios=[1, 1, 0.06]))
    im0 = axes[0].imshow(ekf, cmap='RdYlGn', vmin=0, vmax=1, aspect='auto')
    im1 = axes[1].imshow(dcug, cmap='RdYlGn', vmin=0, vmax=1, aspect='auto')
    for i in range(len(pr)):
        for j in range(len(pl)):
            axes[0].text(j, i, f'{ekf[i,j]:.2f}', ha='center', va='center', fontsize=10.5, color='black')
            axes[1].text(j, i, f'{dcug[i,j]:.2f}', ha='center', va='center', fontsize=10.5, color='black')
    for ax, title in [(axes[0], r'(a) Classical IBVS + $\alpha\beta$ fallback'), (axes[1], '(b) DCUG-PPO (proposed)')]:
        ax.set_xticks(range(len(pl))); ax.set_xticklabels([f'{v:.2f}' for v in pl], fontsize=12)
        ax.set_yticks(range(len(pr))); ax.set_yticklabels([f'{v:.2f}' for v in pr], fontsize=12)
        ax.set_xlabel(r'$p_{lose}$', fontsize=13); ax.set_title(title, fontsize=14)
    axes[0].set_ylabel(r'$p_{recover}$', fontsize=13)
    cb = fig.colorbar(im1, cax=axes[2])
    cb.set_label('success rate', fontsize=13)
    cb.ax.tick_params(labelsize=11)
    fig.suptitle('Robustness landscape over the dropout Markov-chain parameters', fontsize=15.5, y=1.03)
    fig.savefig(f'{FIGS}/fig09_heatmaps.pdf')
    plt.close(fig)


# ============================================================ 13
def fig_ablation():
    fig, ax = plt.subplots(figsize=(11.5, 5.4))
    names = ['no_fallback', 'ekf_fallback', 'single_critic', 'td3', 'abl_fixed_alpha', 'abl_no_vdiff', 'dcug_full']
    means, stds = [], []
    for name in names:
        if name == 'no_fallback':
            means.append(ev['moderate']['classical_no_fallback']['success_rate']); stds.append(0)
        elif name == 'ekf_fallback':
            means.append(ev['moderate']['classical_ekf_fallback']['success_rate']); stds.append(0)
        elif name == 'single_critic':
            arr = [e['success_rate'] for e in ev['moderate']['single_critic']]
            means.append(np.mean(arr)); stds.append(np.std(arr))
        elif name == 'td3':
            arr = [e['success_rate'] for e in td3_eval['moderate'][:3]]
            means.append(np.mean(arr)); stds.append(np.std(arr))
        elif name in ('abl_fixed_alpha', 'abl_no_vdiff'):
            arr = [e['success_rate'] for e in ev['ablation_moderate'][name]]
            means.append(np.mean(arr)); stds.append(np.std(arr))
        else:
            arr = [e['success_rate'] for e in ev['moderate']['dcug_full']]
            means.append(np.mean(arr)); stds.append(np.std(arr))
    labs = [LABEL.get(n, n) for n in names]
    colors = [C.get(n, '#777777') for n in names]
    xpos = np.arange(len(names))
    bars = ax.bar(xpos, means, yerr=stds, color=colors, capsize=4, edgecolor='k', linewidth=0.7)
    for x, m in zip(xpos, means):
        ax.text(x, m + 0.03, f'{m:.2f}', ha='center', fontsize=11.5)
    ax.set_xticks(xpos); ax.set_xticklabels(labs, rotation=28, ha='right', fontsize=11.5)
    ax.set_ylabel('success rate (moderate dropout)', fontsize=13)
    ax.tick_params(axis='y', labelsize=11.5)
    ax.set_ylim(0, 1.12)
    ax.set_title('Component/algorithm comparison, including the TD3 off-policy baseline', fontsize=14.5)
    fig.savefig(f'{FIGS}/fig10_ablation.pdf')
    plt.close(fig)


# ============================================================ 14
def fig_convergence_time():
    fig, ax = plt.subplots(figsize=(6.6, 3.8))
    names = ['no_fallback', 'ekf_fallback', 'single_critic', 'dcug_full']
    data = [np.array(extra['convergence'][n]) * 0.1 for n in names]  # steps -> seconds
    parts = ax.violinplot(data, showmeans=True, showextrema=True)
    for pc, name in zip(parts['bodies'], names):
        pc.set_facecolor(C[name]); pc.set_alpha(0.65)
    ax.set_xticks(range(1, len(names) + 1))
    ax.set_xticklabels([LABEL[n] for n in names], fontsize=7.6, rotation=18, ha='right')
    ax.set_ylabel('time-to-convergence (s), successful episodes only')
    ax.set_title('Convergence-time distributions (moderate dropout)')
    fig.savefig(f'{FIGS}/fig11_convergence_time.pdf')
    plt.close(fig)


# ============================================================ 15
def fig_control_effort():
    fig, axes = plt.subplots(1, 2, figsize=(10.4, 3.6))
    names = ['no_fallback', 'ekf_fallback', 'single_critic', 'td3', 'dcug_full']
    for ax, key, title in [(axes[0], 'effort', '(a) Mean control effort $\\sum a^2$ per step'),
                            (axes[1], 'jerk', '(b) Mean action jerk per step')]:
        means, stds = [], []
        for n in names:
            if n == 'td3':
                means.append(td3_extra[key]); stds.append(td3_extra[key + '_std'])
            else:
                means.append(np.mean(extra[key][n])); stds.append(np.std(extra[key][n]))
        ax.bar(range(len(names)), means, yerr=stds, color=[C[n] for n in names], capsize=3, edgecolor='k', linewidth=0.6)
        ax.set_xticks(range(len(names))); ax.set_xticklabels([LABEL[n] for n in names], rotation=22, ha='right', fontsize=7.6)
        ax.set_title(title, fontsize=9.5)
    fig.savefig(f'{FIGS}/fig12_control_effort.pdf')
    plt.close(fig)


# ============================================================ 16
def fig_distance_sensitivity():
    fig, ax = plt.subplots(figsize=(6.8, 3.8))
    scales = ['near', 'medium', 'far']
    names = ['no_fallback', 'ekf_fallback', 'single_critic', 'dcug_full']
    x = np.arange(len(scales))
    width = 0.19
    for i, name in enumerate(names):
        vals = [extra['distance_sensitivity'][s][name] for s in scales]
        ax.bar(x + (i - 1.5) * width, vals, width=width, color=C[name], label=LABEL[name], edgecolor='k', linewidth=0.5)
    ax.set_xticks(x); ax.set_xticklabels(scales)
    ax.set_ylabel('success rate')
    ax.set_title('Sensitivity to initial pose displacement (moderate dropout)')
    ax.legend(fontsize=7.6, loc='upper center', bbox_to_anchor=(0.5, -0.16), ncol=2)
    fig.subplots_adjust(bottom=0.3)
    fig.savefig(f'{FIGS}/fig13_distance_sensitivity.pdf')
    plt.close(fig)


# ============================================================ 17
def fig_timing():
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    order = ['classical', 'single_critic', 'td3', 'dcug_full']
    labs = [r'Classical IBVS' + '\n' + r'(+$\alpha\beta$)', 'Single-critic\nPPO', 'TD3', 'DCUG-PPO\n(proposed)']
    cols = [C['ekf_fallback'], C['single_critic'], C['td3'], C['dcug_full']]
    vals = [extra['timing_ms']['classical'], extra['timing_ms']['single_critic'], td3_extra['timing_ms'], extra['timing_ms']['dcug_full']]
    ax.bar(range(4), vals, color=cols, edgecolor='k', linewidth=0.6)
    for i, v in enumerate(vals):
        ax.text(i, v + max(vals) * 0.02, f'{v:.3f} ms', ha='center', fontsize=8.5)
    ax.set_xticks(range(4)); ax.set_xticklabels(labs, fontsize=8.5)
    ax.set_ylabel('wall-clock time per control step (ms)')
    ax.set_title('Inference cost (single CPU core)')
    fig.savefig(f'{FIGS}/fig14_timing.pdf')
    plt.close(fig)


# ============================================================ 18
def fig_summary_radar():
    from math import pi
    cats = ['Success\n(moderate)', 'Success\n(severe)', 'Low target\nloss', 'Sample\nefficiency', 'Seed\nreliability', 'Smoothness']
    def norm(v, lo, hi):
        return float(np.clip((v - lo) / (hi - lo), 0, 1))
    sc_succ_m = np.mean([e['success_rate'] for e in ev['moderate']['single_critic']])
    sc_succ_sev = np.mean([e['success_rate'] for e in ev['severe']['single_critic']])
    dc_succ_m = np.mean([e['success_rate'] for e in ev['moderate']['dcug_full']])
    dc_succ_sev = np.mean([e['success_rate'] for e in ev['severe']['dcug_full']])
    ekf_succ_m = ev['moderate']['classical_ekf_fallback']['success_rate']
    ekf_succ_sev = ev['severe']['classical_ekf_fallback']['success_rate']
    sc_lost = np.mean([e['lost_rate'] for e in ev['moderate']['single_critic']])
    dc_lost = np.mean([e['lost_rate'] for e in ev['moderate']['dcug_full']])
    ekf_lost = ev['moderate']['classical_ekf_fallback']['lost_rate']
    sc_seedstd = np.std([e['success_rate'] for e in ev['moderate']['single_critic']])
    dc_seedstd = np.std([e['success_rate'] for e in ev['moderate']['dcug_full']])
    sc_eff = np.mean(extra['effort']['single_critic']); dc_eff = np.mean(extra['effort']['dcug_full'])
    ekf_eff = np.mean(extra['effort']['ekf_fallback'])
    series = {
        'ekf_fallback': [ekf_succ_m, ekf_succ_sev, 1 - ekf_lost, 1.0, 1.0, 1 - norm(ekf_eff, 0, 0.6)],
        'single_critic': [sc_succ_m, sc_succ_sev, 1 - sc_lost, norm(1, 0, 2), 1 - norm(sc_seedstd, 0, 0.5),
                           1 - norm(sc_eff, 0, 0.6)],
        'dcug_full': [dc_succ_m, dc_succ_sev, 1 - dc_lost, norm(1, 0, 1), 1 - norm(dc_seedstd, 0, 0.5),
                      1 - norm(dc_eff, 0, 0.6)],
    }
    N = len(cats)
    angles = [n / N * 2 * pi for n in range(N)] + [0]
    fig, ax = plt.subplots(figsize=(7.6, 7.6), subplot_kw=dict(polar=True))
    for name, vals in series.items():
        vals = vals + vals[:1]
        ax.plot(angles, vals, color=C[name], lw=2.4, label=LABEL[name])
        ax.fill(angles, vals, color=C[name], alpha=0.12)
    ax.set_xticks(angles[:-1]); ax.set_xticklabels(cats, fontsize=12.5)
    ax.set_yticks([0.25, 0.5, 0.75, 1.0]); ax.set_yticklabels(['.25', '.5', '.75', '1'], fontsize=10.5)
    ax.set_title('Multi-criteria comparison (higher = better, normalized)', fontsize=14, y=1.1)
    ax.legend(loc='upper right', bbox_to_anchor=(1.45, 1.18), fontsize=11.5)
    fig.savefig(f'{FIGS}/fig15_radar_summary.pdf')
    plt.close(fig)


# ============================================================ 16
def fig_sample_efficiency():
    fig, ax = plt.subplots(figsize=(6.6, 3.8))
    names = ['single_critic', 'dcug_full']
    trains = {'single_critic': train_sc, 'dcug_full': train_dcug}
    all_x, all_y, all_c = [], [], []
    for i, name in enumerate(names):
        for r in trains[name]:
            hist = r['history']
            budget = hist[-1]['episode']
            cross = next((h['episode'] for h in hist if h['success_rate'] >= 0.5), None)
            censored = cross is None
            val = budget if censored else cross
            marker = '^' if censored else 'o'
            ax.scatter([i + np.random.uniform(-0.08, 0.08)], [val], color=C[name], edgecolor='k',
                       s=90, marker=marker, zorder=5)
    for i, name in enumerate(names):
        vals = []
        n_cens = 0
        for r in trains[name]:
            hist = r['history']
            cross = next((h['episode'] for h in hist if h['success_rate'] >= 0.5), None)
            if cross is None:
                n_cens += 1
            else:
                vals.append(cross)
        if vals:
            ax.bar(i, np.mean(vals), width=0.5, color=C[name], alpha=0.35, zorder=1)
        if n_cens:
            ax.text(i, 3450, f'{n_cens}/10 seeds never\nreached 50%\nwithin their budget',
                    ha='center', fontsize=7.3, color=C[name])
    ax.scatter([], [], color='gray', edgecolor='k', marker='o', s=90, label='reached 50% success')
    ax.scatter([], [], color='gray', edgecolor='k', marker='^', s=90, label='censored (did not reach\nwithin that seed\'s budget)')
    ax.set_xticks(range(len(names))); ax.set_xticklabels([LABEL[n] for n in names], fontsize=8.5)
    ax.set_ylabel('training episodes to reach 50% windowed\nsuccess rate (stochastic rollout)')
    ax.set_title('Sample efficiency during training (10 seeds each;\nseven of ten seeds per variant used a 2500-episode budget)', fontsize=9.5)
    ax.legend(fontsize=7.6, loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=2)
    fig.subplots_adjust(bottom=0.34)
    ax.set_ylim(0, 3700)
    fig.savefig(f'{FIGS}/fig16_sample_efficiency.pdf')
    plt.close(fig)


extra2 = json.load(open(f'{RES}/extra_data2.json'))
mj = json.load(open(f'{RES}/mujoco_transfer.json'))
td3_eval = json.load(open(f'{RES}/eval_td3.json'))
td3_extra = json.load(open(f'{RES}/td3_effort_timing.json'))


# ============================================================ 17
def fig_noise_robustness():
    fig, ax = plt.subplots(figsize=(6.6, 3.8))
    nr = extra2['noise_robustness']
    levels = nr['noise_levels']
    for name in ['ekf_fallback', 'single_critic', 'dcug_full']:
        ax.plot(levels, nr[name], marker='o', color=C[name], label=LABEL[name], lw=1.8)
    ax.axvline(0.5, color='gray', ls=':', lw=1)
    ax.text(0.55, 0.15, 'training\nnoise level', fontsize=7, color='gray')
    ax.set_xlabel('pixel measurement noise $\\sigma$ (px)')
    ax.set_ylabel('success rate (moderate dropout)')
    ax.set_title('Robustness to pixel noise beyond the training level')
    ax.set_ylim(0.5, 1.02)
    ax.legend(fontsize=7.6, loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=2)
    fig.subplots_adjust(bottom=0.32)
    fig.savefig(f'{FIGS}/fig17_noise_robustness.pdf')
    plt.close(fig)


# ============================================================ 18
def fig_computational_scaling():
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.6))
    cs = extra2['computational_scaling']
    hiddens = sorted(int(k) for k in cs.keys())
    rt = [cs[str(h)]['runtime_ms'] for h in hiddens]
    params = [cs[str(h)]['n_params'] for h in hiddens]
    axes[0].plot(hiddens, rt, marker='o', color=C['dcug_full'], lw=1.8)
    axes[0].set_xlabel('hidden units per layer'); axes[0].set_ylabel('forward-pass time (ms)')
    axes[0].set_title('(a) Inference cost vs. network width')
    axes[0].set_xscale('log', base=2); axes[0].set_xticks(hiddens); axes[0].set_xticklabels(hiddens)
    axes[1].plot(params, rt, marker='s', color=C['single_critic'], lw=1.8)
    axes[1].set_xlabel('total parameters (actor + both critics)'); axes[1].set_ylabel('forward-pass time (ms)')
    axes[1].set_title('(b) Inference cost vs. parameter count')
    axes[1].set_xscale('log')
    fig.savefig(f'{FIGS}/fig18_computational_scaling.pdf')
    plt.close(fig)


# ============================================================ 19
def fig_action_smoothness():
    fig, axes = plt.subplots(2, 1, figsize=(7.2, 5.6), sharex=True)
    names = ['single_critic', 'dcug_full']
    comp = {'no_fallback': extra['qualitative']['no_fallback'],
            'ekf_fallback': extra['qualitative']['ekf_fallback'],
            'single_critic': extra['qualitative']['single_critic'],
            'dcug_full': extra['qualitative']['dcug_full']}
    for ax, dim, ylab in [(axes[0], 0, '$v_x$ (normalized)'), (axes[1], 3, '$\\omega_z$ (normalized)')]:
        for name in ['single_critic', 'dcug_full']:
            traj = comp[name]
            t = np.arange(len(traj)) * 0.1
            v = [s['action'][dim] for s in traj]
            ax.plot(t, v, color=C[name], lw=1.5, label=LABEL[name])
        ax.set_ylabel(ylab)
        ax.axhline(0, color='gray', lw=0.6)
    axes[0].set_title('Commanded action over time, matched severe-dropout episode', fontsize=10)
    axes[1].set_xlabel('time (s)')
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, fontsize=8.5, loc='upper center', bbox_to_anchor=(0.5, 0.02), ncol=2)
    fig.subplots_adjust(bottom=0.16, hspace=0.28)
    fig.savefig(f'{FIGS}/fig19_action_smoothness.pdf')
    plt.close(fig)


# ============================================================ 20
def fig_disturbance_recovery():
    fig, ax = plt.subplots(figsize=(6.8, 3.8))
    dist = extra2['disturbance']
    jump_step = dist['jump_step']
    for name in ['ekf_fallback', 'single_critic', 'dcug_full']:
        traj = dist[name]
        t = np.arange(len(traj)) * 0.1
        rmse = [s['rmse'] for s in traj]
        ax.plot(t, rmse, color=C[name], lw=1.7, label=LABEL[name])
    ax.axvline(jump_step * 0.1, color='k', ls='--', lw=1.2)
    ax.text(jump_step * 0.1 + 0.15, ax.get_ylim()[1] * 0.85 if ax.get_ylim()[1] > 0 else 25,
            'sudden target\noffset injected', fontsize=7.5)
    ax.axhline(5.5, color='gray', ls=':', lw=1)
    ax.set_xlabel('time (s)'); ax.set_ylabel('true feature RMSE (px)')
    ax.set_title('Recovery from a sudden 5 cm / -4 cm target offset\n(fixed-horizon rollout; injected at $t=4.0$s)', fontsize=9.5)
    ax.legend(fontsize=7.6, loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=2)
    fig.subplots_adjust(bottom=0.32)
    fig.savefig(f'{FIGS}/fig20_disturbance_recovery.pdf')
    plt.close(fig)


# ============================================================ 21
def fig_failure_cases():
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 3.8))
    fails = extra2['failures']

    ax = axes[0]
    for name, key, col in [('DCUG-PPO', 'long_dropout_dcug', C['dcug_full']),
                             (r'Classical + $\alpha\beta$', 'long_dropout_ekf', C['ekf_fallback'])]:
        tr = fails[key]['traj']
        t = np.arange(len(tr)) * 0.1
        rmse = [s['rmse'] for s in tr]
        vis = [s['visible'] for s in tr]
        ax.plot(t, rmse, color=col, lw=1.6, label=name)
    ax.set_yscale('log'); ax.axhline(5.5, color='gray', ls=':', lw=1)
    ax.set_xlabel('time (s)'); ax.set_ylabel('true feature RMSE (px)')
    ax.set_title('(a) Extreme dropout\n($p_{lose}{=}0.5$, $p_{recover}{=}0.02$):\nboth controllers eventually lose the target', fontsize=8.5)
    ax.legend(fontsize=7, loc='upper center', bbox_to_anchor=(0.5, -0.22), ncol=1)

    ax = axes[1]
    tr = fails['target_loss_no_fallback']['traj']
    t = np.arange(len(tr)) * 0.1
    rmse = [s['rmse'] for s in tr]
    ax.plot(t, rmse, color=C['no_fallback'], lw=1.8)
    ax.axhline(5.5, color='gray', ls=':', lw=1)
    ax.set_yscale('log')
    ax.set_xlabel('time (s)'); ax.set_ylabel('true feature RMSE (px)')
    ax.set_title('(b) Classical no-fallback,\ntarget-loss failure\n(zero-order hold drifts off-target\nduring a dropout interval)', fontsize=8.5)

    ax = axes[2]
    tr = fails['collapsed_seed_single_critic']['traj']
    t = np.arange(len(tr)) * 0.1
    rmse = [s['rmse'] for s in tr]
    ax.plot(t, rmse, color=C['single_critic'], lw=1.8)
    ax.axhline(5.5, color='gray', ls=':', lw=1)
    ax.set_yscale('log')
    ax.set_xlabel('time (s)'); ax.set_ylabel('true feature RMSE (px)')
    ax.set_title('(c) Single-critic PPO,\ncollapsed-seed failure\n(the seed-1 policy drives the\ntarget out of frame immediately)', fontsize=8.5)

    fig.subplots_adjust(bottom=0.32, wspace=0.35)
    fig.savefig(f'{FIGS}/fig21_failure_cases.pdf')
    plt.close(fig)


# ============================================================ 22
def fig_mujoco_transfer():
    fig, ax = plt.subplots(figsize=(7.4, 4.0))
    diffs = ['mild', 'moderate', 'severe']
    names = ['no_fallback', 'ekf_fallback', 'single_critic', 'dcug_full']
    x = np.arange(len(diffs))
    width = 0.19
    for i, name in enumerate(names):
        means, stds = [], []
        for d in diffs:
            if name == 'no_fallback':
                means.append(mj[d]['classical_no_fallback']); stds.append(0)
            elif name == 'ekf_fallback':
                means.append(mj[d]['classical_ekf_fallback']); stds.append(0)
            else:
                arr = [e['success_rate'] for e in mj[d][name]]
                means.append(np.mean(arr)); stds.append(np.std(arr))
        ax.bar(x + (i - 1.5) * width, means, width=width, yerr=stds, color=C[name],
               label=LABEL[name], capsize=2.5, edgecolor='k', linewidth=0.4)
    ax.set_xticks(x); ax.set_xticklabels(diffs)
    ax.set_ylabel('success rate (MuJoCo dynamics, zero-shot)')
    ax.set_title('Zero-shot transfer to MuJoCo rigid-body dynamics\n(policies trained only in the kinematic simulator; no fine-tuning)', fontsize=10)
    ax.legend(fontsize=7.6, loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=2)
    fig.subplots_adjust(bottom=0.34)
    fig.savefig(f'{FIGS}/fig22_mujoco_transfer.pdf')
    plt.close(fig)


if __name__ == '__main__':
    fig_system_schematic()
    fig_dropout_process()
    fig_architecture()
    fig_training_curves()
    fig_seed_reliability()
    fig_qualitative_trajectory()
    fig_rmse_and_gate()
    fig_success_lost_vs_severity()
    fig_heatmaps()
    fig_ablation()
    fig_convergence_time()
    fig_control_effort()
    fig_distance_sensitivity()
    fig_timing()
    fig_summary_radar()
    fig_sample_efficiency()
    fig_noise_robustness()
    fig_computational_scaling()
    fig_action_smoothness()
    fig_disturbance_recovery()
    fig_failure_cases()
    fig_mujoco_transfer()
    print('ALL FIGURES DONE')
