import json, time
import numpy as np
import torch

from env import IBVSDropoutEnv, Z_DESIRED
from train import make_env
from ppo import Agent
from controllers import (run_classical_no_fallback, run_classical_ekf_fallback,
                          fallback_action, classical_ibvs_action)
from run_experiments import load_agent, RESULTS

OUT = {}

# ---------------------------------------------------------------
# 1) Matched-seed qualitative comparison: same env/episode conditions,
#    4 controllers, record full trajectories (true pose, rmse, alpha).
# ---------------------------------------------------------------
def record_classical(env, mode, seed_reset_kwargs=None):
    obs, _ = env.reset(**(seed_reset_kwargs or {}))
    done = False
    traj = []
    last_action = np.zeros(4)
    while not done:
        if mode == 'no_fallback':
            if env.channel.visible:
                last_action = classical_ibvs_action(env.pose, env.s_star)
            action = last_action
        else:  # ekf_fallback
            action = classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred)
        obs, rew, done, info = env.step(action)
        traj.append(dict(rmse=info['rmse_true'], visible=info['visible'], pose=info['pose'].tolist(),
                          action=action.tolist(), success=info['success']))
    return traj


def record_agent(env, agent, seed_reset_kwargs=None):
    obs, _ = env.reset(**(seed_reset_kwargs or {}))
    done = False
    traj = []
    while not done:
        a_safe = fallback_action(env) if agent.dual else np.zeros(4, dtype=np.float32)
        act, logp, vopt, vpess, alpha = agent.act(obs, a_safe_np=a_safe, sample=False)
        obs, rew, done, info = env.step(act)
        traj.append(dict(rmse=info['rmse_true'], visible=info['visible'], pose=info['pose'].tolist(),
                          action=act.tolist(), alpha=float(alpha)))
    return traj


MATCH_SEED = 42
env = make_env(seed=MATCH_SEED, difficulty='severe')
dcug_agent = load_agent('dcug_full', 1, dual=True)
sc_agent = load_agent('single_critic', 2, dual=False)  # use a non-collapsed seed for fair qualitative viz

# re-seed env identically before each controller so initial pose + dropout realization line up
def fresh_env():
    return make_env(seed=MATCH_SEED, difficulty='severe')

traj_no_fb = record_classical(fresh_env(), 'no_fallback')
traj_ekf = record_classical(fresh_env(), 'ekf_fallback')
traj_sc = record_agent(fresh_env(), sc_agent)
traj_dcug = record_agent(fresh_env(), dcug_agent)

OUT['qualitative'] = dict(no_fallback=traj_no_fb, ekf_fallback=traj_ekf,
                           single_critic=traj_sc, dcug_full=traj_dcug, seed=MATCH_SEED)
print('qualitative lengths:', len(traj_no_fb), len(traj_ekf), len(traj_sc), len(traj_dcug))

# ---------------------------------------------------------------
# 2) 2D dropout-severity robustness heatmap (p_lose x p_recover) for DCUG-PPO vs EKF-fallback
# ---------------------------------------------------------------
p_lose_grid = [0.03, 0.06, 0.09, 0.12, 0.16, 0.20]
p_recover_grid = [0.35, 0.25, 0.18, 0.12, 0.08]
N_EVAL = 60

heat_dcug = np.zeros((len(p_recover_grid), len(p_lose_grid)))
heat_ekf = np.zeros((len(p_recover_grid), len(p_lose_grid)))
for i, pr in enumerate(p_recover_grid):
    for j, pl in enumerate(p_lose_grid):
        env = IBVSDropoutEnv(p_lose=pl, p_recover=pr, seed=123)
        s_d = s_e = 0
        for k in range(N_EVAL):
            obs, _ = env.reset()
            done = False
            while not done:
                a_safe = fallback_action(env)
                act, *_ = dcug_agent.act(obs, a_safe_np=a_safe, sample=False)
                obs, rew, done, info = env.step(act)
            s_d += info['success']
            t = run_classical_ekf_fallback(env, dict())
            s_e += t[-1]['success']
        heat_dcug[i, j] = s_d / N_EVAL
        heat_ekf[i, j] = s_e / N_EVAL
    print('row done', i)

OUT['heatmap'] = dict(p_lose_grid=p_lose_grid, p_recover_grid=p_recover_grid,
                       dcug=heat_dcug.tolist(), ekf=heat_ekf.tolist())

# ---------------------------------------------------------------
# 3) Sensitivity to initial-pose difficulty scale (near/med/far)
# ---------------------------------------------------------------
scale_results = {}
for scale_name, scale in [('near', 0.5), ('medium', 1.0), ('far', 1.6)]:
    env = make_env(seed=55, difficulty='moderate')
    res = {}
    for cname, ctrl in [('no_fallback', 'classical_nf'), ('ekf_fallback', 'classical_ekf')]:
        succ = 0
        for k in range(80):
            if ctrl == 'classical_nf':
                t = record_classical(env, 'no_fallback', dict(difficulty=scale))
            else:
                t = record_classical(env, 'ekf_fallback', dict(difficulty=scale))
            succ += t[-1]['success']
        res[cname] = succ / 80
    for cname, agent in [('single_critic', sc_agent), ('dcug_full', dcug_agent)]:
        succ = 0
        for k in range(80):
            obs, _ = env.reset(difficulty=scale)
            done = False
            while not done:
                a_safe = fallback_action(env) if agent.dual else np.zeros(4, dtype=np.float32)
                act, *_ = agent.act(obs, a_safe_np=a_safe, sample=False)
                obs, rew, done, info = env.step(act)
            succ += info['success']
        res[cname] = succ / 80
    scale_results[scale_name] = res
    print(scale_name, res)

OUT['distance_sensitivity'] = scale_results

# ---------------------------------------------------------------
# 4) Convergence-time (steps to first sustained success) + control effort,  moderate difficulty
# ---------------------------------------------------------------
def conv_time_and_effort(traj):
    rmses = [s['rmse'] for s in traj]
    conv = None
    hold = 0
    for i, r in enumerate(rmses):
        if r < 5.5:
            hold += 1
            if hold >= 8:
                conv = i - 7
                break
        else:
            hold = 0
    effort = float(np.mean([np.sum(np.array(s['action']) ** 2) for s in traj]))
    jerk = float(np.mean([np.sum((np.array(traj[i]['action']) - np.array(traj[i-1]['action'])) ** 2)
                           for i in range(1, len(traj))])) if len(traj) > 1 else 0.0
    return conv, effort, jerk

conv_data = {'no_fallback': [], 'ekf_fallback': [], 'single_critic': [], 'dcug_full': []}
effort_data = {k: [] for k in conv_data}
jerk_data = {k: [] for k in conv_data}
env = make_env(seed=77, difficulty='moderate')
for k in range(120):
    t1 = record_classical(env, 'no_fallback')
    t2 = record_classical(env, 'ekf_fallback')
    t3 = record_agent(env, sc_agent)
    t4 = record_agent(env, dcug_agent)
    for name, tr in [('no_fallback', t1), ('ekf_fallback', t2), ('single_critic', t3), ('dcug_full', t4)]:
        c, e, j = conv_time_and_effort(tr)
        if c is not None:
            conv_data[name].append(c)
        effort_data[name].append(e)
        jerk_data[name].append(j)

OUT['convergence'] = conv_data
OUT['effort'] = effort_data
OUT['jerk'] = jerk_data
print('convergence sample sizes:', {k: len(v) for k, v in conv_data.items()})

# ---------------------------------------------------------------
# 5) Inference wall-clock time per control step
# ---------------------------------------------------------------
env = make_env(seed=99, difficulty='moderate')
obs, _ = env.reset()
N_T = 500
t0 = time.time()
for _ in range(N_T):
    _ = classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred)
t_classical = (time.time() - t0) / N_T * 1000

t0 = time.time()
for _ in range(N_T):
    a_safe = fallback_action(env)
    _ = dcug_agent.act(obs, a_safe_np=a_safe, sample=False)
t_dcug = (time.time() - t0) / N_T * 1000

t0 = time.time()
for _ in range(N_T):
    _ = sc_agent.act(obs, a_safe_np=np.zeros(4, dtype=np.float32), sample=False)
t_sc = (time.time() - t0) / N_T * 1000

OUT['timing_ms'] = dict(classical=t_classical, single_critic=t_sc, dcug_full=t_dcug)
print('timing (ms/step):', OUT['timing_ms'])

with open(f'{RESULTS}/extra_data.json', 'w') as f:
    json.dump(OUT, f)
print('SAVED extra_data.json')
