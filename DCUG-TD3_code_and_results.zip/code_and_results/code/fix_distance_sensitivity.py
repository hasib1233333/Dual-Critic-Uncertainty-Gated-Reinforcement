import json
import numpy as np
from train import make_env
from run_experiments import load_agent, MODELS, RESULTS
from controllers import classical_ibvs_action, fallback_action

sc_agent = load_agent('single_critic', 2, dual=False)
dcug_agent = load_agent('dcug_full', 1, dual=True)


def record_classical(env, mode, seed_reset_kwargs=None):
    obs, _ = env.reset(**(seed_reset_kwargs or {}))
    done = False
    traj = []
    last_action = np.zeros(4)
    while not done:
        if mode == 'no_fallback':
            if env.channel.visible:
                last_action = classical_ibvs_action(env.pose, env.s_star)
            action = last_action
        else:
            action = classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred)
        obs, rew, done, info = env.step(action)
        traj.append(dict(rmse=info['rmse_true'], visible=info['visible'],
                          success=info['success']))
    return traj


scale_results = {}
for scale_name, scale in [('near', 0.5), ('medium', 1.0), ('far', 1.6)]:
    env = make_env(seed=55, difficulty='moderate')
    res = {}
    for cname, ctrl in [('no_fallback', 'classical_nf'), ('ekf_fallback', 'classical_ekf')]:
        succ = 0
        for k in range(80):
            if ctrl == 'classical_nf':
                t = record_classical(env, 'no_fallback', dict(difficulty=scale))
            else:
                t = record_classical(env, 'ekf_fallback', dict(difficulty=scale))
            succ += t[-1]['success']
        res[cname] = succ / 80
    for cname, agent in [('single_critic', sc_agent), ('dcug_full', dcug_agent)]:
        succ = 0
        for k in range(80):
            obs, _ = env.reset(difficulty=scale)
            done = False
            while not done:
                a_safe = fallback_action(env) if agent.dual else np.zeros(4, dtype=np.float32)
                act, *_ = agent.act(obs, a_safe_np=a_safe, sample=False)
                obs, rew, done, info = env.step(act)
            succ += info['success']
        res[cname] = succ / 80
    scale_results[scale_name] = res
    print(scale_name, res, flush=True)

with open(f'{RESULTS}/distance_sensitivity_fixed.json', 'w') as f:
    json.dump(scale_results, f, indent=2)
print('SAVED')
