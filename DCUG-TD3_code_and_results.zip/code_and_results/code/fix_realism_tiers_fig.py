import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.size': 10, 'font.family': 'serif',
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': True, 'grid.alpha': 0.25, 'grid.linestyle': ':',
    'figure.dpi': 140, 'savefig.bbox': 'tight',
})

C = dict(ekf_fallback='#4C72B0', single_critic='#DD8452', dcug_full='#55A868')
LABEL = {'ekf_fallback': r'Classical IBVS + $\alpha\beta$ fallback',
         'single_critic': 'Single-critic PPO', 'dcug_full': 'DCUG-PPO (proposed)'}

RES = '/home/claude/project/results'
ev = json.load(open(f'{RES}/eval_results.json'))
mj = json.load(open(f'{RES}/mujoco_transfer.json'))
real = json.load(open(f'{RES}/realimage_transfer.json'))

tiers = ['Tier 1\n(kinematic,\nanalytic)', 'Tier 2\n(MuJoCo,\nanalytic)', 'Tier 3\n(MuJoCo,\nrendered)']
names = ['ekf_fallback', 'single_critic', 'dcug_full']

means = {n: [] for n in names}
stds = {n: [] for n in names}

# tier 1: kinematic, moderate preset
means['ekf_fallback'].append(ev['moderate']['classical_ekf_fallback']['success_rate']); stds['ekf_fallback'].append(0.0)
for n in ['single_critic', 'dcug_full']:
    vals = [x['success_rate'] for x in ev['moderate'][n]]
    means[n].append(np.mean(vals)); stds[n].append(np.std(vals, ddof=1))

# tier 2: mujoco, moderate preset
means['ekf_fallback'].append(mj['moderate']['classical_ekf_fallback']); stds['ekf_fallback'].append(0.0)
for n in ['single_critic', 'dcug_full']:
    vals = [x['success_rate'] for x in mj['moderate'][n]]
    means[n].append(np.mean(vals)); stds[n].append(np.std(vals, ddof=1))

# tier 3: real-image, 5-seed subset
means['ekf_fallback'].append(real['classical_ekf_fallback']['success_rate']); stds['ekf_fallback'].append(0.0)
for n in ['single_critic', 'dcug_full']:
    vals = [x['success_rate'] for x in real[n]]
    means[n].append(np.mean(vals)); stds[n].append(np.std(vals, ddof=1))

fig, ax = plt.subplots(figsize=(7.0, 4.0))
x = np.arange(len(tiers))
width = 0.24
for i, n in enumerate(names):
    ax.bar(x + (i - 1) * width, [m * 100 for m in means[n]], yerr=[s * 100 for s in stds[n]],
           width=width, color=C[n], label=LABEL[n], edgecolor='k', linewidth=0.5, capsize=3)
ax.set_xticks(x)
ax.set_xticklabels(tiers, fontsize=8.5)
ax.set_ylabel('success rate (%)')
ax.set_title('Success rate (moderate dropout) across three fidelity tiers')
ax.legend(fontsize=7.8, loc='upper center', bbox_to_anchor=(0.5, -0.22), ncol=1)
ax.set_ylim(0, 110)
fig.subplots_adjust(bottom=0.34)
fig.savefig('/home/claude/project/paper/fig23_realism_tiers.pdf')
print('saved')
for n in names:
    print(n, [f'{m*100:.1f}' for m in means[n]])
