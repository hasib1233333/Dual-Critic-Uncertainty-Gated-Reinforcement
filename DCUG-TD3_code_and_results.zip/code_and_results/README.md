# DCUG-PPO / DCUG-TD3: Code and Results

Public mirror: https://github.com/hasib1233333/Dual-Critic-Uncertainty-Gated-Reinforcement.git

Covers the main paper ("Dual-Critic Uncertainty-Gated Reinforcement Learning for
Vision-Dropout-Robust Image-Based Visual Servoing", submitted to Discover Robotics)
and its extension paper ("Does Fallback-Anchored Uncertainty Gating Help Off-Policy
Reinforcement Learning?").

## Fixes made during the major-revision round (this archive reflects the corrected state)

Two independent reviewers verified the manuscript's numbers against an earlier version
of this code and found several real bugs, all fixed here:

- **`gather_extra.py`**: the distance-sensitivity sweep scored the two classical
  controllers on a final-step-only RMSE check while the learned controllers used the
  true 8-consecutive-step success criterion. Fixed to use the same criterion for all
  four controllers (`record_classical` now returns the environment's real `success`
  flag). See `fix_distance_sensitivity.py` for the corrected re-run.
- **`mujoco_realimage_env.py`**: added a `strict_detection_termination` flag. The
  original behavior (any single missed detection ends the episode as an unrecoverable
  loss) is preserved as the default; setting it `False` treats a failed detection as a
  recoverable dropout event instead. See `tier3_termination_check.py` for a comparison
  of both definitions.
- **`figs.py`**: (a) three hardcoded "5 seeds" labels left over from before the
  PPO-family seed count was doubled to ten, now say "10 seeds"; (b) the `LABEL` dict and
  three other hardcoded strings called the fallback estimator "EKF" — it is not a
  Kalman filter (see `env.py`: raw pass-through position estimate, fixed 0.7/0.3
  exponential velocity smoothing, hand-coded covariance ramp) — now say
  "$\alpha\beta$ fallback" throughout; (c) all TD3 comparisons now explicitly slice to
  the first 3 seeds of `eval_td3.json` (see note below on why that file has more than 3).
- **`fix_realism_tiers_fig.py`**: the original three-fidelity-tier bar chart's
  generating script was lost from an earlier archive; this rebuilds it from
  `eval_results.json` + `mujoco_transfer.json` + `realimage_transfer.json`, reproducing
  the exact numbers already reported in the paper (68.0/66.0/63.3 for the classical
  baseline; 91.4/88.9/72.0 for DCUG-PPO; 83.1/82.5/58.0 for single-critic PPO).

None of these fixes required retraining except one: `record_classical`'s consistent
success criterion needed re-evaluating the distance-sensitivity sweep on trained
policies, so `dcug_full` seed 1 and `single_critic` seed 2 were retrained (included in
`models/`) specifically to regenerate that one figure. The corrected numbers changed by
at most 2.5 percentage points, confined to the classical baseline's bars.

**Note on `eval_td3.json`**: this file contains 10 seeds' worth of TD3 evaluations, not
3. The main paper's TD3 comparisons (Table 5, the abstract, `sec:td3`) were run and
verified against only the *first 3* seeds in this file, matching the paper's stated
"TD3: 3 seeds" — the extra 7 seeds were added later for the extension paper's
matched-power comparison against DCUG-TD3. Every script in this archive that touches
`eval_td3.json` for a main-paper figure now explicitly slices to `[:3]`.

## Contents

### Core environment and PPO/DCUG-PPO (main paper)
- `code/env.py` — IBVS-under-dropout kinematic simulation environment
- `code/controllers.py` — classical IBVS, $\alpha\beta$-filter-fallback, and DCUG-PPO fallback-action controllers
- `code/ppo.py` — PPO implementation with optional dual-critic / uncertainty-gated (DCUG) actor
- `code/train.py`, `code/train_one.py` — PPO training loops
- `code/run_experiments.py` — full evaluation sweeps
- `code/gather_extra.py` — qualitative trajectories, dropout-parameter heatmap, distance sensitivity (fixed scoring, see above), timing
- `code/gather_extra2.py` — noise-robustness sweep, computational-scaling benchmark, disturbance-rejection test, failure-case mining
- `code/figs.py` — regenerates all 22 main-paper figures (fixed labels, see above)
- `code/fix_distance_sensitivity.py` — standalone re-run of the corrected distance-sensitivity sweep
- `code/fix_realism_tiers_fig.py` — standalone rebuild of the three-fidelity-tier figure
- `code/tier3_termination_check.py` — strict vs. lenient detection-termination comparison

### Cross-simulator validation
- `code/mujoco_env.py` — MuJoCo rigid-body environment
- `code/mujoco_eval.py`, `code/mujoco_eval_extend.py` — zero-shot MuJoCo evaluation
- `code/mujoco_realimage_env.py` — MuJoCo + real offscreen rendering + OpenCV feature detection (fixed termination logic, see above)
- `code/realimage_eval.py` — zero-shot evaluation in the rendered-image environment

### TD3 baseline and DCUG-TD3 (extension paper)
- `code/td3.py`, `code/train_td3.py`, `code/train_td3_one.py`, `code/eval_td3.py`
- `code/dcug_td3.py`, `code/train_dcug_td3.py`, `code/train_dcug_td3_one.py`, `code/train_dcug_td3_variant.py`, `code/eval_dcug_td3.py`
- `code/generate_stats_figures.py` — extension-paper forest plot and ablation chart
- `code/ieee_style.py` — shared matplotlib styling

## Results
All raw per-seed training histories, per-episode evaluation arrays, and derived
statistics underlying every figure and table in both papers. See filenames for
correspondence (`eval_*.json` = deterministic evaluation, `train_*.json` = training
history, `extra_data*.json` = secondary/robustness analyses).

## Models
`models/` contains two retrained checkpoints (`dcug_full_seed1.pt`,
`single_critic_seed2.pt`) used to regenerate the distance-sensitivity figure with
corrected scoring. Full model weights for all ten main seeds are not included in this
archive; retrain via `train_one.py` with the corresponding seed argument if needed.

## Known scope limits
See both papers' Discussion, Limitations, and the point-by-point response to reviewers
for a full account of open questions: no physical-robot validation, no SAC/PPO-LSTM/
Dreamer/distributional-RL baselines, ablation configurations underpowered at 2 seeds
each, and the gate's asymptotic-performance contribution not established over a fixed
blend (narrowed explicitly in the revised manuscript per reviewer feedback).
