# DCUG-PPO / DCUG-TD3: Code and Results

Public mirror: https://github.com/hasib1233333/Dual-Critic-Uncertainty-Gated-Reinforcement.git

This archive covers both the main paper ("Dual-Critic Uncertainty-Gated Reinforcement Learning for
Vision-Dropout-Robust Image-Based Visual Servoing") and its extension ("Does Fallback-Anchored
Uncertainty Gating Help Off-Policy Reinforcement Learning?").

## Contents

### Core environment and PPO/DCUG-PPO (main paper)
- `code/env.py` — IBVS-under-dropout kinematic simulation environment (Jacobian, dropout channel, target drift)
- `code/controllers.py` — classical IBVS, EKF-fallback, and DCUG-PPO fallback-action controllers
- `code/ppo.py` — PPO implementation with optional dual-critic / uncertainty-gated (DCUG) actor
- `code/train.py`, `code/train_one.py` — PPO training loops (single-seed CLI variant for chunked/resumable runs)
- `code/run_experiments.py` — full evaluation sweeps (severity presets, ablations, statistical raw data)
- `code/gather_extra.py` — qualitative trajectories, 2-D dropout-parameter heatmap, distance sensitivity, timing
- `code/gather_extra2.py` — noise-robustness sweep, computational-scaling benchmark, disturbance-rejection test,
  failure-case mining (all reuse already-trained models, no retraining)
- `code/figs.py` — regenerates the main paper's 22 figures from the JSON results

### Cross-simulator validation (main paper, Sec. 6.9-6.10)
- `code/mujoco_env.py` — MuJoCo environment: real rigid-body dynamics in place of the kinematic integrator
- `code/mujoco_eval.py`, `code/mujoco_eval_extend.py` — zero-shot MuJoCo evaluation (all 10 seeds)
- `code/mujoco_realimage_env.py` — MuJoCo + real offscreen rendering + OpenCV color-blob feature detection
- `code/realimage_eval.py` — zero-shot evaluation in the rendered-image environment

### TD3 baseline (main paper Sec. 6.8; extension paper throughout)
- `code/td3.py` — TD3 implementation (twin critics, delayed updates, target policy smoothing, replay buffer)
- `code/train_td3.py` — TD3 training loop
- `code/train_td3_one.py` — checkpointed/resumable single-seed TD3 trainer (all 10 seeds trained with this)
- `code/eval_td3.py` — deterministic TD3 evaluation across severity presets. TD3 was originally reported with
  3 seeds; retrained to 10 seeds (matching DCUG-TD3's power) in response to reviewer feedback — see
  `results/train_td3_seed{1..10}.json` and `results/eval_td3.json`.

### DCUG-TD3 (extension paper)
- `code/dcug_td3.py` — DCUG-TD3: fallback-anchored, uncertainty-gated TD3 (gate + expectile pessimistic critic),
  including the gated replay buffer that stores the *real* fallback action for both current and next state
- `code/train_dcug_td3.py` — DCUG-TD3 training loop (also logs gate value alpha per episode for Fig. 7)
- `code/train_dcug_td3_one.py` — checkpointed/resumable single-seed DCUG-TD3 trainer (main 10 seeds)
- `code/train_dcug_td3_variant.py` — trains the alpha-tracking seeds (101-103) and the two ablation configs
  (fixed alpha=0.5, gate-without-delta-Q)
- `code/eval_dcug_td3.py` — deterministic DCUG-TD3 evaluation across severity presets, all 10 seeds
- `code/generate_stats_figures.py` — forest plot (mean-difference 95% CI) and ablation bar chart

### Shared
- `code/ieee_style.py` — shared matplotlib IEEE-style config (colors, fonts, line widths) for extension-paper figures

## Results
- `results/train_dcug_full.json`, `results/train_single_critic.json` — main-paper PPO training curves (10 seeds each)
- `results/train_abl_fixed_alpha.json`, `results/train_abl_no_vdiff.json` — main-paper PPO ablation curves (2 seeds)
- `results/train_td3_seed{1..10}.json` — vanilla TD3 training curves, all 10 seeds
- `results/train_dcug_td3_seed{1..10}.json` — DCUG-TD3 training curves, all 10 seeds
- `results/train_dcug_td3_alpha_seed{101,102,103}.json` — alpha-tracking seeds (Fig. 7 of extension paper)
- `results/train_abl_fixed05_seed{1,2}.json`, `results/train_abl_noqdiff_seed{1,2}.json` — DCUG-TD3 ablation curves
- `results/eval_results.json` — main-paper deterministic evaluation (PPO-family), raw per-episode success arrays
- `results/eval_td3.json` — TD3 deterministic evaluation, all 10 seeds, all severities
- `results/eval_dcug_td3.json` — DCUG-TD3 deterministic evaluation, all 10 seeds, all severities
- `results/dcug_td3_ablations.json` — DCUG-TD3 ablation deterministic evaluation
- `results/dcug_td3_effort_timing.json`, `results/td3_effort_timing.json` — control effort/jerk/inference timing
- `results/training_time_comparison.json` — controlled, identical-hardware TD3 vs. DCUG-TD3 training-time comparison
- `results/mujoco_transfer.json`, `results/realimage_transfer.json` — cross-simulator validation results
- `results/extra_data.json`, `results/extra_data2.json` — qualitative traces, heatmap, sensitivity sweeps,
  disturbance-rejection trajectories, failure-case trajectories, computational scaling

## Reproducing
Trained model weights are not included in this archive (see the public GitHub repo, or retrain via
`train_one.py`, `train_td3_one.py`, `train_dcug_td3_one.py`, `train_dcug_td3_variant.py`). Requires numpy,
scipy, torch (CPU is sufficient), matplotlib, mujoco (`pip install mujoco`), and opencv-python.

## Known scope limits (see both papers' Discussion and Limitations sections)
- No SAC / PPO-LSTM / DreamerV3 / distributional-RL baselines beyond TD3.
- No formal hyperparameter (expectile tau, fallback gain kappa) sensitivity sweep.
- No Gazebo / Isaac Sim / PyBullet replication (PyBullet's from-source build did not complete within this
  environment's per-call time limits; MuJoCo was used instead as it ships prebuilt wheels).
- No physical-robot validation.
- The extension paper's ablation configurations (fixed-alpha, gate-without-delta-Q) use only 2 seeds each
  (800-episode budget), smaller than the main 10-seed/1200-episode runs, and are flagged as correspondingly
  less statistically powered in the paper text.
