import json, time
import numpy as np
import torch

from env import IBVSDropoutEnv
from train import make_env
from run_experiments import load_agent, RESULTS
from controllers import fallback_action, run_classical_ekf_fallback, run_classical_no_fallback
from ppo import Actor, Critic, Agent

OUT = {}
dcug_agent = load_agent('dcug_full', 1, dual=True)
sc_agent = load_agent('single_critic', 2, dual=False)

# ---------------------------------------------------------------
# Priority 3: Gaussian pixel-noise robustness sweep (no retraining;
# existing trained models evaluated at noise levels beyond training sigma=0.5px)
# ---------------------------------------------------------------
noise_levels = [0.0, 0.5, 1.0, 2.0, 3.0, 4.0]
noise_results = {'single_critic': [], 'dcug_full': [], 'ekf_fallback': []}
N_EVAL = 100
for sigma in noise_levels:
    env = IBVSDropoutEnv(p_lose=0.08, p_recover=0.18, seed=321, pixel_noise_std=sigma)
    s_d = s_s = s_e = 0
    for k in range(N_EVAL):
        obs, _ = env.reset()
        done = False
        while not done:
            a_safe = fallback_action(env)
            act, *_ = dcug_agent.act(obs, a_safe_np=a_safe, sample=False)
            obs, rew, done, info = env.step(act)
        s_d += info['success']
        obs, _ = env.reset()
        done = False
        while not done:
            act, *_ = sc_agent.act(obs, a_safe_np=np.zeros(4, dtype=np.float32), sample=False)
            obs, rew, done, info = env.step(act)
        s_s += info['success']
        t = run_classical_ekf_fallback(env, dict())
        s_e += t[-1]['success']
    noise_results['dcug_full'].append(s_d / N_EVAL)
    noise_results['single_critic'].append(s_s / N_EVAL)
    noise_results['ekf_fallback'].append(s_e / N_EVAL)
    print('noise', sigma, 'dcug', s_d / N_EVAL, 'sc', s_s / N_EVAL, 'ekf', s_e / N_EVAL)
OUT['noise_robustness'] = dict(noise_levels=noise_levels, **noise_results)

# ---------------------------------------------------------------
# Priority 8: Computational scaling with network width (timing only;
# does not require trained weights since matmul cost is weight-independent)
# ---------------------------------------------------------------
env = make_env(seed=1, difficulty='moderate')
obs, _ = env.reset()
obs_dim, act_dim = env.obs_dim, env.act_dim
scaling = {}
N_T = 800
for hidden in [16, 32, 64, 128, 256]:
    actor = Actor(obs_dim, act_dim, hidden=hidden, dual=True)
    v_opt = Critic(obs_dim, hidden=hidden)
    v_pess = Critic(obs_dim, hidden=hidden)
    obs_t = torch.as_tensor(obs, dtype=torch.float32).unsqueeze(0)
    a_safe_t = torch.zeros(1, 4)
    with torch.no_grad():
        t0 = time.time()
        for _ in range(N_T):
            vo = v_opt(obs_t); vp = v_pess(obs_t)
            vdiff = (vo - vp).detach()
            mu, std, alpha = actor(obs_t, a_safe=a_safe_t, v_diff=vdiff)
        dt = (time.time() - t0) / N_T * 1000
    n_params = sum(p.numel() for p in actor.parameters()) + sum(p.numel() for p in v_opt.parameters()) + sum(p.numel() for p in v_pess.parameters())
    scaling[hidden] = dict(runtime_ms=dt, n_params=n_params)
    print('hidden', hidden, 'runtime_ms', dt, 'params', n_params)
OUT['computational_scaling'] = scaling

# ---------------------------------------------------------------
# Priority 9 support data: action time series (vx,vy,vz,wz) already
# present per-step in extra_data.json qualitative trajectories -- no
# new experiment needed, just flagging which keys to use downstream.
# ---------------------------------------------------------------

# ---------------------------------------------------------------
# Priority 4: Disturbance rejection -- inject a sudden target jump
# mid-episode (simulating e.g. the object being bumped) and record
# recovery trajectories for classical-EKF, single-critic, and DCUG-PPO.
# ---------------------------------------------------------------
def run_with_disturbance(agent_or_none, mode, seed, jump=(0.05, -0.04), jump_step=40, horizon=90):
    """Runs a FIXED horizon (ignoring the environment's own success/lost early
    termination) so that every controller actually experiences the injected
    disturbance at jump_step, regardless of how quickly it would otherwise
    have converged and ended the episode. Used only for this qualitative
    recovery-trajectory visualization, not for any success-rate statistic."""
    env = make_env(seed=seed, difficulty='moderate')
    obs, _ = env.reset()
    traj = []
    for t in range(horizon):
        if t == jump_step:
            env.target_xy = env.target_xy + np.array(jump)
        if mode == 'ekf':
            from controllers import classical_ibvs_action
            action = classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred)
        else:
            a_safe = fallback_action(env) if agent_or_none.dual else np.zeros(4, dtype=np.float32)
            action, *_ = agent_or_none.act(obs, a_safe_np=a_safe, sample=False)
        obs, rew, done, info = env.step(action)
        traj.append(dict(rmse=info['rmse_true'], pose=info['pose'].tolist(), target_xy=env.target_xy.tolist()))
        env._success_streak = 0  # force-disable early success termination for this visualization
    return traj

DIST_SEED = 17
OUT['disturbance'] = dict(
    ekf_fallback=run_with_disturbance(None, 'ekf', DIST_SEED),
    single_critic=run_with_disturbance(sc_agent, 'rl', DIST_SEED),
    dcug_full=run_with_disturbance(dcug_agent, 'rl', DIST_SEED),
    jump_step=40,
)
print('disturbance episode lengths:', {k: len(v) for k, v in OUT['disturbance'].items() if isinstance(v, list)})

# ---------------------------------------------------------------
# Priority 7: mine representative failure cases from fresh rollouts
# ---------------------------------------------------------------
failures = {}

# (a) extremely long dropout: force a long forced dropout window and record classical-EKF and DCUG-PPO
env = IBVSDropoutEnv(p_lose=0.5, p_recover=0.02, seed=555)  # engineered to produce very long dropouts
obs, _ = env.reset()
done = False
traj = []
while not done:
    a_safe = fallback_action(env)
    act, *_ = dcug_agent.act(obs, a_safe_np=a_safe, sample=False)
    obs, rew, done, info = env.step(act)
    traj.append(dict(rmse=info['rmse_true'], visible=info['visible']))
failures['long_dropout_dcug'] = dict(traj=traj, final_success=bool(info['success']), final_lost=bool(info['lost']))

env = IBVSDropoutEnv(p_lose=0.5, p_recover=0.02, seed=555)
t2 = run_classical_ekf_fallback(env, dict())
failures['long_dropout_ekf'] = dict(traj=[dict(rmse=s['rmse_true'], visible=s['visible']) for s in t2],
                                     final_success=bool(t2[-1]['success']), final_lost=bool(t2[-1]['lost']))

# (b) complete target loss: classical no-fallback under severe dropout + drift, pick a lost episode
env = make_env(seed=42, difficulty='severe')
found = None
for sd in range(50):
    env2 = make_env(seed=sd + 1000, difficulty='severe')
    t3 = run_classical_no_fallback(env2, dict())
    if t3[-1]['lost']:
        found = [dict(rmse=s['rmse_true'], visible=s['visible']) for s in t3]
        break
failures['target_loss_no_fallback'] = dict(traj=found, seed_used=sd + 1000 if found else None)

# (c) single-critic collapsed-seed behaviour (seed 1, known collapse)
collapsed_agent = load_agent('single_critic', 1, dual=False)
env = make_env(seed=42, difficulty='moderate')
obs, _ = env.reset()
done = False
traj = []
while not done:
    act, *_ = collapsed_agent.act(obs, a_safe_np=np.zeros(4, dtype=np.float32), sample=False)
    obs, rew, done, info = env.step(act)
    traj.append(dict(rmse=info['rmse_true'], visible=info['visible'], pose=info['pose'].tolist()))
failures['collapsed_seed_single_critic'] = dict(traj=traj, final_success=bool(info['success']), final_lost=bool(info['lost']))

OUT['failures'] = failures
print('failure cases gathered:', {k: len(v['traj']) if v.get('traj') else 0 for k, v in failures.items()})

with open(f'{RESULTS}/extra_data2.json', 'w') as f:
    json.dump(OUT, f)
print('SAVED extra_data2.json')
