import json
import numpy as np
import torch

from train import make_env
from dcug_td3 import DCUGTD3Agent
from controllers import fallback_action

RESULTS = '/home/claude/project/results'
MODELS = '/home/claude/project/models'
SEEDS = list(range(1, 11))
N_EVAL = 300


def load_dcug_td3(seed):
    env = make_env(seed=0, difficulty='moderate')
    agent = DCUGTD3Agent(env.obs_dim, env.act_dim)
    ckpt = torch.load(f'{MODELS}/dcug_td3_seed{seed}.pt', weights_only=True)
    agent.actor.load_state_dict(ckpt['actor'])
    return agent


def eval_dcug_td3(agent, difficulty, n=N_EVAL, seed=999):
    env = make_env(seed=seed, difficulty=difficulty)
    succ, lost, raw = [], [], []
    for i in range(n):
        obs, _ = env.reset()
        done = False
        while not done:
            a_safe = fallback_action(env)
            act, *_ = agent.act(obs, a_safe_np=a_safe, sample=False)
            obs, rew, done, info = env.step(act)
        succ.append(float(info['success'])); lost.append(float(info['lost']))
        raw.append(float(info['success']))
    return dict(success_rate=float(np.mean(succ)), lost_rate=float(np.mean(lost)), raw_success=raw)


if __name__ == '__main__':
    results = {}
    for diff in ['mild', 'moderate', 'severe']:
        print(f'--- {diff} ---', flush=True)
        per_seed = []
        for sd in SEEDS:
            agent = load_dcug_td3(sd)
            r = eval_dcug_td3(agent, diff)
            r['seed'] = sd
            per_seed.append(r)
            print(f'  seed {sd}: success={r["success_rate"]:.3f} lost={r["lost_rate"]:.3f}', flush=True)
        results[diff] = per_seed
        with open(f'{RESULTS}/eval_dcug_td3.json', 'w') as f:
            json.dump(results, f, indent=2)
    print('SAVED eval_dcug_td3.json')
