import numpy as np
from env import IBVSDropoutEnv
from ppo import Agent, RolloutBuffer
from controllers import fallback_action


def collect_and_train(agent, env, total_episodes, episodes_per_update=16,
                       log_every=100, verbose=True):
    ep_returns, ep_success, ep_lost, ep_rmse = [], [], [], []
    history = []  # (episode_idx, mean_return, success_rate) sampled at log_every

    ep_count = 0
    while ep_count < total_episodes:
        buf = RolloutBuffer()
        for _ in range(episodes_per_update):
            obs, _ = env.reset()
            done = False
            ep_ret = 0.0
            while not done:
                a_safe = fallback_action(env) if agent.dual else np.zeros(4, dtype=np.float32)
                act, logp, vopt, vpess, alpha = agent.act(obs, a_safe_np=a_safe, sample=True)
                next_obs, rew, done, info = env.step(act)
                buf.add(obs, act, rew, done, logp, vopt, vpess, a_safe, 0.0)
                obs = next_obs
                ep_ret += rew
            ep_returns.append(ep_ret)
            ep_success.append(float(info['success']))
            ep_lost.append(float(info['lost']))
            ep_rmse.append(info['rmse_true'])
            ep_count += 1
        agent.update(buf)

        if ep_count % log_every < episodes_per_update:
            w = 200
            history.append(dict(
                episode=ep_count,
                mean_return=float(np.mean(ep_returns[-w:])),
                success_rate=float(np.mean(ep_success[-w:])),
                lost_rate=float(np.mean(ep_lost[-w:])),
                mean_rmse=float(np.mean(ep_rmse[-w:])),
            ))
            if verbose:
                h = history[-1]
                print(f"  ep {h['episode']:5d} | return {h['mean_return']:7.2f} | "
                      f"succ {h['success_rate']:.2f} | lost {h['lost_rate']:.2f} | rmse {h['mean_rmse']:.1f}")
    return history, dict(returns=ep_returns, success=ep_success, lost=ep_lost, rmse=ep_rmse)


def make_env(seed, difficulty='moderate'):
    presets = {
        'mild':     dict(p_lose=0.04, p_recover=0.25),
        'moderate': dict(p_lose=0.08, p_recover=0.18),
        'severe':   dict(p_lose=0.14, p_recover=0.12),
    }
    kw = presets[difficulty]
    return IBVSDropoutEnv(seed=seed, **kw)


if __name__ == '__main__':
    import time
    env = make_env(seed=0, difficulty='moderate')
    agent = Agent(env.obs_dim, env.act_dim, dual=True)
    t0 = time.time()
    hist, raw = collect_and_train(agent, env, total_episodes=200, episodes_per_update=16, log_every=50)
    print('elapsed', time.time() - t0)
