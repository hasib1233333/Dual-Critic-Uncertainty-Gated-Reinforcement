"""Classical Jacobian-based IBVS controllers used as baselines."""
import numpy as np
from env import image_jacobian, IBVSDropoutEnv, Z_DESIRED

LAMBDA = 1.2


def classical_ibvs_action(pose, s_star, use_pred_features=None):
    """
    Standard Lyapunov IBVS law: v = -lambda * J^+ (s - s*)
    If use_pred_features is given, uses that feature vector for the error
    (used by the EKF-fallback variant during dropout); otherwise this
    function assumes the caller only invokes it when the true pose/features
    are available.
    """
    J = image_jacobian(pose)
    s, _, _, _ = _proj(pose)
    s_used = s if use_pred_features is None else use_pred_features
    err = s_used - s_star
    Jpinv = np.linalg.pinv(J)
    v = -LAMBDA * (Jpinv @ err)
    v = v / IBVSDropoutEnv.V_LIM  # convert physical -> normalized [-1,1] action
    return np.clip(v, -1, 1)


def _proj(pose):
    from env import project
    return project(pose)


FALLBACK_GAIN_SCALE = 0.5  # conservative gain relative to LAMBDA


def fallback_action(env):
    """
    The model-based 'anchor' action available to the RL agent at every step.
    Uses the robot's own proprioceptive pose (always known via forward
    kinematics / encoders) and the EKF-predicted target features (the best
    available estimate of the target while the vision pipeline is degraded
    or fully dropped out), with a deliberately reduced gain -- i.e. a
    cautious hold on the last reliable target estimate rather than an
    aggressive correction based on possibly-stale information.
    """
    J = image_jacobian(env.pose)
    err = env.s_pred - env.s_star
    Jpinv = np.linalg.pinv(J)
    v = -LAMBDA * FALLBACK_GAIN_SCALE * (Jpinv @ err)
    v = v / IBVSDropoutEnv.V_LIM
    return np.clip(v, -1, 1).astype(np.float32)


def run_classical_no_fallback(env, seed_reset_kwargs=None):
    """
    Baseline 1: pure classical IBVS. During dropout, the controller has NO new
    feature measurement, so it freezes the last commanded velocity (naive
    zero-order hold) -- this is the common default behaviour of a
    vision-in-the-loop controller with no explicit dropout handling.
    """
    obs, _ = env.reset(**(seed_reset_kwargs or {}))
    last_action = np.zeros(4)
    traj = []
    done = False
    while not done:
        if env.channel.visible:
            last_action = classical_ibvs_action(env.pose, env.s_star)
        action = last_action
        obs, reward, done, info = env.step(action)
        traj.append(info)
    return traj


def run_classical_ekf_fallback(env, seed_reset_kwargs=None):
    """
    Baseline 2: classical IBVS control law, but during dropout the feature
    error is computed against the EKF-predicted feature vector instead of
    freezing the last command (a standard, sensible engineering fallback).
    """
    obs, _ = env.reset(**(seed_reset_kwargs or {}))
    done = False
    traj = []
    while not done:
        pred_s = env.s_pred
        action = classical_ibvs_action(env.pose, env.s_star, use_pred_features=pred_s)
        obs, reward, done, info = env.step(action)
        traj.append(info)
    return traj
