"""
DCUG-TD3: applies the same fallback-anchoring / uncertainty-gating idea used
in DCUG-PPO to TD3. The actor produces a raw deterministic action mu_raw plus
a gate alpha in (0,1); the executed action is the affine blend
    mu_final = alpha*mu_raw + (1-alpha)*a_safe
exactly as in DCUG-PPO, but here a_safe is blended into a *deterministic*
policy rather than a Gaussian's mean, since TD3 has no learned std. A third
critic, Q_pess, is trained with an asymmetric expectile loss (tau=0.1) on the
same replay buffer and standard TD3 bootstrapped target; the detached
disagreement Q_opt - Q_pess (with Q_opt = min(Q1,Q2), matching TD3's own
overestimation-safe target) feeds the gate, mirroring DCUG-PPO's Delta V.
"""
import numpy as np
import torch
import torch.nn as nn

from td3 import mlp, TD3Critic, ReplayBuffer

torch.set_num_threads(4)


class GatedTD3Actor(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden=64):
        super().__init__()
        self.trunk = mlp([obs_dim, hidden, hidden], out_act=nn.ReLU)
        self.mu_head = nn.Linear(hidden, act_dim)
        self.gate_head = mlp([hidden + 1, 32, 1])

    def forward(self, obs, a_safe, q_diff):
        h = self.trunk(obs)
        mu_raw = torch.tanh(self.mu_head(h))
        gate_in = torch.cat([h, q_diff.unsqueeze(-1)], dim=-1)
        alpha = torch.sigmoid(self.gate_head(gate_in))
        mu_final = alpha * mu_raw + (1 - alpha) * a_safe
        return mu_final, alpha


class QPessCritic(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden=64):
        super().__init__()
        self.net = mlp([obs_dim + act_dim, hidden, hidden, 1])

    def forward(self, obs, act):
        return self.net(torch.cat([obs, act], dim=-1)).squeeze(-1)


def expectile_loss(pred, target, tau=0.1):
    u = target - pred
    w = torch.where(u > 0, tau, 1 - tau)
    return (w * u ** 2).mean()


class GatedReplayBuffer:
    """Like ReplayBuffer, but also stores the REAL fallback action a_safe for
    both the current and next observation, computed from the actual
    environment state at collection time (not reconstructed later from a
    proxy), so off-policy updates can use the true fallback controller."""
    def __init__(self, obs_dim, act_dim, capacity=200_000):
        self.capacity = capacity
        self.obs = np.zeros((capacity, obs_dim), dtype=np.float32)
        self.next_obs = np.zeros((capacity, obs_dim), dtype=np.float32)
        self.acts = np.zeros((capacity, act_dim), dtype=np.float32)
        self.a_safe = np.zeros((capacity, act_dim), dtype=np.float32)
        self.next_a_safe = np.zeros((capacity, act_dim), dtype=np.float32)
        self.rews = np.zeros(capacity, dtype=np.float32)
        self.done = np.zeros(capacity, dtype=np.float32)
        self.ptr = 0
        self.size = 0

    def add(self, o, a, r, no, d, a_safe, next_a_safe):
        i = self.ptr
        self.obs[i] = o; self.next_obs[i] = no; self.acts[i] = a
        self.a_safe[i] = a_safe; self.next_a_safe[i] = next_a_safe
        self.rews[i] = r; self.done[i] = float(d)
        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size):
        idx = np.random.randint(0, self.size, size=batch_size)
        return (torch.as_tensor(self.obs[idx]), torch.as_tensor(self.acts[idx]),
                torch.as_tensor(self.rews[idx]), torch.as_tensor(self.next_obs[idx]),
                torch.as_tensor(self.done[idx]), torch.as_tensor(self.a_safe[idx]),
                torch.as_tensor(self.next_a_safe[idx]))


class DCUGTD3Agent:
    dual = True  # for API compatibility with eval helpers (a_safe expected)

    def __init__(self, obs_dim, act_dim, hidden=64, gamma=0.98, tau=0.005,
                 policy_noise=0.2, noise_clip=0.5, policy_delay=2, lr=3e-4,
                 tau_pess=0.1, pess_coef=0.5):
        self.actor = GatedTD3Actor(obs_dim, act_dim, hidden)
        self.actor_target = GatedTD3Actor(obs_dim, act_dim, hidden)
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic = TD3Critic(obs_dim, act_dim, hidden)  # Q1, Q2 (standard TD3 pair)
        self.critic_target = TD3Critic(obs_dim, act_dim, hidden)
        self.critic_target.load_state_dict(self.critic.state_dict())
        self.q_pess = QPessCritic(obs_dim, act_dim, hidden)
        self.q_pess_target = QPessCritic(obs_dim, act_dim, hidden)
        self.q_pess_target.load_state_dict(self.q_pess.state_dict())

        actor_params = list(self.actor.parameters())
        critic_params = list(self.critic.parameters()) + list(self.q_pess.parameters())
        self.actor_opt = torch.optim.Adam(actor_params, lr=lr)
        self.critic_opt = torch.optim.Adam(critic_params, lr=lr)

        self.gamma = gamma
        self.tau = tau
        self.policy_noise = policy_noise
        self.noise_clip = noise_clip
        self.policy_delay = policy_delay
        self.pess_coef = pess_coef
        self.act_dim = act_dim
        self.update_count = 0

    def _q_diff(self, obs, act, use_target=False):
        c = self.critic_target if use_target else self.critic
        qp = self.q_pess_target if use_target else self.q_pess
        q1, q2 = c(obs, act)
        q_opt = torch.min(q1, q2)
        q_pess_val = qp(obs, act)
        return (q_opt - q_pess_val).detach()

    def act(self, obs_np, a_safe_np, sample=True, explore_noise=0.15):
        obs = torch.as_tensor(obs_np, dtype=torch.float32).unsqueeze(0)
        a_safe = torch.as_tensor(a_safe_np, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            h = self.actor.trunk(obs)
            mu_raw = torch.tanh(self.actor.mu_head(h))
            q_diff = self._q_diff(obs, mu_raw, use_target=False)
            gate_in = torch.cat([h, q_diff.unsqueeze(-1)], dim=-1)
            alpha = torch.sigmoid(self.actor.gate_head(gate_in))
            mu_final = alpha * mu_raw + (1 - alpha) * a_safe
            a = mu_final.squeeze(0).numpy()
        if sample:
            a = a + np.random.normal(0, explore_noise, size=self.act_dim)
        a = np.clip(a, -1, 1)
        return a, 0.0, 0.0, 0.0, float(alpha.squeeze())

    def update(self, buf: GatedReplayBuffer, batch_size=256):
        if buf.size < batch_size:
            return
        obs, act, rew, next_obs, done, a_safe, next_a_safe = buf.sample(batch_size)

        with torch.no_grad():
            next_h = self.actor_target.trunk(next_obs)
            next_mu_raw = torch.tanh(self.actor_target.mu_head(next_h))
            next_q_diff = self._q_diff(next_obs, next_mu_raw, use_target=True)
            next_gate_in = torch.cat([next_h, next_q_diff.unsqueeze(-1)], dim=-1)
            next_alpha = torch.sigmoid(self.actor_target.gate_head(next_gate_in))
            next_mu = next_alpha * next_mu_raw + (1 - next_alpha) * next_a_safe
            noise = (torch.randn_like(act) * self.policy_noise).clamp(-self.noise_clip, self.noise_clip)
            next_act = (next_mu + noise).clamp(-1, 1)
            q1_t, q2_t = self.critic_target(next_obs, next_act)
            q_t = torch.min(q1_t, q2_t)
            y = rew + self.gamma * (1 - done) * q_t

        q1, q2 = self.critic(obs, act)
        critic_loss = ((q1 - y) ** 2).mean() + ((q2 - y) ** 2).mean()
        q_pess_pred = self.q_pess(obs, act)
        pess_loss = expectile_loss(q_pess_pred, y.detach(), tau=0.1)
        total_critic_loss = critic_loss + self.pess_coef * pess_loss
        self.critic_opt.zero_grad()
        total_critic_loss.backward()
        self.critic_opt.step()

        self.update_count += 1
        if self.update_count % self.policy_delay == 0:
            h = self.actor.trunk(obs)
            mu_raw = torch.tanh(self.actor.mu_head(h))
            q_diff = self._q_diff(obs, mu_raw, use_target=False)
            gate_in = torch.cat([h, q_diff.unsqueeze(-1)], dim=-1)
            alpha = torch.sigmoid(self.actor.gate_head(gate_in))
            mu_final = alpha * mu_raw + (1 - alpha) * a_safe
            actor_loss = -self.critic.q1_only(obs, mu_final).mean()
            self.actor_opt.zero_grad()
            actor_loss.backward()
            self.actor_opt.step()

            with torch.no_grad():
                for p, pt in zip(self.actor.parameters(), self.actor_target.parameters()):
                    pt.data.mul_(1 - self.tau).add_(self.tau * p.data)
                for p, pt in zip(self.critic.parameters(), self.critic_target.parameters()):
                    pt.data.mul_(1 - self.tau).add_(self.tau * p.data)
                for p, pt in zip(self.q_pess.parameters(), self.q_pess_target.parameters()):
                    pt.data.mul_(1 - self.tau).add_(self.tau * p.data)
