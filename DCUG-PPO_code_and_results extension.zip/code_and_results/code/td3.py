"""
TD3 (Fujimoto, van Hoof, Meger 2018) as an additional off-policy RL baseline,
answering the reviewer question "would a stronger off-policy method also
solve this?" Standard TD3: deterministic actor, twin critics, delayed policy
updates, target policy smoothing. No fallback anchoring, no dual critic --
this is meant as a naive-but-strong baseline, structurally analogous in role
to the single-critic PPO baseline but from a different RL algorithm family.
"""
import numpy as np
import torch
import torch.nn as nn

torch.set_num_threads(4)


def mlp(sizes, act=nn.ReLU, out_act=nn.Identity):
    layers = []
    for i in range(len(sizes) - 1):
        layers.append(nn.Linear(sizes[i], sizes[i + 1]))
        layers.append(act() if i < len(sizes) - 2 else out_act())
    return nn.Sequential(*layers)


class TD3Actor(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden=64):
        super().__init__()
        self.net = mlp([obs_dim, hidden, hidden, act_dim], out_act=nn.Tanh)

    def forward(self, obs):
        return self.net(obs)


class TD3Critic(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden=64):
        super().__init__()
        self.q1 = mlp([obs_dim + act_dim, hidden, hidden, 1])
        self.q2 = mlp([obs_dim + act_dim, hidden, hidden, 1])

    def forward(self, obs, act):
        x = torch.cat([obs, act], dim=-1)
        return self.q1(x).squeeze(-1), self.q2(x).squeeze(-1)

    def q1_only(self, obs, act):
        x = torch.cat([obs, act], dim=-1)
        return self.q1(x).squeeze(-1)


class ReplayBuffer:
    def __init__(self, obs_dim, act_dim, capacity=200_000):
        self.capacity = capacity
        self.obs = np.zeros((capacity, obs_dim), dtype=np.float32)
        self.next_obs = np.zeros((capacity, obs_dim), dtype=np.float32)
        self.acts = np.zeros((capacity, act_dim), dtype=np.float32)
        self.rews = np.zeros(capacity, dtype=np.float32)
        self.done = np.zeros(capacity, dtype=np.float32)
        self.ptr = 0
        self.size = 0

    def add(self, o, a, r, no, d):
        i = self.ptr
        self.obs[i] = o; self.next_obs[i] = no; self.acts[i] = a
        self.rews[i] = r; self.done[i] = float(d)
        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size):
        idx = np.random.randint(0, self.size, size=batch_size)
        return (torch.as_tensor(self.obs[idx]), torch.as_tensor(self.acts[idx]),
                torch.as_tensor(self.rews[idx]), torch.as_tensor(self.next_obs[idx]),
                torch.as_tensor(self.done[idx]))


class TD3Agent:
    dual = False  # for API compatibility with the eval helpers used elsewhere

    def __init__(self, obs_dim, act_dim, hidden=64, gamma=0.98, tau=0.005,
                 policy_noise=0.2, noise_clip=0.5, policy_delay=2, lr=3e-4):
        self.actor = TD3Actor(obs_dim, act_dim, hidden)
        self.actor_target = TD3Actor(obs_dim, act_dim, hidden)
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic = TD3Critic(obs_dim, act_dim, hidden)
        self.critic_target = TD3Critic(obs_dim, act_dim, hidden)
        self.critic_target.load_state_dict(self.critic.state_dict())
        self.actor_opt = torch.optim.Adam(self.actor.parameters(), lr=lr)
        self.critic_opt = torch.optim.Adam(self.critic.parameters(), lr=lr)
        self.gamma = gamma
        self.tau = tau
        self.policy_noise = policy_noise
        self.noise_clip = noise_clip
        self.policy_delay = policy_delay
        self.act_dim = act_dim
        self.update_count = 0

    def act(self, obs_np, a_safe_np=None, sample=True, explore_noise=0.15):
        obs = torch.as_tensor(obs_np, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            a = self.actor(obs).squeeze(0).numpy()
        if sample:
            a = a + np.random.normal(0, explore_noise, size=self.act_dim)
        a = np.clip(a, -1, 1)
        return a, 0.0, 0.0, 0.0, 1.0  # match Agent.act's 5-tuple signature

    def update(self, buf: ReplayBuffer, batch_size=256):
        if buf.size < batch_size:
            return
        obs, act, rew, next_obs, done = buf.sample(batch_size)
        with torch.no_grad():
            noise = (torch.randn_like(act) * self.policy_noise).clamp(-self.noise_clip, self.noise_clip)
            next_act = (self.actor_target(next_obs) + noise).clamp(-1, 1)
            q1_t, q2_t = self.critic_target(next_obs, next_act)
            q_t = torch.min(q1_t, q2_t)
            y = rew + self.gamma * (1 - done) * q_t

        q1, q2 = self.critic(obs, act)
        critic_loss = ((q1 - y) ** 2).mean() + ((q2 - y) ** 2).mean()
        self.critic_opt.zero_grad()
        critic_loss.backward()
        self.critic_opt.step()

        self.update_count += 1
        if self.update_count % self.policy_delay == 0:
            actor_loss = -self.critic.q1_only(obs, self.actor(obs)).mean()
            self.actor_opt.zero_grad()
            actor_loss.backward()
            self.actor_opt.step()

            with torch.no_grad():
                for p, pt in zip(self.actor.parameters(), self.actor_target.parameters()):
                    pt.data.mul_(1 - self.tau).add_(self.tau * p.data)
                for p, pt in zip(self.critic.parameters(), self.critic_target.parameters()):
                    pt.data.mul_(1 - self.tau).add_(self.tau * p.data)
