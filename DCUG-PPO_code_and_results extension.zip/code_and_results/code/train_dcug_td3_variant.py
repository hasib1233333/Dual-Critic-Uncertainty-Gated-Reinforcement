import sys, json, time, os
import numpy as np
import torch

from train import make_env
from dcug_td3 import DCUGTD3Agent, GatedReplayBuffer
from train_dcug_td3 import collect_and_train_dcug_td3

RESULTS = '/home/claude/project/results'
MODELS = '/home/claude/project/models'

CHUNK = 100

VARIANTS = {
    'dcug_td3_alpha':  dict(total_episodes=1200, warmup=800, kwargs={}),
    'abl_fixed05':     dict(total_episodes=800, warmup=600, kwargs=dict(fixed_alpha=0.5)),
    'abl_noqdiff':     dict(total_episodes=800, warmup=600, kwargs=dict(use_qdiff=False)),
}


def save_ckpt(ckpt_path, agent, buf, done_episodes, history):
    tmp = ckpt_path + '.tmp'
    torch.save(dict(actor=agent.actor.state_dict(), actor_target=agent.actor_target.state_dict(),
                     critic=agent.critic.state_dict(), critic_target=agent.critic_target.state_dict(),
                     q_pess=agent.q_pess.state_dict(), q_pess_target=agent.q_pess_target.state_dict(),
                     update_count=agent.update_count, buf=buf, done_episodes=done_episodes,
                     history=history), tmp)
    os.replace(tmp, ckpt_path)


def train_chunk(name, seed, difficulty='moderate', time_budget=195):
    cfg = VARIANTS[name]
    t_start = time.time()
    ckpt_path = f'{MODELS}/{name}_seed{seed}_ckpt.pt'
    env = make_env(seed=seed, difficulty=difficulty)

    try:
        ckpt = torch.load(ckpt_path, weights_only=False)
        agent = DCUGTD3Agent(env.obs_dim, env.act_dim, **cfg['kwargs'])
        agent.actor.load_state_dict(ckpt['actor'])
        agent.actor_target.load_state_dict(ckpt['actor_target'])
        agent.critic.load_state_dict(ckpt['critic'])
        agent.critic_target.load_state_dict(ckpt['critic_target'])
        agent.q_pess.load_state_dict(ckpt['q_pess'])
        agent.q_pess_target.load_state_dict(ckpt['q_pess_target'])
        agent.update_count = ckpt['update_count']
        buf = ckpt['buf']
        done_episodes = ckpt['done_episodes']
        history = ckpt['history']
        print(f'resumed {name} seed={seed} at episode {done_episodes}', flush=True)
    except FileNotFoundError:
        np.random.seed(seed); torch.manual_seed(seed)
        agent = DCUGTD3Agent(env.obs_dim, env.act_dim, **cfg['kwargs'])
        buf = GatedReplayBuffer(env.obs_dim, env.act_dim)
        done_episodes = 0
        history = []
        print(f'starting fresh {name} seed={seed}', flush=True)

    total_episodes = cfg['total_episodes']
    while done_episodes < total_episodes and (time.time() - t_start) < time_budget:
        this_chunk = min(CHUNK, total_episodes - done_episodes)
        warmup_left = max(0, cfg['warmup'] - buf.size)
        h = collect_and_train_dcug_td3(agent, env, buf, total_episodes=this_chunk, log_every=100,
                                         warmup_steps=warmup_left, verbose=True)
        for entry in h:
            entry['episode'] += done_episodes
        history += h
        done_episodes += this_chunk
        save_ckpt(ckpt_path, agent, buf, done_episodes, history)
        print(f'  [checkpoint saved at episode {done_episodes}, elapsed {time.time()-t_start:.0f}s]', flush=True)

    if done_episodes >= total_episodes:
        torch.save(dict(actor=agent.actor.state_dict()), f'{MODELS}/{name}_seed{seed}.pt')
        with open(f'{RESULTS}/train_{name}_seed{seed}.json', 'w') as f:
            json.dump(dict(seed=seed, history=history), f)
        print(f'{name} SEED {seed} FULLY DONE, final success={history[-1]["success_rate"]:.2f}', flush=True)
        return True
    return False


if __name__ == '__main__':
    name = sys.argv[1]
    seed = int(sys.argv[2])
    finished = train_chunk(name, seed)
    print('FINISHED' if finished else 'PARTIAL', name, seed)
