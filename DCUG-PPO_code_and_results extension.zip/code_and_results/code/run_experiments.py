import json
import time
import numpy as np
import torch

from train import make_env, collect_and_train
from ppo import Agent
from controllers import run_classical_no_fallback, run_classical_ekf_fallback, fallback_action

RESULTS = '/home/claude/project/results'
MODELS = '/home/claude/project/models'

SEEDS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
ABL_SEEDS = [1, 2]
TRAIN_EPISODES = 3000
ABL_EPISODES = 2500
TRAIN_DIFFICULTY = 'moderate'
EVAL_EPISODES = 300


def set_seed(s):
    np.random.seed(s)
    torch.manual_seed(s)


def train_variant(name, dual, seeds, episodes, **agent_kwargs):
    all_hist = []
    for sd in seeds:
        print(f'=== training {name} seed={sd} ({episodes} episodes) ===', flush=True)
        set_seed(sd)
        env = make_env(seed=sd, difficulty=TRAIN_DIFFICULTY)
        agent = Agent(env.obs_dim, env.act_dim, dual=dual, **agent_kwargs)
        t0 = time.time()
        hist, raw = collect_and_train(agent, env, total_episodes=episodes,
                                       episodes_per_update=16, log_every=200, verbose=True)
        dt = time.time() - t0
        print(f'--- {name} seed={sd} done in {dt:.1f}s, final success={hist[-1]["success_rate"]:.2f} ---', flush=True)
        torch.save({'actor': agent.actor.state_dict(), 'v_opt': agent.v_opt.state_dict(),
                    'v_pess': agent.v_pess.state_dict() if dual else None},
                   f'{MODELS}/{name}_seed{sd}.pt')
        all_hist.append(dict(seed=sd, history=hist, elapsed=dt))
        with open(f'{RESULTS}/train_{name}.json', 'w') as f:
            json.dump(all_hist, f)
    return all_hist


def eval_agent(agent, difficulty, n=EVAL_EPISODES, seed=999, record_traj=False, record_raw=False):
    env = make_env(seed=seed, difficulty=difficulty)
    succ, lost, rmse, rets = [], [], [], []
    example_traj = None
    for i in range(n):
        obs, _ = env.reset()
        done = False
        ep_ret = 0.0
        traj = [] if (record_traj and i == 0) else None
        while not done:
            a_safe = fallback_action(env) if agent.dual else np.zeros(4, dtype=np.float32)
            act, logp, vopt, vpess, alpha = agent.act(obs, a_safe_np=a_safe, sample=False)
            obs, rew, done, info = env.step(act)
            ep_ret += rew
            if traj is not None:
                traj.append(dict(rmse=info['rmse_true'], visible=info['visible'],
                                  alpha=float(alpha), pose=info['pose'].tolist()))
        succ.append(float(info['success'])); lost.append(float(info['lost']))
        rmse.append(info['rmse_true']); rets.append(ep_ret)
        if traj is not None:
            example_traj = traj
    out = dict(success_rate=float(np.mean(succ)), lost_rate=float(np.mean(lost)),
               mean_rmse=float(np.mean(rmse)), mean_return=float(np.mean(rets)),
               success_std=float(np.std(succ)))
    if record_traj:
        out['example_traj'] = example_traj
    if record_raw:
        out['raw_success'] = succ
    return out


def eval_classical(difficulty, n=EVAL_EPISODES, seed=999):
    env = make_env(seed=seed, difficulty=difficulty)
    r1 = dict(succ=[], lost=[])
    r2 = dict(succ=[], lost=[])
    for i in range(n):
        t1 = run_classical_no_fallback(env, dict())
        r1['succ'].append(float(t1[-1]['success'])); r1['lost'].append(float(t1[-1]['lost']))
        t2 = run_classical_ekf_fallback(env, dict())
        r2['succ'].append(float(t2[-1]['success'])); r2['lost'].append(float(t2[-1]['lost']))
    return (dict(success_rate=np.mean(r1['succ']), lost_rate=np.mean(r1['lost']), raw_success=r1['succ']),
            dict(success_rate=np.mean(r2['succ']), lost_rate=np.mean(r2['lost']), raw_success=r2['succ']))


def load_agent(name, seed, dual, **agent_kwargs):
    env_dummy = make_env(seed=0, difficulty='moderate')
    agent = Agent(env_dummy.obs_dim, env_dummy.act_dim, dual=dual, **agent_kwargs)
    ckpt = torch.load(f'{MODELS}/{name}_seed{seed}.pt', weights_only=True)
    agent.actor.load_state_dict(ckpt['actor'])
    agent.v_opt.load_state_dict(ckpt['v_opt'])
    if dual and ckpt['v_pess'] is not None:
        agent.v_pess.load_state_dict(ckpt['v_pess'])
    return agent


def eval_one_difficulty(difficulty):
    print(f'--- evaluating difficulty={difficulty} ---', flush=True)
    c_nofb, c_ekf = eval_classical(difficulty)
    dcug_evals = [eval_agent(load_agent('dcug_full', sd, dual=True), difficulty,
                              record_traj=(sd == SEEDS[0] and difficulty == 'moderate'),
                              record_raw=True)
                  for sd in SEEDS]
    sc_evals = [eval_agent(load_agent('single_critic', sd, dual=False), difficulty, record_raw=True)
                for sd in SEEDS]
    result = dict(
        classical_no_fallback=c_nofb,
        classical_ekf_fallback=c_ekf,
        dcug_full=dcug_evals,
        single_critic=sc_evals,
    )
    try:
        with open(f'{RESULTS}/eval_results.json') as f:
            all_results = json.load(f)
    except FileNotFoundError:
        all_results = {}
    all_results[difficulty] = result
    with open(f'{RESULTS}/eval_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    print(f'saved {difficulty}', flush=True)


def eval_ablations():
    abl_fixed = [eval_agent(load_agent('abl_fixed_alpha', sd, dual=True, fixed_alpha=0.5), 'moderate', record_raw=True)
                 for sd in ABL_SEEDS]
    abl_novdiff = [eval_agent(load_agent('abl_no_vdiff', sd, dual=True, use_vdiff=False), 'moderate', record_raw=True)
                   for sd in ABL_SEEDS]
    try:
        with open(f'{RESULTS}/eval_results.json') as f:
            all_results = json.load(f)
    except FileNotFoundError:
        all_results = {}
    all_results['ablation_moderate'] = dict(abl_fixed_alpha=abl_fixed, abl_no_vdiff=abl_novdiff)
    with open(f'{RESULTS}/eval_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    print('saved ablations', flush=True)


if __name__ == '__main__':
    t_start = time.time()

    # 3) evaluation sweeps across dropout-severity difficulty settings
    eval_results = {}
    for difficulty in ['mild', 'moderate', 'severe']:
        print(f'--- evaluating difficulty={difficulty} ---', flush=True)
        c_nofb, c_ekf = eval_classical(difficulty)
        dcug_evals = [eval_agent(load_agent('dcug_full', sd, dual=True), difficulty,
                                  record_traj=(sd == SEEDS[0] and difficulty == 'moderate'),
                                  record_raw=True)
                      for sd in SEEDS]
        sc_evals = [eval_agent(load_agent('single_critic', sd, dual=False), difficulty, record_raw=True)
                    for sd in SEEDS]
        eval_results[difficulty] = dict(
            classical_no_fallback=c_nofb,
            classical_ekf_fallback=c_ekf,
            dcug_full=dcug_evals,
            single_critic=sc_evals,
        )

    # ablations evaluated only at the training (moderate) difficulty
    abl_fixed = [eval_agent(load_agent('abl_fixed_alpha', sd, dual=True, fixed_alpha=0.5), 'moderate')
                 for sd in ABL_SEEDS]
    abl_novdiff = [eval_agent(load_agent('abl_no_vdiff', sd, dual=True, use_vdiff=False), 'moderate')
                   for sd in ABL_SEEDS]
    eval_results['ablation_moderate'] = dict(abl_fixed_alpha=abl_fixed, abl_no_vdiff=abl_novdiff)

    with open(f'{RESULTS}/eval_results.json', 'w') as f:
        json.dump(eval_results, f, indent=2)

    print(f'=== ALL DONE in {time.time()-t_start:.1f}s ===', flush=True)
