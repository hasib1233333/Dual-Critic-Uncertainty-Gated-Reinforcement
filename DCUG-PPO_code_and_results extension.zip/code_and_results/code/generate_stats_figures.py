"""
Generates the two newest extension-paper figures:
  - fig9_forest_plot: mean success-rate difference (DCUG-TD3 - TD3) with 95% CI,
    matched n=10 seeds per method, at each dropout severity.
  - fig10_ablation_chart: bar-chart visualization of the ablation table (TD3,
    fixed-alpha=0.5 blend, gate-without-delta-Q, full DCUG-TD3).

Run from the ext_paper/ directory (needs ieee_style.py and results/*.json).
"""
import sys
sys.path.insert(0, '.')
from ieee_style import *
import json
import numpy as np
from scipy import stats

RES = '../results'


def ci95_diff(a, b):
    """95% CI on the mean difference a-b via Welch-Satterthwaite."""
    a, b = np.array(a), np.array(b)
    diff = a.mean() - b.mean()
    se = np.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b))
    df = (a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b)) ** 2 / (
        (a.var(ddof=1) / len(a)) ** 2 / (len(a) - 1) + (b.var(ddof=1) / len(b)) ** 2 / (len(b) - 1))
    tval = stats.t.ppf(0.975, df)
    return diff, diff - tval * se, diff + tval * se


def fig_forest_plot():
    td3 = json.load(open(f'{RES}/eval_td3.json'))
    dt = json.load(open(f'{RES}/eval_dcug_td3.json'))

    diffs = ['Mild', 'Moderate', 'Severe']
    keys = ['mild', 'moderate', 'severe']
    means, los, his, pvals = [], [], [], []
    for k in keys:
        a = [x['success_rate'] for x in dt[k]]
        b = [x['success_rate'] for x in td3[k]]
        d, lo, hi = ci95_diff(a, b)
        t, p = stats.ttest_ind(a, b, equal_var=False)
        means.append(d * 100); los.append(lo * 100); his.append(hi * 100); pvals.append(p)

    fig, ax = plt.subplots(figsize=(6.8, 3.6))
    y = np.arange(len(diffs))
    for i, (m, lo, hi, p) in enumerate(zip(means, los, his, pvals)):
        ax.errorbar(m, i, xerr=[[m - lo], [hi - m]], fmt='D', color=IEEE_COLOR['dcug_td3'],
                    markersize=8, capsize=5, capthick=2, elinewidth=2.5, ecolor='#555555')
        ax.text(hi + 1.5, i, f'p={p:.3f}', va='center', fontsize=9)
    ax.axvline(0, color='black', lw=1.5, ls='-')
    ax.set_yticks(y); ax.set_yticklabels(diffs)
    ax.set_xlabel('DCUG-TD3 minus TD3 success rate (percentage points, 95% CI)')
    ax.set_title('Mean-difference forest plot, matched n=10 seeds each')
    ax.invert_yaxis()
    fig.subplots_adjust(right=0.82)
    save_all_formats(fig, 'fig9_forest_plot')
    for d, m, lo, hi, p in zip(diffs, means, los, his, pvals):
        print(d, round(m, 2), round(lo, 2), round(hi, 2), round(p, 3))


def fig_ablation_chart():
    ablations = json.load(open(f'{RES}/dcug_td3_ablations.json'))
    td3 = json.load(open(f'{RES}/eval_td3.json'))
    dt = json.load(open(f'{RES}/eval_dcug_td3.json'))

    labels = ['TD3\n(no anchor,\nno gate)', 'Fixed blend\n(\u03b1=0.5)', 'Gate w/o\n\u0394Q', 'Full\nDCUG-TD3']
    means = [
        np.mean([x['success_rate'] for x in td3['moderate']]),
        np.mean([x['success_rate'] for x in ablations['abl_fixed05']]),
        np.mean([x['success_rate'] for x in ablations['abl_noqdiff']]),
        np.mean([x['success_rate'] for x in dt['moderate']]),
    ]
    stds = [
        np.std([x['success_rate'] for x in td3['moderate']]),
        np.std([x['success_rate'] for x in ablations['abl_fixed05']]),
        np.std([x['success_rate'] for x in ablations['abl_noqdiff']]),
        np.std([x['success_rate'] for x in dt['moderate']]),
    ]
    ns = [10, 2, 2, 10]
    colors = [IEEE_COLOR['td3'], '#999999', '#C44E52', IEEE_COLOR['dcug_td3']]

    fig, ax = plt.subplots(figsize=(6.8, 4.0))
    x = np.arange(4)
    ax.bar(x, [m * 100 for m in means], yerr=[s * 100 for s in stds], color=colors,
           capsize=6, edgecolor='black', linewidth=1.2, error_kw=dict(elinewidth=2.2, capthick=2.2))
    for i, (m, n) in enumerate(zip(means, ns)):
        ax.text(i, m * 100 + 3.5, f'{m*100:.1f}%\n(n={n})', ha='center', fontsize=9)
    ax.set_xticks(x); ax.set_xticklabels(labels, fontsize=9.5)
    ax.set_ylabel('Success rate (moderate dropout, %)')
    ax.set_ylim(0, 115)
    ax.set_title('Ablation: isolating the gate from the pessimistic critic')
    save_all_formats(fig, 'fig10_ablation_chart')


if __name__ == '__main__':
    fig_forest_plot()
    fig_ablation_chart()
    print('DONE')
