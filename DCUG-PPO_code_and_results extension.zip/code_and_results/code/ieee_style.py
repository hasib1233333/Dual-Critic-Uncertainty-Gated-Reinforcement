"""IEEE-style matplotlib configuration, shared across all extension-paper figures."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# Liberation Serif is metrically compatible with Times New Roman and is
# actually installed in this environment (no real Times New Roman available).
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Liberation Serif', 'Times New Roman', 'DejaVu Serif'],
    'axes.labelsize': 11,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 10,
    'axes.titlesize': 12,
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
    'savefig.facecolor': 'white',
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.grid': True,
    'grid.alpha': 0.35,
    'grid.linestyle': '--',
    'grid.linewidth': 0.6,
    'grid.color': '#B0B0B0',
    'lines.linewidth': 2.5,
    'lines.markersize': 8,
    'axes.linewidth': 1.0,
    'figure.dpi': 150,
    'savefig.bbox': 'tight',
    'savefig.transparent': False,
})

# IEEE-appropriate palette, mapped per the requested scheme.
IEEE_COLOR = dict(
    td3='#0072BD',          # blue
    dcug_td3='#D95319',     # orange
    single_critic='#7F7F7F',  # gray (PPO baseline)
    dcug_full='#77AC30',    # green (DCUG-PPO)
    baseline='#000000',     # black (classical baselines)
    ekf_fallback='#000000',
    no_fallback='#4D4D4D',
)
IEEE_LABEL = dict(
    td3='TD3',
    dcug_td3='DCUG-TD3 (this paper)',
    single_critic='Single-critic PPO',
    dcug_full='DCUG-PPO',
    ekf_fallback='Classical + EKF',
    no_fallback='Classical (no fallback)',
)
IEEE_MARKER = dict(td3='o', dcug_td3='s', single_critic='^', dcug_full='D',
                    ekf_fallback='v', no_fallback='x')


def save_all_formats(fig, path_no_ext):
    fig.savefig(path_no_ext + '.pdf')
    fig.savefig(path_no_ext + '.eps')
    fig.savefig(path_no_ext + '.svg')
