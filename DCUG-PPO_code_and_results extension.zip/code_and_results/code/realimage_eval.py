import os
os.environ.setdefault('MUJOCO_GL', 'egl')
import json, time
import numpy as np

from mujoco_realimage_env import RealImageMuJoCoEnv
from run_experiments import load_agent, RESULTS
from controllers import fallback_action, classical_ibvs_action

N_EVAL = 30  # reduced from 300 due to rendering cost (~45ms/step vs <1ms analytic)
SEEDS = [1, 2, 3, 4, 5]


def eval_agent_realimage(agent, n=N_EVAL, seed=999):
    env = RealImageMuJoCoEnv(p_lose=0.08, p_recover=0.18, seed=seed)
    succ, lost = [], []
    for i in range(n):
        obs, _ = env.reset()
        done = False
        while not done:
            a_safe = fallback_action(env) if agent.dual else np.zeros(4, dtype=np.float32)
            act, *_ = agent.act(obs, a_safe_np=a_safe, sample=False)
            obs, rew, done, info = env.step(act)
        succ.append(float(info['success'])); lost.append(float(info['lost']))
    return dict(success_rate=float(np.mean(succ)), lost_rate=float(np.mean(lost)))


def eval_classical_realimage(n=N_EVAL, seed=999):
    env = RealImageMuJoCoEnv(p_lose=0.08, p_recover=0.18, seed=seed)
    succ, lost = [], []
    for i in range(n):
        obs, _ = env.reset()
        done = False
        while not done:
            action = classical_ibvs_action(env.pose, env.s_star, use_pred_features=env.s_pred)
            obs, rew, done, info = env.step(action)
        succ.append(float(info['success'])); lost.append(float(info['lost']))
    return dict(success_rate=float(np.mean(succ)), lost_rate=float(np.mean(lost)))


if __name__ == '__main__':
    import sys
    t0 = time.time()
    which = sys.argv[1] if len(sys.argv) > 1 else 'all'

    try:
        with open(f'{RESULTS}/realimage_transfer.json') as f:
            results = json.load(f)
    except FileNotFoundError:
        results = {}

    if which in ('all', 'classical'):
        print('--- classical EKF-fallback ---', flush=True)
        results['classical_ekf_fallback'] = eval_classical_realimage()
        print(results['classical_ekf_fallback'], flush=True)

    if which in ('all', 'dcug'):
        results.setdefault('dcug_full', [])
        done_seeds = {r['seed'] for r in results['dcug_full']}
        for sd in SEEDS:
            if sd in done_seeds:
                continue
            agent = load_agent('dcug_full', sd, dual=True)
            r = eval_agent_realimage(agent, seed=999 + sd)
            r['seed'] = sd
            results['dcug_full'].append(r)
            print('dcug seed', sd, r, flush=True)
            with open(f'{RESULTS}/realimage_transfer.json', 'w') as f:
                json.dump(results, f, indent=2)

    if which in ('all', 'sc'):
        results.setdefault('single_critic', [])
        done_seeds = {r['seed'] for r in results['single_critic']}
        for sd in SEEDS:
            if sd in done_seeds:
                continue
            agent = load_agent('single_critic', sd, dual=False)
            r = eval_agent_realimage(agent, seed=999 + sd)
            r['seed'] = sd
            results['single_critic'].append(r)
            print('single_critic seed', sd, r, flush=True)
            with open(f'{RESULTS}/realimage_transfer.json', 'w') as f:
                json.dump(results, f, indent=2)

    with open(f'{RESULTS}/realimage_transfer.json', 'w') as f:
        json.dump(results, f, indent=2)
    print(f'DONE in {time.time()-t0:.1f}s', flush=True)
