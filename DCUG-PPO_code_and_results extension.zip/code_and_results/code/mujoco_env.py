"""
Cross-simulator validation: the SAME IBVS-under-dropout task (same interaction
matrix, same dropout channel, same target drift, same success criterion),
but the camera platform is now a real rigid body simulated in MuJoCo (mass,
joint damping, velocity-servo actuators) instead of the idealized
instantaneous-velocity kinematic integrator used everywhere else in this
paper. This tests zero-shot transfer of the already-trained policies to an
established, independently-developed physics engine.
"""
import numpy as np
import mujoco

from env import (project, image_jacobian, TARGET_PTS, Z_DESIRED, F, IMG_HALF,
                  SUCCESS_TOL, SUCCESS_HOLD, DropoutChannel, DT)

XML = """
<mujoco>
  <option timestep="0.005" gravity="0 0 0" integrator="implicitfast"/>
  <worldbody>
    <body name="cam" pos="0 0 0.6">
      <joint name="jx" type="slide" axis="1 0 0" damping="3.0"/>
      <joint name="jy" type="slide" axis="0 1 0" damping="3.0"/>
      <joint name="jz" type="slide" axis="0 0 1" damping="3.0"/>
      <joint name="jyaw" type="hinge" axis="0 0 1" damping="0.8"/>
      <inertial pos="0 0 0" mass="0.6" diaginertia="0.001 0.001 0.001"/>
      <geom type="box" size="0.03 0.03 0.03"/>
    </body>
  </worldbody>
  <actuator>
    <velocity name="ax" joint="jx" kv="40"/>
    <velocity name="ay" joint="jy" kv="40"/>
    <velocity name="az" joint="jz" kv="40"/>
    <velocity name="ayaw" joint="jyaw" kv="1.5"/>
  </actuator>
</mujoco>
"""

SUBSTEPS = int(round(DT / 0.005))  # 20 physics substeps per 0.1s control step


class MuJoCoIBVSEnv:
    """Same task/observation/action semantics as env.IBVSDropoutEnv, but the
    camera pose is now driven by MuJoCo rigid-body dynamics rather than
    instantaneous kinematic integration."""
    V_LIM = np.array([0.25, 0.25, 0.20, 0.8])

    def __init__(self, p_lose=0.08, p_recover=0.18, seed=0, pixel_noise_std=0.5,
                 target_drift_std=0.006, process_noise_std=0.006,
                 pose_range=None):
        self.model = mujoco.MjModel.from_xml_string(XML)
        self.data = mujoco.MjData(self.model)
        self.rng = np.random.default_rng(seed)
        self.channel = DropoutChannel(p_lose, p_recover, self.rng)
        self.pixel_noise_std = pixel_noise_std
        self.target_drift_std = target_drift_std
        self.process_noise_std = process_noise_std
        self.pose_range = pose_range or dict(xy=0.15, z=(0.45, 0.85), th=0.5)
        self.s_star, _, _, _ = project((0.0, 0.0, Z_DESIRED, 0.0))
        self.obs_dim = 22
        self.act_dim = 4

    def _mj_pose(self):
        x, y, z, th = self.data.qpos[0], self.data.qpos[1], self.data.qpos[2] + 0.6, self.data.qpos[3]
        return np.array([x, y, z, th])

    def reset(self, difficulty=None):
        r = self.pose_range
        x0 = self.rng.uniform(-r['xy'], r['xy'])
        y0 = self.rng.uniform(-r['xy'], r['xy'])
        z0 = self.rng.uniform(*r['z']) - 0.6
        th0 = self.rng.uniform(-r['th'], r['th'])
        if difficulty is not None:
            x0, y0, th0 = x0 * difficulty, y0 * difficulty, th0 * difficulty
        mujoco.mj_resetData(self.model, self.data)
        self.data.qpos[:] = [x0, y0, z0, th0]
        self.data.qvel[:] = 0.0
        mujoco.mj_forward(self.model, self.data)
        self.target_xy = np.zeros(2)
        self.target_vel = self.rng.normal(0, self.target_drift_std, size=2)
        self.channel.reset()
        self.t = 0
        self.prev_action = np.zeros(4)
        self.pose = self._mj_pose()
        self.true_s, self.zc, _, _ = project(self.pose, target_xy=self.target_xy)
        self.s_pred = self.true_s.copy()
        self.s_vel = np.zeros(8)
        self.cov_trace = 0.0
        self._success_streak = 0
        return self._obs(), {}

    def _fov_violation(self, s):
        return np.any(np.abs(s) > IMG_HALF * 1.6)

    def _obs(self):
        err = (self.s_pred - self.s_star) / IMG_HALF
        vel = self.s_vel / IMG_HALF
        t_since = np.array([min(self.channel.steps_since_valid, 20) / 20.0])
        cov = np.array([min(self.cov_trace, 400.0) / 400.0])
        return np.concatenate([err, vel, t_since, cov, self.prev_action]).astype(np.float32)

    def step(self, action):
        action = np.clip(action, -1, 1)
        v_cmd = action * self.V_LIM
        self.data.ctrl[:] = v_cmd
        for _ in range(SUBSTEPS):
            self.data.qvel[:] += self.rng.normal(0, self.process_noise_std, size=4) * 0.005
            mujoco.mj_step(self.model, self.data)
        self.pose = self._mj_pose()
        self.pose[2] = np.clip(self.pose[2], 0.2, 1.2)

        self.target_vel = self.target_vel + self.rng.normal(0, self.target_drift_std * 0.3, size=2)
        self.target_vel = np.clip(self.target_vel, -0.05, 0.05)
        self.target_xy = self.target_xy + self.target_vel * DT
        self.true_s, self.zc, _, _ = project(self.pose, target_xy=self.target_xy)

        visible = self.channel.step()
        if visible:
            noisy_s = self.true_s + self.rng.normal(0, self.pixel_noise_std, size=8)
            innov = noisy_s - self.s_pred
            self.s_vel = 0.7 * self.s_vel + 0.3 * (innov / DT)
            self.s_pred = noisy_s
            self.cov_trace = 5.0
        else:
            self.s_pred = self.s_pred + self.s_vel * DT
            self.cov_trace = self.cov_trace + 8.0 * (1 + 0.15 * self.channel.steps_since_valid)

        err_true = self.true_s - self.s_star
        rmse_true = np.sqrt(np.mean(err_true ** 2))
        lost = self._fov_violation(self.true_s) or self.pose[2] <= 0.21 or self.pose[2] >= 1.19

        if rmse_true < SUCCESS_TOL:
            self._success_streak += 1
        else:
            self._success_streak = 0
        success = self._success_streak >= SUCCESS_HOLD

        self.prev_action = action.copy()
        self.t += 1
        done = lost or success or (self.t >= 100)
        info = dict(rmse_true=rmse_true, visible=visible, lost=lost, success=success, pose=self.pose.copy())
        return self._obs(), 0.0, done, info
