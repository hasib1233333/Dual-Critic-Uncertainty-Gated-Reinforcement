import json, time
import numpy as np

from mujoco_env import MuJoCoIBVSEnv
from run_experiments import load_agent, RESULTS
from controllers import fallback_action, run_classical_no_fallback, run_classical_ekf_fallback

SEEDS = [6, 7, 8, 9, 10]
PRESETS = {
    'mild':     dict(p_lose=0.04, p_recover=0.25),
    'moderate': dict(p_lose=0.08, p_recover=0.18),
    'severe':   dict(p_lose=0.14, p_recover=0.12),
}
N_EVAL = 100

results = {}
t_start = time.time()
for diff, kw in PRESETS.items():
    print(f'=== {diff} ===', flush=True)
    env = MuJoCoIBVSEnv(seed=999, **kw)
    n1 = n2 = 0
    for i in range(N_EVAL):
        t1 = run_classical_no_fallback(env, dict()); n1 += t1[-1]['success']
        t2 = run_classical_ekf_fallback(env, dict()); n2 += t2[-1]['success']
    classical_no_fallback = n1 / N_EVAL
    classical_ekf_fallback = n2 / N_EVAL

    dcug_res, sc_res = [], []
    for sd in SEEDS:
        dcug_agent = load_agent('dcug_full', sd, dual=True)
        sc_agent = load_agent('single_critic', sd, dual=False)
        env = MuJoCoIBVSEnv(seed=999, **kw)
        s_d = s_s = l_d = l_s = 0
        for i in range(N_EVAL):
            obs, _ = env.reset()
            done = False
            while not done:
                a_safe = fallback_action(env)
                act, *_ = dcug_agent.act(obs, a_safe_np=a_safe, sample=False)
                obs, rew, done, info = env.step(act)
            s_d += info['success']; l_d += info['lost']

            obs, _ = env.reset()
            done = False
            while not done:
                act, *_ = sc_agent.act(obs, a_safe_np=np.zeros(4, dtype=np.float32), sample=False)
                obs, rew, done, info = env.step(act)
            s_s += info['success']; l_s += info['lost']
        dcug_res.append(dict(success_rate=s_d / N_EVAL, lost_rate=l_d / N_EVAL))
        sc_res.append(dict(success_rate=s_s / N_EVAL, lost_rate=l_s / N_EVAL))
        print(f'  seed {sd}: dcug={s_d/N_EVAL:.2f} sc={s_s/N_EVAL:.2f}', flush=True)

    results[diff] = dict(
        classical_no_fallback=classical_no_fallback,
        classical_ekf_fallback=classical_ekf_fallback,
        dcug_full=dcug_res,
        single_critic=sc_res,
    )

try:
    with open(f'{RESULTS}/mujoco_transfer.json') as f:
        prev = json.load(f)
    for d in results:
        prev[d]['dcug_full'] += results[d]['dcug_full']
        prev[d]['single_critic'] += results[d]['single_critic']
    results = prev
except FileNotFoundError:
    pass
with open(f'{RESULTS}/mujoco_transfer.json', 'w') as f:
    json.dump(results, f, indent=2)
print(f'DONE in {time.time()-t_start:.1f}s')
