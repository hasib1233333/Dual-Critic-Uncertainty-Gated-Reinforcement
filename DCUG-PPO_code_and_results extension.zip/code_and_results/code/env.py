"""
Eye-in-hand Image-Based Visual Servoing (IBVS) environment with
Markov-modulated intermittent camera dropout.

Camera looks straight down at a planar square target (4 corner features).
Controllable DOF: [vx, vy, vz, wz]  (horizontal translation, height rate, yaw rate)
State integrated in the world frame; target is static at the world origin.
"""
import numpy as np

F = 400.0          # focal length in pixel units
IMG_HALF = 180.0   # image half-size (pixels) -> FOV cutoff
TARGET_HALF = 0.10 # half side length of square target (m)
Z_DESIRED = 0.60    # desired camera height above target (m)
DT = 0.1
MAX_STEPS = 100
SUCCESS_TOL = 5.5   # px RMSE considered "converged"
SUCCESS_HOLD = 8    # must stay converged this many consecutive steps

# 4 target corners in world frame (z = 0 plane)
TARGET_PTS = np.array([
    [-TARGET_HALF, -TARGET_HALF, 0.0],
    [ TARGET_HALF, -TARGET_HALF, 0.0],
    [ TARGET_HALF,  TARGET_HALF, 0.0],
    [-TARGET_HALF,  TARGET_HALF, 0.0],
])


def project(pose, pts=TARGET_PTS, target_xy=(0.0, 0.0)):
    """pose = (px, py, pz, theta). Returns feature vector s (8,) and per-point zc (4,)."""
    px, py, pz, th = pose
    tx, ty = target_xy
    dx = (pts[:, 0] + tx) - px
    dy = (pts[:, 1] + ty) - py
    ct, st = np.cos(th), np.sin(th)
    xc = dx * ct + dy * st
    yc = -dx * st + dy * ct
    zc = np.full(4, pz)
    u = F * xc / zc
    v = F * yc / zc
    s = np.stack([u, v], axis=1).reshape(-1)
    return s, zc, u, v


def image_jacobian(pose, pts=TARGET_PTS, target_xy=(0.0, 0.0)):
    """Analytic interaction matrix J (8x4) mapping [vx,vy,vz,wz] -> ds/dt."""
    px, py, pz, th = pose
    tx, ty = target_xy
    dx = (pts[:, 0] + tx) - px
    dy = (pts[:, 1] + ty) - py
    ct, st = np.cos(th), np.sin(th)
    xc = dx * ct + dy * st
    yc = -dx * st + dy * ct
    zc = pz
    u = F * xc / zc
    v = F * yc / zc
    rows = []
    for i in range(4):
        Ju = [-F * ct / zc, -F * st / zc, -u[i] / zc, v[i]]
        Jv = [ F * st / zc, -F * ct / zc, -v[i] / zc, -u[i]]
        rows.append(Ju)
        rows.append(Jv)
    return np.array(rows)


class DropoutChannel:
    """Two-state Markov chain: VISIBLE <-> DROPOUT."""
    def __init__(self, p_lose, p_recover, rng):
        self.p_lose = p_lose
        self.p_recover = p_recover
        self.rng = rng
        self.visible = True
        self.steps_since_valid = 0

    def reset(self):
        self.visible = True
        self.steps_since_valid = 0

    def step(self):
        if self.visible:
            if self.rng.random() < self.p_lose:
                self.visible = False
        else:
            if self.rng.random() < self.p_recover:
                self.visible = True
        if self.visible:
            self.steps_since_valid = 0
        else:
            self.steps_since_valid += 1
        return self.visible


class IBVSDropoutEnv:
    """
    Observation (RL agents): 8 (predicted/observed feature error, normalized)
                              + 8 (feature velocity estimate, normalized)
                              + 1 (steps_since_valid, normalized)
                              + 1 (EKF covariance-trace proxy, normalized)
                              + 4 (previous action)  = 22 dims
    Action: 4 continuous in [-1,1], scaled to physical velocity limits.
    """
    V_LIM = np.array([0.25, 0.25, 0.20, 0.8])  # vx,vy,vz,wz limits (m/s, rad/s)

    def __init__(self, p_lose=0.06, p_recover=0.20, pose_range=None, seed=0,
                 pixel_noise_std=0.5, target_drift_std=0.006, process_noise_std=0.006):
        self.rng = np.random.default_rng(seed)
        self.p_lose = p_lose
        self.p_recover = p_recover
        self.channel = DropoutChannel(p_lose, p_recover, self.rng)
        self.pixel_noise_std = pixel_noise_std
        self.target_drift_std = target_drift_std   # target platform drift speed std (m/s)
        self.process_noise_std = process_noise_std  # unmodeled camera-platform disturbance
        self.pose_range = pose_range or dict(xy=0.15, z=(0.45, 0.85), th=0.5)
        self.s_star, _, _, _ = project((0.0, 0.0, Z_DESIRED, 0.0))
        self.obs_dim = 22
        self.act_dim = 4

    def reset(self, difficulty=None):
        r = self.pose_range
        x0 = self.rng.uniform(-r['xy'], r['xy'])
        y0 = self.rng.uniform(-r['xy'], r['xy'])
        z0 = self.rng.uniform(*r['z'])
        th0 = self.rng.uniform(-r['th'], r['th'])
        if difficulty is not None:
            scale = difficulty
            x0, y0, th0 = x0 * scale, y0 * scale, th0 * scale
        self.pose = np.array([x0, y0, z0, th0])
        self.target_xy = np.zeros(2)
        self.target_vel = self.rng.normal(0, self.target_drift_std, size=2)
        self.channel.reset()
        self.t = 0
        self.prev_action = np.zeros(4)
        self.true_s, self.zc, _, _ = project(self.pose, target_xy=self.target_xy)
        self.s_pred = self.true_s.copy()   # EKF predicted features
        self.s_vel = np.zeros(8)           # EKF predicted feature velocity
        self.cov_trace = 0.0
        self._success_streak = 0
        self.last_valid_s = self.true_s.copy()
        return self._obs(), {}

    def _fov_violation(self, s):
        return np.any(np.abs(s) > IMG_HALF * 1.6)

    def _obs(self):
        err = (self.s_pred - self.s_star) / IMG_HALF
        vel = self.s_vel / IMG_HALF
        t_since = np.array([min(self.channel.steps_since_valid, 20) / 20.0])
        cov = np.array([min(self.cov_trace, 400.0) / 400.0])
        return np.concatenate([err, vel, t_since, cov, self.prev_action]).astype(np.float32)

    def step(self, action):
        action = np.clip(action, -1, 1)
        v_phys = action * self.V_LIM
        disturb = self.rng.normal(0, self.process_noise_std, size=4)
        # integrate true pose (with small unmodeled platform disturbance)
        self.pose = self.pose + (np.array([v_phys[0], v_phys[1], v_phys[2], v_phys[3]]) + disturb) * DT
        self.pose[2] = np.clip(self.pose[2], 0.2, 1.2)
        # target continues to drift (e.g. conveyor / handheld part) regardless of camera dropout
        self.target_vel = self.target_vel + self.rng.normal(0, self.target_drift_std * 0.3, size=2)
        self.target_vel = np.clip(self.target_vel, -0.05, 0.05)
        self.target_xy = self.target_xy + self.target_vel * DT
        self.true_s, self.zc, _, _ = project(self.pose, target_xy=self.target_xy)

        visible = self.channel.step()
        if visible:
            noisy_s = self.true_s + self.rng.normal(0, self.pixel_noise_std, size=8)
            # EKF update (simple alpha-beta / constant-velocity filter)
            innov = noisy_s - self.s_pred
            self.s_vel = 0.7 * self.s_vel + 0.3 * (innov / DT)
            self.s_pred = noisy_s
            self.cov_trace = 5.0  # low uncertainty right after an update
            self.last_valid_s = noisy_s
        else:
            # propagate forward with constant-velocity model, grow uncertainty
            self.s_pred = self.s_pred + self.s_vel * DT
            self.cov_trace = self.cov_trace + 8.0 * (1 + 0.15 * self.channel.steps_since_valid)

        err_true = self.true_s - self.s_star
        rmse_true = np.sqrt(np.mean(err_true ** 2))
        action_pen = 0.01 * np.sum(action ** 2)
        smooth_pen = 0.01 * np.sum((action - self.prev_action) ** 2)
        proximity_bonus = 0.30 * np.exp(-rmse_true / 15.0)
        reward = -0.02 * rmse_true - action_pen - smooth_pen - 0.02 + proximity_bonus

        lost = self._fov_violation(self.true_s) or self.pose[2] <= 0.21 or self.pose[2] >= 1.19
        if lost:
            reward -= 15.0

        if rmse_true < SUCCESS_TOL:
            self._success_streak += 1
            reward += 0.05
        else:
            self._success_streak = 0
        success = self._success_streak >= SUCCESS_HOLD

        self.prev_action = action.copy()
        self.t += 1
        done = lost or success or (self.t >= MAX_STEPS)
        info = dict(rmse_true=rmse_true, visible=visible, lost=lost, success=success,
                    cov_trace=self.cov_trace, pose=self.pose.copy())
        return self._obs(), reward, done, info
