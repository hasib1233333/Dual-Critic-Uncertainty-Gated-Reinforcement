import sys
import json
import time
import numpy as np
import torch

from train import make_env, collect_and_train
from ppo import Agent

RESULTS = '/home/claude/project/results'
MODELS = '/home/claude/project/models'


def train_one(name, dual, seed, episodes, **agent_kwargs):
    np.random.seed(seed)
    torch.manual_seed(seed)
    env = make_env(seed=seed, difficulty='moderate')
    agent = Agent(env.obs_dim, env.act_dim, dual=dual, **agent_kwargs)
    t0 = time.time()
    hist, raw = collect_and_train(agent, env, total_episodes=episodes,
                                   episodes_per_update=16, log_every=200, verbose=True)
    dt = time.time() - t0
    print(f'--- {name} seed={seed} done in {dt:.1f}s, final success={hist[-1]["success_rate"]:.2f} ---', flush=True)
    torch.save({'actor': agent.actor.state_dict(), 'v_opt': agent.v_opt.state_dict(),
                'v_pess': agent.v_pess.state_dict() if dual else None},
               f'{MODELS}/{name}_seed{seed}.pt')
    fname = f'{RESULTS}/train_{name}.json'
    try:
        with open(fname) as f:
            all_hist = json.load(f)
    except FileNotFoundError:
        all_hist = []
    all_hist = [h for h in all_hist if h['seed'] != seed]
    all_hist.append(dict(seed=seed, history=hist, elapsed=dt))
    all_hist.sort(key=lambda h: h['seed'])
    with open(fname, 'w') as f:
        json.dump(all_hist, f)


VARIANTS = {
    'dcug_full':       dict(dual=True,  episodes=3000, kwargs={}),
    'single_critic':   dict(dual=False, episodes=3000, kwargs={}),
    'abl_fixed_alpha': dict(dual=True,  episodes=2500, kwargs=dict(fixed_alpha=0.5)),
    'abl_no_vdiff':    dict(dual=True,  episodes=2500, kwargs=dict(use_vdiff=False)),
}

if __name__ == '__main__':
    name = sys.argv[1]
    seed = int(sys.argv[2])
    cfg = VARIANTS[name]
    train_one(name, cfg['dual'], seed, cfg['episodes'], **cfg['kwargs'])
    print('SEED_DONE', name, seed)
