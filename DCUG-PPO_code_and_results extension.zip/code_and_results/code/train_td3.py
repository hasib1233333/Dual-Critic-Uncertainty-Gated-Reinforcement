import numpy as np
from train import make_env
from td3 import TD3Agent, ReplayBuffer


def collect_and_train_td3(agent, env, buf, total_episodes, log_every=100, verbose=True,
                            updates_per_step=1, warmup_steps=1000):
    ep_returns, ep_success, ep_lost = [], [], []
    history = []
    total_steps = 0

    for ep in range(total_episodes):
        obs, _ = env.reset()
        done = False
        ep_ret = 0.0
        while not done:
            if total_steps < warmup_steps:
                act = np.random.uniform(-1, 1, size=env.act_dim).astype(np.float32)
            else:
                act, *_ = agent.act(obs, sample=True)
            next_obs, rew, done, info = env.step(act)
            buf.add(obs, act, rew, next_obs, done)
            obs = next_obs
            ep_ret += rew
            total_steps += 1
            if total_steps >= warmup_steps:
                for _ in range(updates_per_step):
                    agent.update(buf)
        ep_returns.append(ep_ret)
        ep_success.append(float(info['success']))
        ep_lost.append(float(info['lost']))

        if (ep + 1) % log_every == 0:
            w = 200
            history.append(dict(
                episode=ep + 1,
                mean_return=float(np.mean(ep_returns[-w:])),
                success_rate=float(np.mean(ep_success[-w:])),
                lost_rate=float(np.mean(ep_lost[-w:])),
            ))
            if verbose:
                h = history[-1]
                print(f"  ep {h['episode']:5d} | return {h['mean_return']:7.2f} | "
                      f"succ {h['success_rate']:.2f} | lost {h['lost_rate']:.2f}")
    return history


if __name__ == '__main__':
    import time
    env = make_env(seed=1, difficulty='moderate')
    agent = TD3Agent(env.obs_dim, env.act_dim)
    buf = ReplayBuffer(env.obs_dim, env.act_dim)
    t0 = time.time()
    hist = collect_and_train_td3(agent, env, buf, total_episodes=300, log_every=50, warmup_steps=500)
    print('elapsed', time.time() - t0)
