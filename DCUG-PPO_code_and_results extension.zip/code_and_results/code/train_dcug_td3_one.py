import sys, json, time
import numpy as np
import torch

from train import make_env
from dcug_td3 import DCUGTD3Agent, GatedReplayBuffer
from train_dcug_td3 import collect_and_train_dcug_td3

RESULTS = '/home/claude/project/results'
MODELS = '/home/claude/project/models'

TOTAL_EPISODES = 1200
CHUNK = 100
WARMUP = 800


def save_ckpt(ckpt_path, agent, buf, done_episodes, history):
    import os
    tmp_path = ckpt_path + '.tmp'
    torch.save(dict(actor=agent.actor.state_dict(), actor_target=agent.actor_target.state_dict(),
                     critic=agent.critic.state_dict(), critic_target=agent.critic_target.state_dict(),
                     q_pess=agent.q_pess.state_dict(), q_pess_target=agent.q_pess_target.state_dict(),
                     update_count=agent.update_count, buf=buf, done_episodes=done_episodes,
                     history=history), tmp_path)
    os.replace(tmp_path, ckpt_path)


def train_chunk(seed, difficulty='moderate', time_budget=195):
    t_start = time.time()
    ckpt_path = f'{MODELS}/dcug_td3_seed{seed}_ckpt.pt'
    env = make_env(seed=seed, difficulty=difficulty)

    try:
        ckpt = torch.load(ckpt_path, weights_only=False)
        agent = DCUGTD3Agent(env.obs_dim, env.act_dim)
        agent.actor.load_state_dict(ckpt['actor'])
        agent.actor_target.load_state_dict(ckpt['actor_target'])
        agent.critic.load_state_dict(ckpt['critic'])
        agent.critic_target.load_state_dict(ckpt['critic_target'])
        agent.q_pess.load_state_dict(ckpt['q_pess'])
        agent.q_pess_target.load_state_dict(ckpt['q_pess_target'])
        agent.update_count = ckpt['update_count']
        buf = ckpt['buf']
        done_episodes = ckpt['done_episodes']
        history = ckpt['history']
        print(f'resumed seed={seed} at episode {done_episodes}', flush=True)
    except FileNotFoundError:
        np.random.seed(seed); torch.manual_seed(seed)
        agent = DCUGTD3Agent(env.obs_dim, env.act_dim)
        buf = GatedReplayBuffer(env.obs_dim, env.act_dim)
        done_episodes = 0
        history = []
        print(f'starting fresh seed={seed}', flush=True)

    while done_episodes < TOTAL_EPISODES and (time.time() - t_start) < time_budget:
        this_chunk = min(CHUNK, TOTAL_EPISODES - done_episodes)
        warmup_left = max(0, WARMUP - buf.size)
        h = collect_and_train_dcug_td3(agent, env, buf, total_episodes=this_chunk, log_every=100,
                                         warmup_steps=warmup_left, verbose=True)
        for entry in h:
            entry['episode'] += done_episodes
        history += h
        done_episodes += this_chunk
        save_ckpt(ckpt_path, agent, buf, done_episodes, history)
        print(f'  [checkpoint saved at episode {done_episodes}, elapsed {time.time()-t_start:.0f}s]', flush=True)

    if done_episodes >= TOTAL_EPISODES:
        torch.save(dict(actor=agent.actor.state_dict()), f'{MODELS}/dcug_td3_seed{seed}.pt')
        with open(f'{RESULTS}/train_dcug_td3_seed{seed}.json', 'w') as f:
            json.dump(dict(seed=seed, history=history), f)
        print(f'SEED {seed} FULLY DONE, final success={history[-1]["success_rate"]:.2f}', flush=True)
        return True
    return False


if __name__ == '__main__':
    seed = int(sys.argv[1])
    finished = train_chunk(seed)
    print('FINISHED' if finished else 'PARTIAL', seed)
