"""
PPO with an optional Dual-Critic Uncertainty-Gated (DCUG) actor.

Standard mode (dual=False): vanilla Gaussian-policy PPO, single critic.
DCUG mode (dual=True): actor produces a raw action + a learned gate alpha in
(0,1); executed action distribution is the affine blend of the raw Gaussian
proposal with an externally supplied fallback action a_safe:
    mu_final  = alpha * mu_raw + (1-alpha) * a_safe
    std_final = alpha * std_raw + eps
so PPO's log-prob / ratio machinery is applied, exactly, to the *executed*
action distribution. A second critic (V_pess) is trained with an asymmetric
expectile loss (tau=0.1) so it under-estimates value in high-variance /
high-uncertainty states; (V_opt - V_pess), detached, is fed into the gate
head as a learned risk-disagreement signal.
"""
import numpy as np
import torch
import torch.nn as nn

torch.set_num_threads(4)


def mlp(sizes, act=nn.Tanh, out_act=nn.Identity):
    layers = []
    for i in range(len(sizes) - 1):
        layers.append(nn.Linear(sizes[i], sizes[i + 1]))
        layers.append(act() if i < len(sizes) - 2 else out_act())
    return nn.Sequential(*layers)


class Critic(nn.Module):
    def __init__(self, obs_dim, hidden=64):
        super().__init__()
        self.net = mlp([obs_dim, hidden, hidden, 1])

    def forward(self, obs):
        return self.net(obs).squeeze(-1)


class Actor(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden=64, dual=False, use_vdiff=True, use_unc=True):
        super().__init__()
        self.dual = dual
        self.use_vdiff = use_vdiff
        self.use_unc = use_unc
        self.trunk = mlp([obs_dim, hidden, hidden], out_act=nn.Tanh)
        self.mu_head = nn.Linear(hidden, act_dim)
        self.log_std = nn.Parameter(-1.1 * torch.ones(act_dim))
        if dual:
            gate_in = hidden + (1 if use_vdiff else 0)
            self.gate_head = mlp([gate_in, 32, 1])

    def forward(self, obs, a_safe=None, v_diff=None, fixed_alpha=None):
        h = self.trunk(obs)
        mu_raw = torch.tanh(self.mu_head(h))
        log_std_raw = torch.clamp(self.log_std, -3.0, 0.4)
        std_raw = torch.exp(log_std_raw).expand_as(mu_raw)
        if not self.dual:
            return mu_raw, std_raw, torch.ones(obs.shape[0], 1)
        if fixed_alpha is not None:
            alpha = torch.full((obs.shape[0], 1), fixed_alpha)
        else:
            if self.use_vdiff:
                gate_in = torch.cat([h, v_diff.unsqueeze(-1)], dim=-1)
            else:
                gate_in = h
            alpha = torch.sigmoid(self.gate_head(gate_in))
        mu_final = alpha * mu_raw + (1 - alpha) * a_safe
        std_final = alpha * std_raw + 1e-3
        return mu_final, std_final, alpha


def gaussian_logprob(mu, std, a):
    var = std ** 2
    logp = -0.5 * (((a - mu) ** 2) / (var + 1e-8) + 2 * torch.log(std + 1e-8) + np.log(2 * np.pi))
    return logp.sum(-1)


def gaussian_entropy(std):
    return (0.5 * torch.log(2 * np.pi * np.e * std ** 2 + 1e-8)).sum(-1)


class RolloutBuffer:
    def __init__(self):
        self.reset()

    def reset(self):
        self.obs, self.acts, self.rews, self.dones = [], [], [], []
        self.logps, self.vopt, self.vpess, self.asafe, self.vdiff = [], [], [], [], []

    def add(self, obs, act, rew, done, logp, vopt, vpess, asafe, vdiff):
        self.obs.append(obs); self.acts.append(act); self.rews.append(rew); self.dones.append(done)
        self.logps.append(logp); self.vopt.append(vopt); self.vpess.append(vpess)
        self.asafe.append(asafe); self.vdiff.append(vdiff)


def compute_gae(rews, vals, dones, gamma=0.98, lam=0.95, last_val=0.0):
    T = len(rews)
    adv = np.zeros(T, dtype=np.float32)
    lastgae = 0.0
    for t in reversed(range(T)):
        nextval = last_val if t == T - 1 else vals[t + 1]
        nextnonterm = 0.0 if dones[t] else 1.0
        delta = rews[t] + gamma * nextval * nextnonterm - vals[t]
        lastgae = delta + gamma * lam * nextnonterm * lastgae
        adv[t] = lastgae
    ret = adv + np.array(vals, dtype=np.float32)
    return adv, ret


def expectile_loss(pred, target, tau=0.1):
    u = target - pred
    w = torch.where(u > 0, tau, 1 - tau)
    return (w * u ** 2).mean()


class Agent:
    """Wraps actor + (one or two) critics, action selection, and PPO update."""
    def __init__(self, obs_dim, act_dim, dual=False, use_vdiff=True, use_unc=True,
                 fixed_alpha=None, lr=3e-4, tau_pess=0.1):
        self.dual = dual
        self.fixed_alpha = fixed_alpha
        self.tau_pess = tau_pess
        self.actor = Actor(obs_dim, act_dim, dual=dual, use_vdiff=use_vdiff, use_unc=use_unc)
        self.v_opt = Critic(obs_dim)
        self.v_pess = Critic(obs_dim) if dual else None
        params = list(self.actor.parameters()) + list(self.v_opt.parameters())
        if dual:
            params += list(self.v_pess.parameters())
        self.opt = torch.optim.Adam(params, lr=lr)

    def act(self, obs_np, a_safe_np=None, sample=True):
        obs = torch.as_tensor(obs_np, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            v_opt = self.v_opt(obs)
            v_diff = torch.zeros(1)
            if self.dual:
                v_pess = self.v_pess(obs)
                v_diff = (v_opt - v_pess).detach()
            a_safe = torch.as_tensor(a_safe_np, dtype=torch.float32).unsqueeze(0) if a_safe_np is not None else None
            mu, std, alpha = self.actor(obs, a_safe=a_safe, v_diff=v_diff, fixed_alpha=self.fixed_alpha)
            if sample:
                a = mu + std * torch.randn_like(mu)
            else:
                a = mu
            logp = gaussian_logprob(mu, std, a)
        return (a.squeeze(0).numpy(), logp.item(), v_opt.item(),
                (self.v_pess(obs).item() if self.dual else 0.0), float(alpha.squeeze()))

    def update(self, buf: RolloutBuffer, epochs=8, batch_size=256, clip=0.2, vf_coef=0.5,
               pess_coef=0.5, ent_coef=0.001):
        obs = torch.as_tensor(np.array(buf.obs), dtype=torch.float32)
        acts = torch.as_tensor(np.array(buf.acts), dtype=torch.float32)
        old_logp = torch.as_tensor(np.array(buf.logps), dtype=torch.float32)
        asafe = torch.as_tensor(np.array(buf.asafe), dtype=torch.float32)

        adv, ret = compute_gae(buf.rews, buf.vopt, buf.dones)
        adv = (adv - adv.mean()) / (adv.std() + 1e-8)
        adv_t = torch.as_tensor(adv, dtype=torch.float32)
        ret_t = torch.as_tensor(ret, dtype=torch.float32)

        if self.dual:
            _, ret_pess = compute_gae(buf.rews, buf.vpess, buf.dones)
            ret_pess_t = torch.as_tensor(ret_pess, dtype=torch.float32)

        N = obs.shape[0]
        idx_all = np.arange(N)
        for _ in range(epochs):
            np.random.shuffle(idx_all)
            for start in range(0, N, batch_size):
                idx = idx_all[start:start + batch_size]
                b_obs, b_acts = obs[idx], acts[idx]
                b_oldlogp, b_adv, b_ret = old_logp[idx], adv_t[idx], ret_t[idx]
                b_asafe = asafe[idx]

                v_opt_pred = self.v_opt(b_obs)
                if self.dual:
                    v_pess_pred = self.v_pess(b_obs)
                    v_diff = (v_opt_pred - v_pess_pred).detach()
                else:
                    v_diff = torch.zeros(b_obs.shape[0])

                mu, std, alpha = self.actor(b_obs, a_safe=b_asafe, v_diff=v_diff, fixed_alpha=self.fixed_alpha)
                logp = gaussian_logprob(mu, std, b_acts)
                ratio = torch.exp(logp - b_oldlogp)
                surr1 = ratio * b_adv
                surr2 = torch.clamp(ratio, 1 - clip, 1 + clip) * b_adv
                policy_loss = -torch.min(surr1, surr2).mean()
                entropy = gaussian_entropy(std).mean()

                v_loss = ((v_opt_pred - b_ret) ** 2).mean()
                loss = policy_loss + vf_coef * v_loss - ent_coef * entropy
                if self.dual:
                    b_ret_pess = ret_pess_t[idx]
                    pess_loss = expectile_loss(v_pess_pred, b_ret_pess, tau=self.tau_pess)
                    loss = loss + pess_coef * pess_loss

                self.opt.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(
                    list(self.actor.parameters()) + list(self.v_opt.parameters()) +
                    (list(self.v_pess.parameters()) if self.dual else []), 0.5)
                self.opt.step()
